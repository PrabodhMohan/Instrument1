export const INSTRUMENT_REPOSITORY_ADMIN = "InstrumentRepositoryAdmin";

export const GROUPS_TOKEN_PATH =
  "signInUserSession.accessToken.payload.cognito:groups";

export const DEFAULT_SITE_NAME = "Rotkreuz";
export const DEFAULT_SITE_TIMEZONE = "Europe/Zurich";

export const ACCESS_TOKEN_PATH = "signInUserSession.idToken.payload";
export const SYNC_PROFILE_FIELDS = {
  givenName: "custom:firstName",
  familyName: "custom:lastName",
  name: "preferred_username",
  phone: "custom:phoneNumber",
  site: "custom:site"
};

export const INSTRUMENT_REPO_VIEW_USER = "InstrumentRepositoryViewer";

export const getSteps = () => {
  return [
    "Equipment identification",
    "Equipment description",
    "Laboratory information",
    "GxP & Maintenance information",
    "Analyzer configuration",
    "Digital Lab"
  ];
};

export const equipmentDescription = () => {
  return [
    "Instrument name",
    "GITN",
    "Equipment ID",
    "RUDI",
    "Category",
    "Technical position"
  ];
};

export const emptyInstrumentIdentification = {
  siteName: null,
  manufacturer: null,
  instrumentDescription: null,
  instrumentType: null,
  module: null,
  serialNumber: null,
  materialNumber: null,
  displayImage: null
};

export const GXPemptyInstruments = {
  sop: [],
  csv: null,
  electronicRecord: null,
  electronicSignatures: null,
  dateOfNextPeriodicReview: null,
  maintenancePlan: "",
  gxpRelevant: null,
  instrumentGxPStatus: null,
  dateOfNextMaintanance: {
    isSynchronized: false,
    value: null
  },
  dateOfLastMaintanance: {
    isSynchronized: false,
    value: null
  }
};

export const GXPemptyInstrumentsOptions = {
  csv: [
    { key: "Yes", value: "Yes" },
    { key: "No", value: "No" },
    { key: "NA", value: "NA" }
  ],
  electronicRecord: [
    { key: "Yes", value: "Yes" },
    { key: "No", value: "No" },
    { key: "NA", value: "NA" }
  ],
  electronicSignatures: [
    { key: "Yes", value: "Yes" },
    { key: "No", value: "No" },
    { key: "NA", value: "NA" }
  ],
  gxpRelevant: [
    { key: "Yes", value: "Yes" },
    { key: "No", value: "No" }
  ],
  instrumentGxPStatus: [
    { key: "QUALIFIED", value: "Qualified" },
    { key: "NOT_QUALIFIED", value: "Not qualified" },
    { key: "NA", value: "NA" }
  ],
  dateOfNextMaintanance: { value: null },
  dateOfLastMaintanance: { value: null }
};

export const emptyEquipmentDescription = {
  instrumentName: null,
  instrumentGTIN: null,
  equipmentId: null,
  instrumentRUDI: null,
  equipmentCategory: null,
  technicalPlace: null,
  remark: null
};

export const emptyAnalyzerConfiguration = {
  softwareVersion: null,
  configurationBaseline: null,
  installedTests: [],
  qualificationDocuments: {
    isSynchronized: false,
    value: []
  }
};
export const emptyLaboratoryInfo = {
  belongingToGroup: null,
  responsiblePerson: null,
  secondResponsiblePerson: null,
  systemOwner: null,
  buildingLocation: null,
  floorAndRoomLocation: null
};

export const emptyDigitalLabInfo = {
  isBookable: false,
  isVisualized: false
};

export const emptyTableColumn = [
  { key: "serialNumber", val: "Serial number", order: 1, show: true },
  { key: "materialNumber", val: "Material number", order: 2, show: true },
  { key: "instrumentType", val: "Type", order: 3, show: true },
  { key: "instrumentName", val: "Name", order: 4, show: true },
  { key: "siteName", val: "Site", order: 5, show: true },
  { key: "manufacturer", val: "Manufacturer", order: 6, show: true },
  { key: "instrumentDescription", val: "Description", order: 7, show: true }
];

export const emptyHideTableColumn = [
  { key: "module", val: "Module", order: 1, show: false },
  { key: "instrumentGTIN", val: "GTIN number", order: 2, show: false },
  { key: "equipmentId", val: "Equipment id", order: 3, show: false },
  { key: "location", val: "Location", order: 4, show: false },
  {
    key: "responsiblePerson",
    val: "Responsible person",
    order: 5,
    show: false
  },
  { key: "isBookable", val: "Bookable", order: 6, show: false },
  { key: "instrumentRUDI", val: "RUDI number", order: 7, show: false },
  { key: "equipmentCategory", val: "Category", order: 8, show: false },
  { key: "technicalPlace", val: "Technical position", order: 9, show: false },
  { key: "remark", val: "Comment", order: 10, show: false },
  {
    key: "belongingToGroup",
    val: "Group",
    order: 11,
    show: false
  },
  {
    key: "floorAndRoomLocation",
    val: "Room",
    order: 12,
    show: false
  },
  { key: "systemOwner", val: "System owner", order: 13, show: false },
  {
    key: "secondResponsiblePerson",
    val: "Responsible person 2",
    order: 14,
    show: false
  },
  { key: "sop", val: "SOP", order: 15, show: false },
  { key: "csv", val: "CSV relevant", order: 16, show: false },
  {
    key: "electronicRecord",
    val: "Electronic records",
    order: 17,
    show: false
  },
  {
    key: "electronicSignatures",
    val: "Electronic signatures",
    order: 18,
    show: false
  },
  {
    key: "dateOfNextPeriodicReview",
    val: "Date of periodic review",
    order: 19,
    show: false
  },
  {
    key: "maintenancePlan",
    val: "Maintenance or calibration plan",
    order: 20,
    show: false
  },
  { key: "gxpRelevant", val: "GxP relevant", order: 21, show: false },
  { key: "instrumentGxPStatus", val: "GxP state", order: 22, show: false },
  {
    key: "dateOfNextMaintanance",
    val: "Date of next maintenance",
    order: 23,
    show: false
  },
  { key: "softwareVersion", val: "Version", order: 24, show: false },
  {
    key: "configurationBaseline",
    val: "Configure baseline",
    order: 25,
    show: false
  },
  { key: "installedTests", val: "Installed tests", order: 26, show: false },
  {
    key: "qualificationDocuments",
    val: "Linked document tests",
    order: 27,
    show: false
  },
  { key: "isVisualized", val: "Visualized", order: 28, show: false },
  {
    key: "dateOfLastMaintanance",
    val: "Date of executed maintenance",
    order: 28,
    show: false
  },
  { key: "buildingLocation", val: "Building", order: 28, show: false }
];

export const allTableColumn = [
  { key: "serialNumber", val: "Serial number", order: 1, show: true },
  { key: "materialNumber", val: "Material number", order: 2, show: true },
  { key: "instrumentType", val: "Type", order: 3, show: true },
  { key: "instrumentName", val: "Name", order: 4, show: true },
  { key: "siteName", val: "Site", order: 5, show: true },
  { key: "manufacturer", val: "Manufacturer", order: 6, show: true },
  { key: "instrumentDescription", val: "Description", order: 7, show: true },
  { key: "module", val: "Module", order: 1, show: false },
  { key: "instrumentGTIN", val: "GTIN number", order: 2, show: false },
  { key: "equipmentId", val: "Equipment id", order: 3, show: false },
  { key: "location", val: "Location", order: 4, show: false },
  {
    key: "responsiblePerson",
    val: "Responsible person",
    order: 5,
    show: false
  },
  { key: "isBookable", val: "Bookable", order: 6, show: false },
  { key: "instrumentRUDI", val: "RUDI number", order: 7, show: false },
  { key: "equipmentCategory", val: "Category", order: 8, show: false },
  { key: "technicalPlace", val: "Technical position", order: 9, show: false },
  { key: "remark", val: "Comment", order: 10, show: false },
  {
    key: "belongingToGroup",
    val: "Group",
    order: 11,
    show: false
  },
  {
    key: "floorAndRoomLocation",
    val: "Room",
    order: 12,
    show: false
  },
  { key: "systemOwner", val: "System owner", order: 13, show: false },
  {
    key: "secondResponsiblePerson",
    val: "Responsible person 2",
    order: 14,
    show: false
  },
  { key: "sop", val: "SOP", order: 15, show: false },
  { key: "csv", val: "CSV relevant", order: 16, show: false },
  {
    key: "electronicRecord",
    val: "Electronic records",
    order: 17,
    show: false
  },
  {
    key: "electronicSignatures",
    val: "Electronic signatures",
    order: 18,
    show: false
  },
  {
    key: "dateOfNextPeriodicReview",
    val: "Date of periodic review",
    order: 19,
    show: false
  },
  {
    key: "maintenancePlan",
    val: "Maintenance or calibration plan",
    order: 20,
    show: false
  },
  { key: "gxpRelevant", val: "GxP relevant", order: 21, show: false },
  { key: "instrumentGxPStatus", val: "GxP state", order: 22, show: false },
  {
    key: "dateOfNextMaintanance",
    val: "Date of next maintenance",
    order: 23,
    show: false
  },
  { key: "softwareVersion", val: "Version", order: 24, show: false },
  {
    key: "configurationBaseline",
    val: "Configure baseline",
    order: 25,
    show: false
  },
  { key: "installedTests", val: "Installed tests", order: 26, show: false },
  {
    key: "qualificationDocuments",
    val: "Linked document tests",
    order: 26,
    show: false
  },
  { key: "isVisualized", val: "Visualized", order: 28, show: false },
  {
    key: "dateOfLastMaintanance",
    val: "Date of executed maintenance",
    order: 27,
    show: false
  },
  { key: "buildingLocation", val: "Building", order: 28, show: false }
];
export const emptyFilter = {
  site: "",
  group: "",
  manufacturer: "",
  category: "",
  responsiblePerson: ""
};

export const DEFAULT_LIMIT = 5;
