import "./App.scss";
import CssBaseline from "@material-ui/core/CssBaseline";
import AppBar from "./views/AppBar";
import { StyledToastContainer } from "./features/notifications/Notify";
import "react-toastify/dist/ReactToastify.css";
import LoadInstrumentsInfo from "./features/instruments/LoadInstrumentsInfo";
import InstrumentsMainPage from "./features/instruments/InstrumentsMainPage";

function App() {
  return (
    <LoadInstrumentsInfo>
      <CssBaseline />
      <AppBar />
      <InstrumentsMainPage />
      <StyledToastContainer />
    </LoadInstrumentsInfo>
  );
}

export default App;
