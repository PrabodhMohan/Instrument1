import gql from "graphql-tag";

export const CREATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY = gql`
  mutation createDigitalLabInstrumentRepositoryEntry(
    $instrument: CreateDigitalLabInstrumentRepositoryEntryInput!
  ) {
    createDigitalLabInstrumentRepositoryEntry(input: $instrument) {
      costCenter
      alarmNumber
      belongingToGroup
      buildingLocation {
        key
        value
      }
      configurationBaseline
      csv
      dateOfLastMaintanance {
        isSynchronized
        value
      }
      dateOfNextMaintanance {
        isSynchronized
        value
      }
      dateOfNextPeriodicReview
      electronicRecord
      electronicSignatures
      equipmentCategory {
        key
        value
      }
      equipmentId {
        isSynchronized
        value
      }
      eventIdentification
      floorAndRoomLocation {
        isSynchronized
        value
      }
      gemCode
      gxpRelevant
      installedTests {
        name
        version
      }
      instrumentDescription {
        key
        value
      }
      instrumentGTIN {
        isSynchronized
        value
      }
      instrumentGxPStatus
      instrumentName {
        isSynchronized
        value
      }
      instrumentRUDI
      instrumentType 
      inventoryStatus
      isBookable
      isVisualized
      location
      maintenancePlan
      manufacturer {
        key
        value
      }
      materialNumber
      module {
        key
        value
      }
      oaseNumber
      positioning
      positioningEquipment
      positioningSpecs
      qualificationDocuments {
        isSynchronized
        value {
          documentId
          name
        }
      }
      remark
      responsiblePerson {
        isSynchronized
        value
      }
      responsiblePersonId
      rfidNumber
      secondResponsiblePerson {
        isSynchronized
        value
      }
      secondResponsiblePersonId
      serialNumber
      simultaneity
      siteName
      siteTimezone
      softwareVersion
      sop {
        key
        value
      }
      sourceSystem
      systemOwner
      systemOwnerId
      systemStatus {
        isSynchronized
        value
      }
      targetBuilding
      targetRoom
      targetSite
      targetTechnicalPlace
      team
      technicalPlace
      testEquipment
      inventoryId
      displayImage
    }
  }
`;
export const UPDATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY = gql`
  mutation updateDigitalLabInstrumentRepositoryEntry(
    $instrument: UpdateDigitalLabInstrumentRepositoryEntryInput!
  ) {
    updateDigitalLabInstrumentRepositoryEntry(input: $instrument) {
      costCenter
      alarmNumber
      belongingToGroup
      buildingLocation {
        key
        value
      }
      configurationBaseline
      csv
      dateOfLastMaintanance {
        isSynchronized
        value
      }
      dateOfNextMaintanance {
        isSynchronized
        value
      }
      dateOfNextPeriodicReview
      electronicRecord
      electronicSignatures
      equipmentCategory {
        key
        value
      }
      equipmentId {
        isSynchronized
        value
      }
      eventIdentification
      floorAndRoomLocation {
        isSynchronized
        value
      }
      gemCode
      gxpRelevant
      heatLoad
      installedTests {
        name
        version
      }
      instrumentDescription {
        key
        value
      }
      instrumentGTIN {
        isSynchronized
        value
      }
      instrumentGxPStatus
      instrumentName {
        isSynchronized
        value
      }
      instrumentRUDI
      instrumentType 
      inventoryStatus
      isBookable
      isVisualized
      location
      maintenancePlan
      manufacturer {
        key
        value
      }
      materialNumber
      module {
        key
        value
      }
      oaseNumber
      positioning
      positioningEquipment
      positioningSpecs
      qualificationDocuments {
        isSynchronized
        value {
          documentId
          name
        }
      }
      remark
      responsiblePerson {
        isSynchronized
        value
      }
      responsiblePersonId
      rfidNumber
      secondResponsiblePerson {
        isSynchronized
        value
      }
      secondResponsiblePersonId
      serialNumber
      simultaneity
      siteName
      siteTimezone
      softwareVersion
      sop {
        key
        value
      }
      sourceSystem
      systemOwner
      systemOwnerId
      systemStatus {
        isSynchronized
        value
      }
      targetBuilding
      targetRoom
      targetSite
      targetTechnicalPlace
      team
      technicalPlace
      testEquipment
      inventoryId
      displayImage
    }
  }
`;

export const DELETE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY = gql`
  mutation deleteDigitalLabInstrumentRepositoryEntry(
    $materialNumber: String!
    $serialNumber: String!
  ) {
    deleteDigitalLabInstrumentRepositoryEntry(
      input: { materialNumber: $materialNumber, serialNumber: $serialNumber }
    ) {
      materialNumber
      serialNumber
    }
  }
`;

export const CREATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE = gql`
  mutation createDigitalLabInstrumentRepositoryUserProfile(
    $email: String!
    $lastFilter: String!
    $site: String
    $familyName: String
    $givenName: String
    $name: String
    $phone: String
  ) {
    createDigitalLabInstrumentRepositoryUserProfile(
      input: {
        email: $email
        lastFilter: $lastFilter
        site: $site
        familyName: $familyName
        givenName: $givenName
        name: $name
        phone: $phone
      }
    ) {
      id
      email
      lastFilter
      status
      familyName
      givenName
      name
      user
      phone
    }
  }
`;

export const UPDATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE_PERSONAL_FIELDS = gql`
  mutation updateDigitalLabInstrumentRepositoryUserProfile(
    $id: ID!
    $email: String!
    $lastFilter: String!
    $site: String
    $familyName: String
    $givenName: String
    $name: String
    $phone: String
  ) {
    updateDigitalLabInstrumentRepositoryUserProfile(
      input: {
        id: $id
        email: $email
        lastFilter: $lastFilter
        site: $site
        familyName: $familyName
        givenName: $givenName
        name: $name
        phone: $phone
      }
    ) {
      id
      email
      lastFilter
      status
      site
      familyName
      givenName
      name
      user
      phone
    }
  }
`;
