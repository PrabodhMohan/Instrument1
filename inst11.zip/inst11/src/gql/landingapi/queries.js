import gql from "graphql-tag";

export const GET_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY = gql`
  query GetDigitalLabInstrumentRepositoryEntry(
    $materialNumber: String!
    $serialNumber: String!
  ) {
    getDigitalLabInstrumentRepositoryEntry(
      materialNumber: $materialNumber
      serialNumber: $serialNumber
    ) {
      alarmNumber
      belongingToGroup
      buildingLocation {
        key
        value
      }
      equipmentCategory {
        key
        value
      }
      costCenter
      csv
      electronicRecord
      electronicSignatures
      gemCode
      gxpRelevant
      heatLoad
      inventoryStatus
      floorAndRoomLocation {
        value
        isSynchronized
      }
      instrumentRUDI
      materialNumber
      serialNumber
      instrumentGTIN {
        value
        isSynchronized
      }
      location
      maintenancePlan
      module {
        key
        value
      }
      oaseNumber
      dateOfNextPeriodicReview
      positioning
      positioningEquipment
      positioningSpecs
      remark
      responsiblePersonId
      secondResponsiblePersonId
      rfidNumber
      simultaneity
      sop {
        key
        value
      }
      systemOwner
      systemOwnerId
      targetSite
      targetBuilding
      targetRoom
      targetTechnicalPlace
      team
      technicalPlace
      testEquipment
      eventIdentification
      instrumentDescription {
        key
        value
      }
      instrumentType 
      instrumentName {
        value
        isSynchronized
      }
      siteName
      siteTimezone
      responsiblePerson {
        value
        isSynchronized
      }
      softwareVersion
      configurationBaseline
      systemStatus {
        value
        isSynchronized
      }
      instrumentGxPStatus
      dateOfNextMaintanance {
        value
        isSynchronized
      }
      dateOfLastMaintanance {
        value
        isSynchronized
      }
      isBookable
      isVisualized
      installedTests {
        name
        version
      }
      qualificationDocuments {
        isSynchronized
        value {
          documentId
          name
        }
      }
      equipmentId {
        value
        isSynchronized
      }
      manufacturer {
        key
        value
      }
      secondResponsiblePerson {
        value
        isSynchronized
      }
      sourceSystem
      displayImage
      inventoryId
    }
  }
`;
export const LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS = gql`
  query ListDigitalLabInstrumentRepositoryEntrys(
    $limit: Int
    $nextToken: String
    $filter: ModelDigitalLabInstrumentRepositoryEntryFilterInput
  ) {
    listDigitalLabInstrumentRepositoryEntrys(
      limit: $limit
      nextToken: $nextToken
      filter: $filter
    ) {
      nextToken
      items {
        costCenter
        alarmNumber
        belongingToGroup
        buildingLocation {
          key
          value
        }
        configurationBaseline
        csv
        dateOfLastMaintanance {
          isSynchronized
          value
        }
        dateOfNextMaintanance {
          isSynchronized
          value
        }
        dateOfNextPeriodicReview
        electronicRecord
        electronicSignatures
        equipmentCategory {
          key
          value
        }
        equipmentId {
          isSynchronized
          value
        }
        eventIdentification
        floorAndRoomLocation {
          isSynchronized
          value
        }
        gemCode
        gxpRelevant
        installedTests {
          name
          version
        }
        instrumentDescription {
          key
          value
        }
        instrumentGTIN {
          isSynchronized
          value
        }
        instrumentGxPStatus
        instrumentName {
          isSynchronized
          value
        }
        instrumentRUDI
        instrumentType
        inventoryStatus
        isBookable
        isVisualized
        location
        maintenancePlan
        manufacturer {
          key
          value
        }
        materialNumber
        module {
          key
          value
        }
        oaseNumber
        positioning
        positioningEquipment
        positioningSpecs
        qualificationDocuments {
          isSynchronized
          value {
            documentId
            name
          }
        }
        remark
        responsiblePerson {
          isSynchronized
          value
        }
        responsiblePersonId
        rfidNumber
        secondResponsiblePerson {
          isSynchronized
          value
        }
        secondResponsiblePersonId
        serialNumber
        simultaneity
        siteName
        siteTimezone
        softwareVersion
        sop {
          key
          value
        }
        sourceSystem
        systemOwner
        systemOwnerId
        systemStatus {
          isSynchronized
          value
        }
        targetBuilding
        targetRoom
        targetSite
        targetTechnicalPlace
        team
        technicalPlace
        testEquipment
        inventoryId
        displayImage
      }
      nextToken
    }
  }
`;
export const GET_INSTRUMENT_FROM_DATA_RIVER = gql`
  query getInstrumentFromDataRiver(
    $materialNumber: String!
    $serialNumber: String!
  ) {
    getInstrumentFromDataRiver(
      materialNumber: $materialNumber
      serialNumber: $serialNumber
    ) {
      materialNumber
      serialNumber
      systemStatus {
        value
      }
      responsiblePerson {
        value
      }
      buildingLocation {
        value
      }
      dateOfLastMaintanance {
        value
      }
      dateOfNextMaintanance {
        value
      }
      instrumentType 
      floorAndRoomLocation {
        value
      }
      manufacturer {
        value
      }
      equipmentId {
        value
      }
    }
  }
`;

export const LIST_BACKEND_HEALTH_CHECKS = gql`
  query listBackendHealthChecks {
    listBackendHealthChecks {
      items {
        ciJobId
        commitHash
        createdAt
        id
        moduleName
        moduleVersion
        updatedAt
      }
    }
  }
`;

export const LIST_SITES = gql`
  query listSites($limit: Int, $nextToken: String) {
    listSites(limit: $limit, nextToken: $nextToken) {
      items {
        siteName
        timezone
      }
      nextToken
    }
  }
`;

export const USER_BY_EMAIL = gql`
  query userByEmail($email: String!) {
    userByEmail(email: $email) {
      items {
        id
        email
        lastFilter
        familyName
        givenName
        name
        phone
        status
        site
        user
      }
    }
  }
`;
export const LIST_COMBINED_RESULT = gql`
  query listCombinedResult($limit: Int, $siteName: String!) {
    listIRBuildingMasters(siteName: $siteName, limit: $limit) {
      items {
        isActive
        key
        value
      }
    }
    listIRDescriptionMasters(siteName: $siteName, limit: $limit) {
      items {
        siteName
        key
        value
      }
    }

    listIRManufacturerMasters(siteName: $siteName, limit: $limit) {
      items {
        isActive
        key
        value
      }
    }

    listIRGroupMasters(siteName: $siteName, limit: $limit) {
      items {
        value
      }
    }
    listIRModuleMasters(siteName: $siteName, limit: $limit) {
      items {
        isActive
        key
        value
      }
    }
    listIRSOPMasters(siteName: $siteName, limit: $limit) {
      items {
        isActive
        key
        value
      }
    }
    listIREquipmentTypeConfigurations(siteName: $siteName, limit: $limit) {
      items {
        siteName
        equipmentType
        displayImage
        equipmentCategory {
          equipmentCategory
          isBookable
          isVisualized
          hasLogbook
          defaultToTestEquipment
        }
      }
    }
    listIREquipmentCategoryConfigurations {
      items {
        key: equipmentCategory
        value: equipmentCategory
      }
    }
    listDigitalLabInstrumentRepositoryEntrys {
      items {
        responsiblePerson {
          value
        }
      }
    }
    listIRResponsiblePersonLookups {
      items {
        personName
      }
    }
  }
`;
