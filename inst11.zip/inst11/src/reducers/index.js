import { combineReducers } from "redux";
import instrumentsReducer from "../features/instruments/redux/reducer";
import userReducer from "../features/user/redux/reducer";

const rootReducer = combineReducers({
  user: userReducer,
  instruments: instrumentsReducer
});

export default rootReducer;
