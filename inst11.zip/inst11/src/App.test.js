import React, { useContext } from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import LoadInstrumentsInfo from "./features/instruments/LoadInstrumentsInfo";
import AppBar from "./views/AppBar";
import InstrumentsMainPage from "./features/instruments/InstrumentsMainPage";
import App from "./App";

jest.mock("./utils/hooks");
jest.mock("./views/AppBar", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});
jest.mock("./features/instruments/InstrumentsMainPage", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});
jest.mock("./features/instruments/LoadInstrumentsInfo", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});

const FakeLoadInstrumentsInfo = ({ children }) => (
  <div data-testid="load-instrment-info">{children}</div>
);

const FakeAppBar = () => <div data-testid="app-bar">AppBar</div>;

const FakeInstrumentsMainPage = () => {
  return <div data-testid="mainpage">main page</div>;
};

test("should setup initial state", () => {
  // arrange
  LoadInstrumentsInfo.mockImplementation(FakeLoadInstrumentsInfo);
  AppBar.mockImplementation(FakeAppBar);
  InstrumentsMainPage.mockImplementation(FakeInstrumentsMainPage);

  // act
  const { getByTestId } = render(<App />);

  // assert

  expect(getByTestId("load-instrment-info")).toBeDefined();
  expect(getByTestId("app-bar")).toBeDefined();
  expect(getByTestId("mainpage")).toBeDefined();
});
