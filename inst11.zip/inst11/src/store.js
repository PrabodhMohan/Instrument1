import configureStore from "./store/configureStore";
export const store = configureStore();
