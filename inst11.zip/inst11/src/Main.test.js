import React from "react";
import { render, cleanup } from "@testing-library/react";
import Main from "./Main";
import { MemoryRouter } from "react-router-dom";

jest.mock("@aws-amplify/ui-react", () => ({
  withAuthenticator: (Component) => Component
}));
jest.mock("./features/Authentication");
jest.mock("./App");

afterEach(cleanup);

describe("Main", () => {
  test("should create", () => {
    const { getByTestId } = render(
      <MemoryRouter initialEntries={["/"]}>
        <Main />
      </MemoryRouter>
    );
    const welcome = getByTestId("main-page-main-route");
    expect(welcome).toBeDefined();
  });
  test("should show 404", () => {
    const { getByTestId } = render(
      <MemoryRouter initialEntries={["/not-exist"]}>
        <Main />
      </MemoryRouter>
    );
    const welcome = getByTestId(
      "main-page-not-authenticated-with-error-not-found"
    );
    expect(welcome).toBeDefined();
  });
});
