import React from "react";

const App = () => <h1 data-testid="main-page-app-component">app</h1>;

export default App;
