import React from "react";
import { withAuthenticator } from "@aws-amplify/ui-react";
import App from "./App";
import Authentication from "./features/Authentication";
import MaterialTheme from "./components/MaterialTheme";
import StyledTheme from "./components/StyledTheme";
import { Route, Switch } from "react-router-dom";
import NotFoundScreen from "./components/NotFoundScreen";
import { federated } from "./aws-exports";
import ModuleVersion from "./features/system-version/ModuleVersion";

/**
 * to turn off google login button - remove federated authenticatorProps below
 */
const AuthenticatedApp = withAuthenticator(App, { federated: federated });

const Main = () => (
  <MaterialTheme>
    <StyledTheme>
      <Switch>
        <Route exact path="/">
          <Authentication>
            <AuthenticatedApp />
          </Authentication>
        </Route>
        <Route exact path="/info">
          <ModuleVersion />
        </Route>
        <Route path="*">
          <NotFoundScreen redirectPath={"/"} />
        </Route>
      </Switch>
    </StyledTheme>
  </MaterialTheme>
);
export default Main;
