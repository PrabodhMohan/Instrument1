import React from "react";
import { render, cleanup } from "../../test-utils";
import { toast } from "react-toastify";
import {
  Notify,
  CustomNotificationStyled,
  StyledToastContainer
} from "./Notify";
import { fireEvent, waitFor } from "@testing-library/dom";

jest.mock("react-toastify", () => ({
  ...jest.requireActual("react-toastify"),
  toast: jest.fn()
}));

afterEach(cleanup);

describe("test notifications", () => {
  test("should render component with warning applied styles", () => {
    // arrange
    const Icon = () => (
      <span className="icon" data-testid="icon">
        icon
      </span>
    );

    // act
    const { getByTestId } = render(
      <CustomNotificationStyled type="warning">
        <Icon />
      </CustomNotificationStyled>
    );

    // assert
    const NotificationStyledElement = getByTestId("icon");
    expect(NotificationStyledElement).toHaveStyle("background: #cc0033");
    expect(NotificationStyledElement).toHaveStyle("color: #ffffff;");
  });

  test("should render component with default applied styles", () => {
    // arrange
    const Icon = () => (
      <span className="icon" data-testid="icon">
        icon
      </span>
    );

    // act
    const { getByTestId } = render(
      <CustomNotificationStyled>
        <Icon />
      </CustomNotificationStyled>
    );

    // assert
    const NotificationStyledElement = getByTestId("icon");
    expect(NotificationStyledElement).toHaveStyle("background: black");
    expect(NotificationStyledElement).toHaveStyle("color: white;");
  });

  test("should call notify function", () => {
    // arrange
    const mockToast = jest.fn();
    toast.mockImplementation(mockToast);
    const Icon = () => (
      <span className="icon" data-testid="icon">
        icon
      </span>
    );
    // act
    const { getByTestId } = render(
      <CustomNotificationStyled type="success">
        <Icon />
      </CustomNotificationStyled>
    );

    // assert
    const NotificationStyledElement = getByTestId("icon");
    expect(NotificationStyledElement).toHaveStyle("background: #00875A");
    expect(NotificationStyledElement).toHaveStyle("color: #ffffff;");
  });

  test("should call notify function by using Notify", async () => {
    // arrange
    const mockToast = jest.fn();
    toast.mockImplementation(jest.requireActual("react-toastify").toast);
    // act
    const { getByTestId } = render(
      <div>
        <StyledToastContainer />
        <button
          data-testid="test-fire-notification"
          onClick={() =>
            Notify({
              icon: "test",
              text: "test text",
              appName: "test name",
              type: "error"
            })
          }
        ></button>
      </div>
    );

    fireEvent.click(getByTestId("test-fire-notification"));

    // assert
    await waitFor(() => {
      expect(getByTestId("notify")).toBeInTheDocument();
      expect(getByTestId("notify-icon")).toHaveTextContent(/test/i);
      expect(getByTestId("notify-text")).toHaveTextContent(
        /test name test text/i
      );
      expect(getByTestId("notify-name-text")).toHaveTextContent(/test name/i);
    });
  });

  test("should call notify function by using Notify with default values", async () => {
    // arrange
    const mockToast = jest.fn();
    toast.mockImplementation(jest.requireActual("react-toastify").toast);
    // act
    const { getByTestId } = render(
      <div>
        <StyledToastContainer />
        <button
          data-testid="test-fire-notification"
          onClick={() => Notify({})}
        ></button>
      </div>
    );

    fireEvent.click(getByTestId("test-fire-notification"));

    // assert
    await waitFor(() => {
      expect(getByTestId("notify")).toBeInTheDocument();
      expect(getByTestId("notify-icon")).toHaveTextContent(/caution/i);
      expect(getByTestId("notify-text")).toHaveTextContent(/instrument name/i);
      expect(getByTestId("notify-name-text")).toHaveTextContent(
        /instrument name/i
      );
    });
  });
});
