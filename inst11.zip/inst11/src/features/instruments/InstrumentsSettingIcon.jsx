import React, { useState } from "react";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import { CustomSettingsOutlinedIcon } from "../instruments/addEditEquipment/AddEquipmentStyle";
import { CoverMenuItem } from "../instruments/addEditEquipment/AddEquipmentStyle";
import styled from "styled-components";
const IconStyle = styled.div`
  display: flex;
  padding-right: 10px;
`;
const InstrumentSettingIcon = ({
  name,
  setSelectColumn,
  setIsFilterModalOpen
}) => {
  const [anchorEl, setAnchorEl] = useState(null);

  const handleSettingClose = () => {
    setAnchorEl(null);
  };
  const handleSettingClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  return (
    <>
      <CustomSettingsOutlinedIcon
        data-testid="setting-icon-instrument"
        onClick={handleSettingClick}
      />
      <Menu
        data-testid="simple-menu"
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleSettingClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center"
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right"
        }}
      >
        <MenuItem
          data-testid="simple-menu-view_table"
          onClick={() => {
            setSelectColumn(true);
            setAnchorEl(null);
          }}
        >
          <IconStyle>
            <i className="one-icons">view_table</i>
          </IconStyle>
          Select Columns
        </MenuItem>
        <CoverMenuItem />
        <MenuItem
          data-testid="simple-menu-filter"
          onClick={() => {
            setIsFilterModalOpen(true);
            setAnchorEl(null);
          }}
        >
          <IconStyle>
            <i className="one-icons">filter</i>
          </IconStyle>
          Filters
        </MenuItem>
      </Menu>
    </>
  );
};
export default InstrumentSettingIcon;
