import React from "react";
import { render, cleanup, waitFor, fireEvent } from "@testing-library/react";
import Search from "./Search";

afterEach(cleanup);

describe("Search", () => {
  test("should clear input", async () => {
    jest.useFakeTimers("modern");
    const setQuery = jest.fn();
    const { getByTestId } = render(<Search setQuery={setQuery} />);
    const search = getByTestId("search");
    const searchInput = getByTestId("search").querySelector("input");
    expect(search).toBeDefined();
    fireEvent.change(searchInput, {
      target: { value: "text" }
    });
    jest.advanceTimersToNextTimer();
    jest.advanceTimersByTime(1000);
    expect(searchInput.value).toEqual("text");
    await waitFor(() => {
      expect(setQuery).toHaveBeenCalledWith("text");
    });
    fireEvent.click(getByTestId("clear-search-button"));
    jest.advanceTimersToNextTimer();
    jest.advanceTimersByTime(1000);
    await waitFor(() => {
      expect(searchInput.value).toEqual("");
      expect(setQuery).toHaveBeenCalledWith("");
    });
    jest.useRealTimers();
  });
});
