import { Button, ButtonGroup, makeStyles } from "@material-ui/core";
import { buttonStyles } from "./buttonStyles";
import { selectedStyles } from "./selectedStyles";

export const useStyles = makeStyles(() => ({
  button: buttonStyles,
  selected: selectedStyles
}));

const BooleanButtons = ({
  trueLabel,
  falseLabel,
  trueProps,
  falseProps,
  value,
  onChange,
  ...props
}) => {
  const classes = useStyles();
  return (
    <ButtonGroup disableElevation {...props}>
      <Button
        {...trueProps}
        variant={value && "contained"}
        onClick={() => {
          onChange(true);
        }}
        classes={{
          outlinedPrimary: classes.button,
          containedPrimary: classes.selected
        }}
      >
        {trueLabel}
      </Button>
      <Button
        {...falseProps}
        variant={!value && "contained"}
        onClick={() => {
          onChange(false);
        }}
        classes={{
          outlinedPrimary: classes.button,
          containedPrimary: classes.selected
        }}
      >
        {falseLabel}
      </Button>
    </ButtonGroup>
  );
};

export default BooleanButtons;
