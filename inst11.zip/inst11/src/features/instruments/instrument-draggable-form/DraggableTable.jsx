import React, { useState } from "react";
import Column from "./components/Column";
import { DragDropContext } from "react-beautiful-dnd";
import TopBar from "../TopBar";
import { Typography } from "@material-ui/core";
import { ModalContents } from "./DraggableTableStyle";
import { loadLastFilter } from "../../user/redux/actions";
import { withApollo } from "react-apollo";
import { compose } from "redux";
import { connect } from "react-redux";
import Notify from "../../notifications/Notify";
import { find } from "lodash";
import { emptyTableColumn, emptyHideTableColumn } from "../../../constants";

const TableTopBar = ({ setQuery }) => {
  return <TopBar setQuery={setQuery} label="Search for columns" />;
};

const DraggableTable = ({ setShowList, setHideList, lastFilter }) => {
  const lastFilterShowCol  = lastFilter?.showColumns ? lastFilter?.showColumns : emptyTableColumn;
  const lastFilterHideCol  = lastFilter?.hideColumns ? lastFilter?.hideColumns : emptyHideTableColumn;
  const allColumns = [...lastFilterShowCol, ...lastFilterHideCol];
  const defaultAllColumn = [...emptyTableColumn,...emptyHideTableColumn];
  const showColumns = allColumns.length !== defaultAllColumn.length ? emptyTableColumn : lastFilterShowCol;
  const hideColumns = allColumns.length !== defaultAllColumn.length ? emptyHideTableColumn : lastFilterHideCol;

  let showColData = showColumns.map((val) => {
    return val;
  });
  let hideColData = hideColumns.map((val) => {
    return val;
  });

  const initialColumns = {
    show: {
      id: "show",
      list: showColData
    },
    hidden: {
      id: "hidden",
      list: hideColData
    }
  };
  const filterData = (query) => {
    const re = RegExp(`.*${query.toLowerCase().split("").join(".*")}.*`);
    initialColumns.show.list = allColumns.filter(function (item) {
      return item?.val.toLowerCase().match(re) && item.show;
    });
    initialColumns.hidden.list = allColumns.filter(function (item) {
      return item?.val.toLowerCase().match(re) && !item.show;
    });
    setColumns((state) => ({
      ...state,
      show: initialColumns.show,
      hidden: initialColumns.hidden
    }));
  };

  const [columns, setColumns] = useState(initialColumns);
  const onDragEnd = (result) => {
    let { destination, source } = result;

    if (destination === null) {
      let dest = source.droppableId === "show" ? "hidden" : "show";
      destination = { index: 0, droppableId: dest };
    }

    // Make sure we're actually moving the item
    if (
      source.droppableId === destination.droppableId &&
      destination.index === source.index
    )
      return null;

    // Set start and end variables

    const start = columns[source.droppableId];
    const end = columns[destination.droppableId];

    // If start is the same as end, we're in the same column
    if (start === end) {
      // Move the item within the list
      // Start by making a new list without the dragged item
      const newList = start.list.filter((_, idx) => idx !== source.index);
      // Then insert the item at the right location
      newList.splice(destination.index, 0, start.list[source.index]);

      // Then create a new copy of the column object
      const newCol = {
        id: start.id,
        list: newList
      };
      // Update the state
      setColumns((state) => ({ ...state, [newCol.id]: newCol }));
    } else {
      // If start is different from end, we need to update multiple columns
      // Filter the start list like before
      const selectedShowLen = allColumns.filter(function (item) {
        return item.show;
      });
      if (source.droppableId === "show") {
        if (selectedShowLen.length === 1) {
          Notify({
            type: "warning",
            icon: "caution",
            appName: "",
            text: `Add one Column in Shown Column`
          });
          return null;
        }
      }
      const newStartList = start.list.filter((_, idx) => idx !== source.index);
      // Create a new start column
      const newStartCol = {
        id: start.id,
        list: newStartList
      };

      // Make a new end list array
      const newEndList = end.list;

      // Insert the item into the end list
      newEndList.splice(destination.index, 0, start.list[source.index]);

      // Create a new end column
      const newEndCol = {
        id: end.id,
        list: newEndList
      };

      const movedObj = find(allColumns, { val: result.draggableId });
      movedObj.show = !movedObj.show;

      // Update the state
      setColumns((state) => ({
        ...state,
        [newStartCol.id]: newStartCol,
        [newEndCol.id]: newEndCol
      }));
    }
    return null;
  };

  const showListData = [];
  const hideListData = [];

  columns?.show.list.forEach((item) => {
    item.show = true;
    showListData.push(item);
  });
  columns?.hidden.list.forEach((item) => {
    item.show = false;
    hideListData.push(item);
  });

  setShowList(showListData);
  setHideList(hideListData);

  return (
    <ModalContents>
      <Typography className="note">
        You can drag and drop the sections on the left to decide which columns
        you would like to show in the table and the order in which you would
        like them to appear.
      </Typography>
      <TableTopBar
        setQuery={(q) => {
          filterData(q);
        }}
      />
      <div className="dragdropcontextContainer">
        <DragDropContext onDragEnd={onDragEnd}>
          {Object.values(columns).map((col) => (
            <Column list={col.list} id={col.id} />
          ))}
        </DragDropContext>
      </div>
    </ModalContents>
  );
};

const mapStateToProps = (state) => ({
  lastFilter: state.user.lastFilter
});
export default compose(
  connect(mapStateToProps, {
    loadfilter: loadLastFilter
  }),
  withApollo
)(DraggableTable);
