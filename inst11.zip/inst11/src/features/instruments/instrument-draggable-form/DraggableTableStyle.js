import { Typography } from "@material-ui/core";
import { withStyles } from "@material-ui/styles";
import styled from "styled-components";

export const HideShowTypography = withStyles((theme) => ({
  root: {
    width: 250,
    fontSize: 14,
    color: "#333333 !important",
    borderBottom: "1px solid #d3d3d3",
    textAlign: "center",
    padding: "5px 0",
    marginBottom: 10
  }
}))(Typography);

export const ModalContents = styled.div`
  padding: 20px 16px;
  & > .note {
    font-size: 12px;
    padding-bottom: 10px;
  }
  & > .dragdropcontextContainer {
    position: relative;
    width: 100%;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    padding-top: 15px;
  }
`;

export const DraggableContainer = styled.div`
  & > .card {
    display: flex;
    width: 250px;
    font-size: 16px;
    margin-bottom: 8px;
    border: 1px solid #bababa;
    border-radius: 4px;
    padding: 2px 0;
    align-items: center;
  }
`;
