import React, { useState } from "react";
import Column from "./components/Column";
import { DragDropContext } from "react-beautiful-dnd";
import TopBar from "../TopBar";
import { Typography } from "@material-ui/core";
import { ModalContents } from "./DraggableTableStyle";
import { loadLastFilter } from "../../user/redux/actions";

import { withApollo } from "react-apollo";
import { compose } from "redux";
import { connect } from "react-redux";
import Notify from "../../notifications/Notify";
import { find } from "lodash";
import { emptyTableColumn, emptyHideTableColumn } from "../../../constants";
import { render, cleanup, fireEvent } from "../../../test-utils";
import DraggableTable from './DraggableTable';

afterEach(cleanup);

// const TableTopBar = ({ setQuery }) => {
//   return <TopBar setQuery={setQuery} label="Search for columns" />;
// };


// var setShowList = function(){
     
//        alert('fired y');
//   };
     
//   var setHideList = function(){
     
//     alert('fired y');
// };
var setShowList;
   var setHideList ;
//DraggableTable = ({ setShowList, setHideList, lastFilter });


 var lastFilter;
const showListData = [];
const hideListData = [];

//setShowList(showListData);
//setHideList(hideListData);

// //var DraggableTable = ({ setShowList, setHideList, lastFilter }) => {
//     const lastFilterShowCol  = lastFilter?.showColumns ? lastFilter?.showColumns : emptyTableColumn;
//     const lastFilterHideCol  = lastFilter?.hideColumns ? lastFilter?.hideColumns : emptyHideTableColumn;
//     const allColumns = [...lastFilterShowCol, ...lastFilterHideCol];
//     const defaultAllColumn = [...emptyTableColumn,...emptyHideTableColumn];
//     const showColumns = allColumns.length !== defaultAllColumn.length ? emptyTableColumn : lastFilterShowCol;
//     const hideColumns = allColumns.length !== defaultAllColumn.length ? emptyHideTableColumn : lastFilterHideCol;
// //}  

// let showColData = showColumns.map((val) => {
//     return val;
//   });
//   let hideColData = hideColumns.map((val) => {
//     return val;
//   });

//   const initialColumns = {
//     show: {
//       id: "show",
//       list: showColData
//     },
//     hidden: {
//       id: "hidden",
//       list: hideColData
//     }
//   };
   
  

//   const [columns, setColumns] = useState(initialColumns);
//   const onDragEnd = (result) => {
//     let { destination, source } = result;

//     if (destination === null) {
//       let dest = source.droppableId === "show" ? "hidden" : "show";
//       destination = { index: 0, droppableId: dest };
//     }
// }
  
//   columns?.show.list.forEach((item) => {
//     item.show = true;
//     showListData.push(item);
//   });
//   columns?.hidden.list.forEach((item) => {
//     item.show = false;
//     hideListData.push(item);
//   });

//   const filterData = (query) => {
//     const re = RegExp(`.*${query.toLowerCase().split("").join(".*")}.*`);
//     initialColumns.show.list = allColumns.filter(function (item) {
//       return item?.val.toLowerCase().match(re) && item.show;
//     });
//     initialColumns.hidden.list = allColumns.filter(function (item) {
//       return item?.val.toLowerCase().match(re) && !item.show;
//     });
//     setColumns((state) => ({
//       ...state,
//       show: initialColumns.show,
//       hidden: initialColumns.hidden
//     }));
//   };
 
test("should create with table mock", () => {
    const { queryByTestId } = render(<DraggableTable />);
    expect(queryByTestId("instrument-table-draggable-table")).toBeDefined();
});
test("should create with drag drop", () => {
    const { queryByTestId } = render(<DraggableTable />);
    expect(queryByTestId("instrument-table-drag-drop")).toBeDefined();
});
test("should create with dragdrop", () => {
    const { queryByTestId } = render(<Typography> <ModalContents /> </Typography>);
    expect(queryByTestId("instrument-table-drag-drop")).toBeDefined();
    expect(queryByTestId("instrument-table-draggable-table")).toBeDefined();
});
