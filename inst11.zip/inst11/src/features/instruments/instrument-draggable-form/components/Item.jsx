import React from "react";
import { Draggable } from "react-beautiful-dnd";
import DragIndicatorIcon from "@material-ui/icons/DragIndicator";
import { IconButton } from "@material-ui/core";

const Item = ({ key, text, index }) => {
  return (
    <Draggable draggableId={text} index={index} data-testid="inst-draggableId">
      {(provided) => (
        <>
          <div data-testid="instrument-draggableId" 
            ref={provided.innerRef}
            {...provided.draggableProps}
            {...provided.dragHandleProps}
            className="card"
          >
            <IconButton data-testid="instrument-icon-button">
              <DragIndicatorIcon className="icon" data-testid="instrument-ind-icon"/>
            </IconButton>
            <div>{text}</div>
          </div>
        </>
      )}
    </Draggable>
  );
};

export default Item;
