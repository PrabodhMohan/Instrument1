import React from "react";
import { Draggable } from "react-beautiful-dnd";
import { IconButton } from "@material-ui/core";
import { render, cleanup, fireEvent } from "../../../../test-utils";
import DragIndicatorIcon from "@material-ui/icons/DragIndicator";
import { DraggableContainer, HideShowTypography } from "../DraggableTableStyle";
import { store } from "../../../../store";
import { Provider } from "react-redux";
import item from './Item'


afterEach(cleanup);

jest.mock("../../../notifications/Notify");
jest.mock("aws-amplify");
jest.mock("../../../../utils/signout");

const TestComponent = () => {
  const onSubmit = jest.fn();
  const setFieldValue = jest.fn();
  return (
         <Provider store={store}>
          
      </Provider>
    );
};

 
describe("item", () => {
test("should create filter action", () => {
    const { queryByTestId } = render( 
      < TestComponent/> 
      );
    expect(queryByTestId("instrument-draggableId")).toBeDefined();
}); 
test("should create draggable action", () => {
    const { queryByTestId } = render( 
      //   <Provider  store={store} >
      //    < Draggable/> 
      // </Provider>
      < TestComponent/> 

      );
    expect(queryByTestId("inst-draggableId")).toBeDefined();
}); 
test("should create icon  button", () => {
    const { queryByTestId } = render( 
      // < IconButton/> 
      < TestComponent/> 

      );
    expect(queryByTestId("instrument-icon-button")).toBeDefined();
});
test("should create drag icon indicator", () => {
    const { queryByTestId } = render( 
      // < DragIndicatorIcon/> 

      < TestComponent/> 
      );
    expect(queryByTestId("instrument-ind-icon")).toBeDefined();
});
 

});
