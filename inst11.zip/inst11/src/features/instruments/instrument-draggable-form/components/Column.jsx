import React from "react";
import Item from "./Item";
import { Droppable } from "react-beautiful-dnd";
import { DraggableContainer, HideShowTypography } from "../DraggableTableStyle";

const Column = ({ list, id }) => {
  return (
    <Droppable droppableId={id}>
      {(provided) => (
        <div>
          <HideShowTypography data-testid="instrument-hide-show">
            {id === "show" ? "Shown columns" : "Hidden columns"}
          </HideShowTypography>
          <DraggableContainer data-testid="instrument-draggable"
            {...provided.droppableProps}
            ref={provided.innerRef}
          >
            {list.map((text, index) => (
              <Item key={text?.key} text={text?.val} index={index} />
            ))}
            {provided.placeholder}
          </DraggableContainer>
          {id === "show" ? (
            <span
              style={{
                position: "absolute",
                top: 30,
                bottom: 0,
                width: 1,
                backgroundColor: "#d3d3d3",
                left: "50%",
                transform: "translateX(-50%)"
              }}
            ></span>
          ) : (
            ""
          )}
        </div>
      )}
    </Droppable>
  );
};

export default Column;
