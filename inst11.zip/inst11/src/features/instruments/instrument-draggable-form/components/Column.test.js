import React from "react";
import { IconButton } from "@material-ui/core";
import { render, cleanup, fireEvent } from "../../../../test-utils";
import item from    './item';
import Item from "./Item";
import { Droppable } from "react-beautiful-dnd";
import { DraggableContainer, HideShowTypography } from "../DraggableTableStyle";
import { store } from "../../../../store";
import {Provider} from "react-redux";

  


afterEach(cleanup);

jest.mock("../../../notifications/Notify");
jest.mock("aws-amplify");
jest.mock("../../../../utils/signout");
const TestComponent = () => {
   const onSubmit = jest.fn();
   const setFieldValue = jest.fn();
   return (
        <Provider store={store}>
       </Provider>
    );
 };


 describe("columns", () => {
   // it("should render successfully - base", async () => {
   //   const { getByTestId } = render(<TestComponent />);
 
   //   await waitFor(() =>
   //     expect(getByTestId("text-field-softwareVersion")).toBeInTheDocument()
   //   );
   // }); 

test("should create filter action", () => {
    const { queryByTestId } = render( 
      < TestComponent/> 
      );
     expect(queryByTestId("instrument-hide-show")).toBeDefined();
}); 
test("should create draggable action", () => {
    const { queryByTestId } = render( 
           < TestComponent/> 
        );
    expect(queryByTestId("instrument-draggable")).toBeDefined();
 });
 test("should create droppable action", () => {
    const { queryByTestId } = render( 
      // <Provider  store={store}>
      // < Droppable/> 
      // </Provider>
      < TestComponent/> 
      );
     expect(queryByTestId("instrument-hide-show")).toBeDefined();
}); 
// test("should create icon  button", () => {
//     const { queryByTestId } = render( 
//       < IconButton/> 
//       );
//     expect(queryByTestId("instrument-icon-button")).toBeDefined();
// });
// test("should create drag icon indicator", () => {
//     const { queryByTestId } = render( 
//       < DragIndicatorIcon/> 
//       );
//     expect(queryByTestId("instrument-ind-icon")).toBeDefined();
// 
test("should create droppable action", () => {
   const { queryByTestId } = render( 
     // <Provider  store={store}>
     // < Droppable/> 
     // </Provider>
     < HideShowTypography/> 
     );
    expect(queryByTestId("instrument-hide-show")).toBeDefined();
}); 
});