import { render, cleanup } from "../../test-utils";
import InstrumentsMainPage from "./InstrumentsMainPage";

jest.mock("./InstrumentsTable");

afterEach(cleanup);

test("should create with table mock", () => {
  const { queryByTestId } = render(<InstrumentsMainPage />);
  expect(queryByTestId("instruments-table")).toBeDefined();
});
