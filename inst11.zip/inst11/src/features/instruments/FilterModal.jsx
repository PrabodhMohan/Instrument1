import React from "react";
import styled from "styled-components";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import Dialog from "@material-ui/core/Dialog";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import MuiDialogContent from "@material-ui/core/DialogContent";
import { IconButton } from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import FilterForm from "./FilterForm";
import FilterAction from "./FilterAction";
import { connect } from "react-redux";
import { compose, withApollo } from "react-apollo";
import { UPDATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE_PERSONAL_FIELDS } from "../../gql/landingapi/mutations";

import {
  loadInstruments as loadInstrumentsAction,
  updateInstrumentFilter as updateInstrumentFilterAction,
  updatePageTokenArray as updatePageTokenArrayAction,
  updateFilterApplied as updateFilterAppliedAction,
  updateNextToken as updateNextTokenAction,
  updateLoading as updateLoadingAction
} from "./redux/actions";
import { loadUserInfo as loadUserInfoAction } from "../user/redux/actions";
import Notify from "../notifications/Notify";
import { emptyFilter } from "../../constants";
import {
  getFilterObject,
  getfilterInstrumentList
} from "../../utils/helpers/filtersAndPagination";
const styles = (theme) => ({
  root: {
    margin: 0,
    padding: `20px 0 20px 16px`,
    borderBottom: "1px solid #D3D3D3"
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});
const ModalTitle = styled.div`
  font-size: 16px;
  font-weight: 500;
  line-height: 19px;
  color: #333333;
`;
const DialogTitle = withStyles(styles)((props) => {
  const { children, classes, onClose, ...other } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root} {...other}>
      <ModalTitle>{children}</ModalTitle>
      {onClose ? (
        <IconButton
          aria-label="close"
          className={classes.closeButton}
          onClick={onClose}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});

const DialogContent = withStyles((theme) => ({
  root: {
    padding: `${theme.spacing(0)}px ${theme.spacing(0)}px`,
    backgroundColor: "#ffffff"
  }
}))(MuiDialogContent);

const DialogForm = styled.form`
  max-height: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
`;

const useStyles = makeStyles(() => ({
  dialog: {
    width: 617
  },
  backdrop: {
    zIndex: 2000,
    position: "absolute"
  }
}));

const FilterModal = ({
  isFilterModalOpen,
  setIsFilterModalOpen,
  filters,
  user,
  client,
  updateInstrumentFilter,
  loadUserInfo,
  loadInstruments,
  groupList,
  categoryList,
  manufacturerList,
  responsiblePersonList,
  siteList,
  updatePageTokenArray,
  limit,
  updateFilterApplied,
  updateNextToken,
  search,
  updateLoading
}) => {
  const classes = useStyles();
  const clearAll = () => {
    updateInstrumentFilter(emptyFilter);
  };
  const resetToDefault = () => {
    if (user?.lastFilter) {
      try {
        user.lastFilter = JSON.parse(user?.lastFilter);
      } catch (error) {}
      updateInstrumentFilter(user?.lastFilter?.selectedFilters);
    }
  };
  const saveAsDefault = async () => {
    user.lastFilter = {
      ...user.lastFilter,
      selectedFilters: { ...filters }
    };
    user.lastFilter = JSON.stringify(user.lastFilter);

    const result = await updateLastFilter(user);

    if (result) {
      if (result?.lastFilter) {
        try {
          user.lastFilter = JSON.parse(user.lastFilter);
        } catch (error) {}
        loadUserInfo(user);
        updateInstrumentFilter(user.lastFilter?.selectedFilters ?? emptyFilter);
      }
      Notify({
        type: "success",
        icon: "yes",
        appName: "",
        text: `Saved default filter successfully! `
      });
    } else {
      Notify({
        type: "warning",
        icon: "caution",
        appName: "",
        text: `Saved default filter failed! `
      });
    }
  };
  const applyFilter = async () => {
    updateLoading(true);
    const filterObject = getFilterObject({
      filters,
      search,
      groupList,
      categoryList,
      siteList,
      manufacturerList,
      responsiblePersonList
    });

    let instrumentList = [];
    let keepFetching = true;
    let recursiveNextToken = null;

    do {
      const localLimit = limit - instrumentList.length;
      if (localLimit === 0) {
        keepFetching = false;
        break;
      }
      const variables = {
        limit: limit,
        nextToken: recursiveNextToken,
        filter: filterObject
      };
      const { nextToken: latestNextToken, items: result } =
        await getfilterInstrumentList({ client, variables });
      instrumentList.push(...result);
      recursiveNextToken = latestNextToken;
      keepFetching = latestNextToken !== null;
    } while (keepFetching);
    loadInstruments({
      instruments: instrumentList ? instrumentList : []
    });
    updateFilterApplied(true);
    updatePageTokenArray({ pageIndex: 0, token: null });
    updateNextToken(recursiveNextToken ?? null);
    onCancel();
    updateLoading(false);
  };

  const updateLastFilter = async (data) => {
    try {
      const result = await client.mutate({
        mutation: UPDATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE_PERSONAL_FIELDS,
        variables: {
          ...data
        },
        fetchPolicy: "no-cache"
      });
      return result?.data?.updateDigitalLabInstrumentRepositoryUserProfile;
    } catch (error) {
      return null;
    }
  };

  const onCancel = () => setIsFilterModalOpen(false);
  return (
    <Dialog
      classes={{
        paper: classes.dialog
      }}
      onClose={onCancel}
      open={isFilterModalOpen}
      data-testid="modal-for-instrument-editing"
    >
      <DialogForm data-testid="instrument-repositorium-modal-form" noValidate>
        <DialogTitle
          data-testid="instrument-repositorium-modal-title"
          onClose={onCancel}
        >
          Filter equipment
        </DialogTitle>

        <FilterAction
          onCancel={onCancel}
          position="header"
          clearAll={clearAll}
          resetToDefault={resetToDefault}
          saveAsDefault={saveAsDefault}
        />
        <DialogContent data-testid="instrument-repositorium-modal-content">
          <FilterForm position="footer" />
        </DialogContent>
        <FilterAction
          onCancel={onCancel}
          applyFilter={applyFilter}
          position="footer"
        />
      </DialogForm>
    </Dialog>
  );
};

const mapStateToProps = (state) => ({
  groupList: state.instruments?.groupList,
  manufacturerList: state.instruments?.manufacturerList,
  categoryList: state.instruments?.categoryList,
  responsiblePersonList: state.instruments?.responsiblePersonList,
  siteList: state.user?.sites ?? [],
  filters: state.instruments?.filters,
  search: state.instruments?.search,
  user: state.user,
  limit: state.instruments?.limit
});

export default compose(
  connect(mapStateToProps, {
    updateInstrumentFilter: updateInstrumentFilterAction,
    loadUserInfo: loadUserInfoAction,
    loadInstruments: loadInstrumentsAction,
    updatePageTokenArray: updatePageTokenArrayAction,
    updateFilterApplied: updateFilterAppliedAction,
    updateNextToken: updateNextTokenAction,
    updateLoading: updateLoadingAction
  }),
  withApollo
)(FilterModal);
