import { Auth } from "aws-amplify";
import { waitFor } from "@testing-library/react";
import { render, cleanup, fireEvent } from "../../test-utils";
import LoadInstrumentInfo from "./LoadInstrumentsInfo";
import { signOut } from "../../utils/signout";
import {
  LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
  LIST_SITES,
  USER_BY_EMAIL
} from "../../gql/landingapi/queries";
import { INSTRUMENT_REPOSITORY_ADMIN } from "../../constants";
import {
  CREATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE,
  UPDATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE_PERSONAL_FIELDS
} from "../../gql/landingapi/mutations";
import Notify from "../notifications/Notify";
import { Button, Typography } from "@material-ui/core";
 

 
jest.mock("../notifications/Notify");
jest.mock("aws-amplify");
jest.mock("../../utils/signout");
afterEach(cleanup);
 
test("LoadInstrumentInfo should display loading", () => {
  const { getByTestId } = render(<LoadInstrumentInfo />);
  expect(getByTestId("loading")).toBeDefined();
});
test("LoadInstrumentInfo should display generic error", async () => {
  Auth.currentAuthenticatedUser.mockRejectedValueOnce();
  const { getByTestId } = render(<LoadInstrumentInfo />);
  await waitFor(() => expect(getByTestId("message-error")).toBeDefined());
});
test("LoadInstrumentInfo should display error then retry then sign out", async () => {
  const { getByTestId } = render(<LoadInstrumentInfo />);
  const tryAgainButton = await waitFor(() => getByTestId("try-again-button"));
  fireEvent.click(tryAgainButton);
  await waitFor(() => expect(getByTestId("loading")).toBeDefined());
  const signOutButton = await waitFor(() => getByTestId("signout-button"));
  fireEvent.click(signOutButton);
  expect(signOut).toHaveBeenCalled();
});
test("11LoadInstrumentInfo  load data and display children", async () => {
  Auth.currentAuthenticatedUser.mockResolvedValue({
    signInUserSession: {
      accessToken: {
        payload: { "cognito:groups": ["InstrumentRepositoryAdmin"] }
      },
      idToken: {
        payload: {
          preferred_username: "Elliot",
          "custom:firstName": "",
          "custom:lastName": "Doe",
          "custom:phoneNumber": "987654321"
        }
      }
    },
    attributes: {
      email: "test@testmail.com"
    }
  });
  const graphqlInstruments = [
    {
      siteName: "siteName",
      siteTimezone: "timezone",
      softwareVersion: "oiiio",
      belongingToGroup: "tftf",
      buildingLocation: {
        isSynchronized: true,
        value: "90"
      },
      configurationBaseline: "oioioi",
      dateOfLastMaintanance: {
        isSynchronized: true,
        value: "2021-06-21"
      },
      dateOfNextMaintanance: {
        isSynchronized: true,
        value: "2021-06-16"
      },
      floorAndRoomLocation: {
        isSynchronized: true,
        value: "70.70-3"
      },
      installedTests: [],
      instrumentGTIN: {
        isSynchronized: true,
        value: "jujujujuj"
      },
      instrumentGxPStatus: {
        isSynchronized: true,
        value: "tffttf"
      },
      instrumentName: {
        isSynchronized: true,
        value: "TEST.456"
      },
      instrumentRUDI: "jujjuju",
      instrumentType: {
        isSynchronized: false,
        value: "456"
      },
      isBookable: true,
      isVisualized: true,
      materialNumber: "ggggguuu",
      qualificationDocuments: {
        isSynchronized: false,
        value: []
      },
      responsiblePerson: {
        isSynchronized: false,
        value: "ioi"
      },
      serialNumber: "jujujuju",
      systemStatus: {
        isSynchronized: true,
        value: "yggygyy"
      },
      equipmentId: {
        isSynchronized: false,
        value: ""
      },
      secondResponsiblePerson: {
        isSynchronized: false,
        value: ""
      },
      manufacturer: {
        isSynchronized: false,
        value: ""
      }
    }
  ];
  const { getByTestId, store } = render(
    <LoadInstrumentInfo>
      <div data-testid="test">test</div>
    </LoadInstrumentInfo>,
    {
      mocksForApollo: [
        {
          request: {
            query: USER_BY_EMAIL,
            variables: {
              email: "test@testmail.com"
            }
          },
          result: {
            data: {
              userByEmail: {
                items: [
                  {
                    id: "test",
                    email: "test@testmail.com",
                    familyName: "Doe",
                    givenName: "",
                    name: "Elliot",
                    phone: "987654321",
                    status: "",
                    site: "site1",
                    user: "",
                    lastFilter: ""
                  }
                ]
              }
            }
          }
        },
        {
          request: {
            query: LIST_SITES,
            variables: {
              nextToken: null
            }
          },
          result: {
            data: {
              listSites: {
                items: [],
                nextToken: null
              }
            }
          }
        },
        {
          request: {
            query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
            variables: {
              limit: 1000,
              nextToken: null
            }
          },
          result: {
            data: {
              listDigitalLabInstrumentRepositoryEntrys: {
                items: graphqlInstruments,
                nextToken: null
              }
            }
          }
        }
      ]
    }
  );
 
});


test("LoadInstrumentInfo load  with empty data and display children", async () => {
  Auth.currentAuthenticatedUser.mockResolvedValue({
    signInUserSession: {
      accessToken: {
        payload: { "cognito:groups": ["InstrumentRepositoryAdmin"] }
      },
      idToken: {
        payload: {
          preferred_username: "Elliot",
          "custom:firstName": "",
          "custom:lastName": "Doe",
          "custom:phoneNumber": "987654321"
        }
      }
    },
    attributes: {
      email: "test@testmail.com"
    }
  });

  const { getByTestId, store } = render(
    <LoadInstrumentInfo>
      <div data-testid="test">test</div>
    </LoadInstrumentInfo>,
    {
      mocksForApollo: [
        {
          request: {
            query: USER_BY_EMAIL,
            variables: {
              email: "test@testmail.com"
            }
          },
          result: {
            data: {
              userByEmail: {
                items: [
                  {
                    id: "test",
                    email: "test@testmail.com",
                    familyName: "Doe",
                    givenName: "",
                    name: "Elliot",
                    phone: "987654321",
                    status: "",
                    site: "site1",
                    user: "",
                    lastFilter: ""
                  }
                ]
              }
            }
          }
        },
        {
          request: {
            query: LIST_SITES,
            variables: {}
          },
          result: {
            data: {
              listSites: {
                items: []
              }
            }
          }
        },
        {
          request: {
            query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
            variables: {}
          },
          result: {
            data: {
              listDigitalLabInstrumentRepositoryEntrys: {
                items: undefined,
                __typename: "ModelDigitalLabInstrumentRepositoryEntryConnection"
              }
            }
          }
        }
      ]
    }
  ); 
});


test("LoadInstrumentInfo should create profile, load data and display children", async () => {
  const siteAttr = "site1";
  Auth.currentAuthenticatedUser.mockResolvedValue({
    signInUserSession: {
      accessToken: {
        payload: { "cognito:groups": [INSTRUMENT_REPOSITORY_ADMIN] }
      },
      idToken: {
        payload: {
          "custom:firstName": "Doe",
          "custom:lastName": "",
          preferred_username: "john",
          "custom:phoneNumber": "123456789",
          "custom:site": siteAttr
        }
      }
    },
    attributes: {
      email: "test@testmail.com"
    }
  });

  const { getByTestId, store } = render(
    <LoadInstrumentInfo>
      <div data-testid="test">test</div>
    </LoadInstrumentInfo>,
    {
      mocksForApollo: [
        {
          request: {
            query: USER_BY_EMAIL,
            variables: {
              email: "test@testmail.com"
            }
          },
          result: {
            data: {
              userByEmail: {
                items: []
              }
            }
          }
        },
        {
          request: {
            query: CREATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE,
            variables: {
              email: "test@testmail.com",
              givenName: "Doe",
              familyName: "",
              name: "john",
              phone: "123456789",
              lastFilter: "",
              site: siteAttr
            }
          },
          result: {
            data: {
              createDigitalLabInstrumentRepositoryUserProfile: {
                id: "test",
                email: "test@testmail.com",
                site: siteAttr,
                familyName: "",
                givenName: "Doe",
                name: "john",
                user: "",
                phone: "123456789",
                lastFilter: ""
              }
            }
          }
        }
      ]
    }
  );
 
});

test("LoadInstrumentInfo should update profile when even if it not completed, rewrite assigned site to user, load data and display children", async () => {
  const siteAttr = "site1";
  Auth.currentAuthenticatedUser.mockResolvedValue({
    signInUserSession: {
      accessToken: {
        payload: { "cognito:groups": [INSTRUMENT_REPOSITORY_ADMIN] }
      },
      idToken: {
        payload: {
          preferred_username: "mike",
          "custom:site": siteAttr
        }
      }
    },
    attributes: {
      email: "test@testmail.com"
    }
  });

  const { getByTestId, store } = render(
    <LoadInstrumentInfo>
      <div data-testid="test">test</div>
    </LoadInstrumentInfo>,
    {
      mocksForApollo: [
        {
          request: {
            query: USER_BY_EMAIL,
            variables: {
              email: "test@testmail.com"
            }
          },
          result: {
            data: {
              userByEmail: {
                items: [
                  {
                    id: "test",
                    email: "test@testmail.com",
                    familyName: "",
                    givenName: "",
                    name: "Elliot",
                    phone: "987654321",
                    status: "",
                    site: "",
                    user: "",
                    lastFilter: ""
                  }
                ]
              }
            }
          }
        },
        {
          request: {
            query: UPDATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE_PERSONAL_FIELDS,
            variables: {
              id: "test",
              email: "test@testmail.com",
              givenName: "",
              familyName: "",
              name: "mike",
              phone: "",
              lastFilter: "",
              site: siteAttr
            }
          },
          result: {
            data: {
              updateDigitalLabInstrumentRepositoryUserProfile: {
                id: "test",
                email: "test@testmail.com",
                site: siteAttr,
                familyName: "",
                givenName: "",
                name: "john",
                user: "",
                phone: "",
                lastFilter: ""
              }
            }
          }
        }
      ]
    }
  );
 
});

test("LoadBookingInstrumentInfo should not update profile when data not changed, load data and display children", async () => {
  const siteAttr = "site1";
  Auth.currentAuthenticatedUser.mockResolvedValue({
    signInUserSession: {
      accessToken: {
        payload: { "cognito:groups": [INSTRUMENT_REPOSITORY_ADMIN] }
      },
      idToken: {
        payload: {
          preferred_username: "Elliot",
          "custom:firstName": "",
          "custom:lastName": "Doe",
          "custom:phoneNumber": "987654321",
          "custom:site": siteAttr
        }
      }
    },
    attributes: {
      email: "test@testmail.com"
    }
  });

  const { getByTestId, store } = render(
    <LoadInstrumentInfo>
      <div data-testid="test">test</div>
    </LoadInstrumentInfo>,
    {
      mocksForApollo: [
        {
          request: {
            query: USER_BY_EMAIL,
            variables: {
              email: "test@testmail.com"
            }
          },
          result: {
            data: {
              userByEmail: {
                items: [
                  {
                    id: "test",
                    email: "test@testmail.com",
                    familyName: "Doe",
                    givenName: "",
                    name: "Elliot",
                    phone: "987654321",
                    status: "",
                    site: siteAttr,
                    user: "",
                    lastFilter: ""
                  }
                ]
              }
            }
          }
        }
      ]
    }
  );
 });

 
test("LoadBookingInstrumentInfo should display info about not configured site location", async () => {
  Auth.currentAuthenticatedUser.mockResolvedValue({
    signInUserSession: {
      accessToken: {
        payload: { "cognito:groups": [INSTRUMENT_REPOSITORY_ADMIN] }
      },
      idToken: {
        payload: {
          preferred_username: "Elliot",
          "custom:firstName": "",
          "custom:lastName": "Doe",
          "custom:phoneNumber": "987654321",
          "custom:site": ""
        }
      }
    },
    attributes: {
      email: "test@testmail.com"
    }
  });

  const { getByTestId } = render(
    <LoadInstrumentInfo>
      <div data-testid="test">test</div>
    </LoadInstrumentInfo>,
    {
      mocksForApollo: [
        {
          request: {
            query: USER_BY_EMAIL,
            variables: {
              email: "test@testmail.com"
            }
          },
          result: {
            data: {
              userByEmail: {
                items: [
                  {
                    id: "test",
                    email: "test@testmail.com",
                    familyName: "Doe",
                    givenName: "",
                    name: "Elliot",
                    phone: "987654321",
                    status: "",
                    site: "",
                    user: "",
                    lastFilter: ""
                  }
                ]
              }
            }
          }
        }
      ]
    }
  );

  await waitFor(() => {
    expect(getByTestId("message-error").textContent).toBe(
      "You do not have site location assigned. Go to the Landing Page to configure this."
    );
  });
});

 
test("should create filter action on signout", () => {
    const { queryByTestId } = render( 
      < Button/>     );
    expect(queryByTestId("signout-button")).toBeDefined();
});
 

