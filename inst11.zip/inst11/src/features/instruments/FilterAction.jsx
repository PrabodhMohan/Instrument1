import React, { useEffect, useState } from "react";
import styled, { css } from "styled-components";
import { withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import MuiDialogActions from "@material-ui/core/DialogActions";
import { connect } from "react-redux";
import { emptyFilter } from "../../constants";
import { isEqual } from "underscore";
import ClearAllIcon from "@material-ui/icons/ClearAll";

const actionOutlinedStyles = css`
  background-color: #fafafa;
  border: 1px solid #bababa;
`;

export const ActionbuttonStyled = styled(Button)`
  && {
    text-transform: capitalize;
    ${(props) =>
      props.variant && props.variant === "outlined" && actionOutlinedStyles}
  }
`;

const DialogActions = withStyles(() => ({
  root: {
    margin: 0,
    padding: "20px 16px 16px 16px"
  }
}))(MuiDialogActions);

const FilterAction = ({
  onCancel,
  position,
  clearAll,
  resetToDefault,
  saveAsDefault,
  applyFilter,
  filters,
  user
}) => {
  const [disableClearAll, setDisableClearAll] = useState(false);
  const [disableResetToDefault, setDisableResetToDefault] = useState(false);
  const [disableSaveAsDefault, setDisableSaveAsDefault] = useState(false);
  const [disableConfirm, setDisableConfirm] = useState(false);

  useEffect(() => {
    setDisableClearAll(isEqual(filters, emptyFilter));
    setDisableResetToDefault(
      isEqual(filters, user.lastFilter?.selectedFilters)
    );
    setDisableSaveAsDefault(isEqual(filters, user.lastFilter?.selectedFilters));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]);

  return (
    <DialogActions data-testid="instrument-repositorium-modal-action-buttons">
      {position === "header" ? (
        <>
          <ActionbuttonStyled
            data-testid="instrument-repositorium-modal-action-button-confirm"
            variant="contained"
            color="primary"
            startIcon={<ClearAllIcon />}
            onClick={clearAll}
            disabled={disableClearAll}
          >
            Clear all
          </ActionbuttonStyled>
          <ActionbuttonStyled
            data-testid="instrument-repositorium-modal-action-button-confirm"
            variant="contained"
            color="primary"
            startIcon={<i className="one-icons">reset</i>}
            onClick={resetToDefault}
            disabled={disableResetToDefault}
          >
            Reset to default
          </ActionbuttonStyled>
          <ActionbuttonStyled
            data-testid="instrument-repositorium-modal-action-button-confirm"
            autoFocus
            variant="contained"
            color="primary"
            startIcon={<i className="one-icons">save</i>}
            onClick={saveAsDefault}
            disabled={disableSaveAsDefault}
          >
            Save as default
          </ActionbuttonStyled>
        </>
      ) : (
        <>
          <ActionbuttonStyled
            data-testid="instrument-repositorium-modal-action-button-cancel"
            variant="outlined"
            onClick={onCancel}
            color="primary"
            style={{ marginRight: 14 }}
          >
            Cancel
          </ActionbuttonStyled>
          <ActionbuttonStyled
            data-testid="instrument-repositorium-modal-action-button-confirm"
            autoFocus
            variant="contained"
            disabled={disableConfirm}
            color="primary"
            onClick={() => {
              setDisableConfirm(true);
              applyFilter();
            }}
          >
            Confirm
          </ActionbuttonStyled>
        </>
      )}
    </DialogActions>
  );
};

const mapStateToProps = (state) => ({
  filters: state.instruments?.filters,
  user: state.user
});
export default connect(mapStateToProps)(FilterAction);
