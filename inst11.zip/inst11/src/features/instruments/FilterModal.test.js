 
import React, { useEffect, useState } from "react";
import styled from "styled-components";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import Dialog from "@material-ui/core/Dialog";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import MuiDialogContent from "@material-ui/core/DialogContent";
import { IconButton } from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import FilterForm from "./FilterForm";
import FilterAction from "./FilterAction";
import { connect } from "react-redux";
import { compose, withApollo } from "react-apollo";
import { UPDATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE_PERSONAL_FIELDS } from "../../gql/landingapi/mutations";
import { render, cleanup, waitFor } from "@testing-library/react";
import { ThemeProvider, theme } from "@material-ui/core/styles";

import {
  loadInstruments as loadInstrumentsAction,
  updateInstrumentFilter as updateInstrumentFilterAction,
  updatePageTokenArray as updatePageTokenArrayAction,
  updateFilterApplied as updateFilterAppliedAction,
  updateNextToken as updateNextTokenAction,
  updateLoading as updateLoadingAction
} from "./redux/actions";
import { loadUserInfo as loadUserInfoAction } from "../user/redux/actions";
import Notify from "../notifications/Notify";
import { emptyFilter } from "../../constants";
import {
  getFilterObject,
  getfilterInstrumentList
} from "../../utils/helpers/filtersAndPagination";
import FilterModal from './FilterModal'


const styles = (theme) => ({
  root: {
    margin: 0,
    padding: `20px 0 20px 16px`,
    borderBottom: "1px solid #D3D3D3"
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});
const ModalTitle = styled.div`
  font-size: 16px;
  font-weight: 500;
  line-height: 19px;
  color: #333333;
`;

  const DialogTitle = withStyles(styles)((props) => {
    const { children, classes, onClose, ...other } = props;
    return (
      <MuiDialogTitle disableTypography className={classes.root} {...other}>
        <ModalTitle>{children}</ModalTitle>
        {onClose ? (
          <IconButton
            aria-label="close"
            className={classes.closeButton}
            onClick={onClose}
          >
            <CloseIcon />
          </IconButton>
        ) : null}
      </MuiDialogTitle>
    );
  });
  
  const DialogContent = withStyles((theme) => ({
    root: {
      padding: `${theme.spacing(0)}px ${theme.spacing(0)}px`,
      backgroundColor: "#ffffff"
    }
  }))(MuiDialogContent);
  
  const DialogForm = styled.form`
    max-height: 100%;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  `;
  
  const useStyles = makeStyles(() => ({
    dialog: {
      width: 617
    },
    backdrop: {
      zIndex: 2000,
      position: "absolute"
    }
  }));
  
  const resetToDefault = () => {
    if (user?.lastFilter) {
      try {
        user.lastFilter = JSON.parse(user?.lastFilter);
      } catch (error) {}
      updateInstrumentFilter(user?.lastFilter?.selectedFilters);
    }
  };
  const saveAsDefault = async () => {
    user.lastFilter = {
      ...user.lastFilter,
      selectedFilters: { ...filters }
    };
    user.lastFilter = JSON.stringify(user.lastFilter);
 
    const result = await updateLastFilter(user);
  }

  test("should create with table inst", () => {
    const { queryByTestId } = render( 
      < DialogForm/> 
    );
    expect(queryByTestId("instrument-repositorium-modal-form")).toBeDefined();
  }); 

  test("should create with table inst", () => {
    const { queryByTestId } = render( 
      < DialogTitle/> 
    );
    expect(queryByTestId("instrument-repositorium-modal-title")).toBeDefined();
  }); 
 
  test("should create with table inst", () => {
    const { queryByTestId } = render( 
      <Provider>
      < FilterAction/> 
      </Provider>
    );
    expect(queryByTestId("instrument-filter-action")).toBeDefined();
  }); 
 
  test("should create with table inst", () => {
    const { queryByTestId } = render( 
      < DialogContent/> 
    );
    expect(queryByTestId("instrument-repositorium-modal-content")).toBeDefined();
  }); 
