import React from "react";
import { ConfirmDialog } from "../../components/shared";
import useDialog from "../../utils/hooks/useDialog";
import { PreviousButtonStyled } from "./addEditEquipment/AddEquipmentStyle";

const CancelButton = ({ cancelStep }) => {
  const { openDialog, ...dialogProps } = useDialog();

  return (
    <>
      <PreviousButtonStyled
        variant="contained"
        onClick={() => openDialog()}
        data-testid="add-instrument-previous-step-button"
      >
        Cancel
      </PreviousButtonStyled>

      <ConfirmDialog
        {...dialogProps}
        approveText="Yes"
        approveColor="primary"
        approveVariant="contained"
        cancelText="No"
        cancelVariant="outlined"
        cancelColor="primary"
        onApprove={() => cancelStep()}
        title="Add equipment"
        content="Do you want to cancel it?"
      />
    </>
  );
};

export default CancelButton;
