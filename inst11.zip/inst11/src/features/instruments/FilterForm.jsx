import React, { useState, useEffect } from "react";
import styled from "styled-components";
import CustomSelect from "../../components/shared/CustomSelect";
import { connect } from "react-redux";
import { compose, withApollo } from "react-apollo";
import { updateInstrumentFilter as updateInstrumentFilterAction } from "./redux/actions";

export const MainRow = styled.div`
  margin-bottom: 1.25rem;
`;
export const TitleHeader = styled.h2`
  display: flex;
  justify-content: space-between;
`;
export const TitleRow = styled.h2`
  font-weight: 500;
  font-size: 1.125rem;
  line-height: 1.4375rem;
  color: #333333;
  margin-bottom: 0.75rem;
  padding: 0 16px;
`;
export const RowInputsContainer = styled.div`
  display: flex;
  padding: 1.25rem 1rem;
`;
export const RowInputs = styled.div`
  & > .customSelect {
    width: 220px;
    display: flex;
    flex-direction: column;
    margin-bottom: 1.25rem;
  }
`;

const FilterForm = ({
  groupList,
  categoryList,
  manufacturerList,
  responsiblePersonList,
  siteList,
  filters,
  updateInstrumentFilter
}) => {
  const [filterObj, setFilterObj] = useState(filters);
  const [isManual, setIsManual] = useState(false);

  const handleChange = (event) => {
    setIsManual(true);
    const name = event.target.name;
    const manualFilters = {
      ...filterObj,
      [name]: event.target.value
    };
    setFilterObj(manualFilters);
    updateInstrumentFilter(manualFilters);
  };

  useEffect(() => {
    isManual ? setFilterObj(filterObj) : setFilterObj(filters);
    setIsManual(false);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]);

  return (
    <MainRow data-testid="basic-data-req-form">
      <RowInputsContainer>
        <RowInputs style={{ marginRight: 90 }}>
          <CustomSelect
            className="customSelect"
            variant="filled"
            selectLabel="Site"
            testid="basic-select"
            options={siteList}
            value={filterObj?.site}
            propValue="siteName"
            propLabel="siteName"
            name="site"
            onChange={handleChange}
          />
          <CustomSelect
            className="customSelect"
            variant="filled"
            selectLabel="Manufacturer"
            testid="basic-select"
            options={manufacturerList}
            propValue="value"
            propLabel="value"
            value={filterObj?.manufacturer}
            name="manufacturer"
            onChange={handleChange}
          />
          <CustomSelect
            className="customSelect"
            variant="filled"
            selectLabel="Responsible person"
            testid="basic-select"
            options={responsiblePersonList}
            propValue="personName"
            propLabel="personName"
            value={filterObj?.responsiblePerson}
            name="responsiblePerson"
            onChange={handleChange}
          />
        </RowInputs>
        <RowInputs>
          <CustomSelect
            className="customSelect"
            variant="filled"
            selectLabel="Group"
            options={groupList}
            testid="basic-select"
            value={filterObj?.group}
            name="group"
            onChange={handleChange}
            propValue="value"
            propLabel="value"
          />
          <CustomSelect
            className="customSelect"
            variant="filled"
            selectLabel="Category"
            testid="basic-select"
            options={categoryList}
            value={filterObj?.category}
            name="category"
            onChange={handleChange}
            propValue="value"
            propLabel="value"
          />
        </RowInputs>
        <RowInputs></RowInputs>
      </RowInputsContainer>
    </MainRow>
  );
};

const mapStateToProps = (state) => ({
  groupList: state.instruments?.groupList,
  manufacturerList: state.instruments?.manufacturerList,
  categoryList: state.instruments?.categoryList,
  responsiblePersonList: state.instruments?.responsiblePersonList,
  siteList: state.user?.sites ?? [],
  filters: state.instruments?.filters,
  user: state.user
});
export default compose(
  connect(mapStateToProps, {
    updateInstrumentFilter: updateInstrumentFilterAction
  }),
  withApollo
)(FilterForm);
