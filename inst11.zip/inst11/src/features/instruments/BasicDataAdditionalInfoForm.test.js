import { render, cleanup, fireEvent, waitFor } from "../../test-utils";
import { emptyInstruments } from "./InstrumentsModal";
import { useFormik } from "formik";
import BasicDataAdditionalInfoForm from "./BasicDataAdditionalInfoForm";
import * as yup from "yup";

afterEach(cleanup);

const testValidationSchema = yup.object({
  serialNumber: yup.string("Enter serial number"),
  materialNumber: yup.string("Enter material number"),
  siteName: yup.string("Site name"),
  siteTimezone: yup.string("Site timezone"),
  instrumentRUDI: yup.string("Enter RUDI number"),
  buildingLocation: yup.object({
    value: yup.string("Enter building location").required("required"),
    isSynchronized: yup.bool()
  }),
  instrumentGTIN: yup.object({
    value: yup.string("Enter instrument GTIN"),
    isSynchronized: yup.bool()
  }),
  instrumentName: yup.object({
    value: yup.string("Enter instrument name"),
    isSynchronized: yup.bool()
  }),
  instrumentType: yup.object({
    value: yup.string("Enter instrument type"),
    isSynchronized: yup.bool()
  }),
  isBookable: yup.bool(),
  isVisualized: yup.bool(),
  floorAndRoomLocation: yup.object({
    value: yup.string("Enter instrument location").required("required"),
    isSynchronized: yup.bool()
  }),
  responsiblePerson: yup.object({
    value: yup.string("Enter responsible person").required("required"),
    isSynchronized: yup.bool()
  }),
  softwareVersion: yup.string("Enter software version").required("required"),
  configurationBaseline: yup
    .string("Enter configuration baseline")
    .required("required"),
  systemStatus: yup.object({
    value: yup.string("Enter system status").required("required"),
    isSynchronized: yup.bool()
  }),
  instrumentGxPStatus: yup.object({
    value: yup.string("Enter ABC indicator").required("required"),
    isSynchronized: yup.bool()
  }),
  belongingToGroup: yup.string("Enter belonging to group").required("required"),
  dateOfLastMaintanance: yup.object({
    value: yup.date().typeError("invalid date").nullable(),
    isSynchronized: yup.bool()
  }),
  dateOfNextMaintanance: yup.object({
    value: yup.date().typeError("invalid date").nullable(),
    isSynchronized: yup.bool()
  }),
  installedTests: yup.array(),
  qualificationDocuments: yup.object({
    value: yup.array(),
    isSynchronized: yup.bool()
  }),
  equipmentId: yup
    .object({
      value: yup.string("Enter equipment ID"),
      isSynchronized: yup.bool()
    })
    .nullable(),
  manufacturer: yup
    .object({
      value: yup.string("Enter manufacturer"),
      isSynchronized: yup.bool()
    })
    .nullable(),
  secondResponsiblePerson: yup
    .object({
      value: yup.string("Enter second responsible person"),
      isSynchronized: yup.bool()
    })
    .nullable()
});

const TestComponent = ({ submit }) => {
  const formik = useFormik({
    initialValues: {
      ...emptyInstruments
    },
    validationSchema: testValidationSchema,
    onSubmit: (values) => {
      if (submit) {
        submit(values);
      }
    }
  });

  return (
    <form data-testid="test-form" onSubmit={formik.handleSubmit}>
      <BasicDataAdditionalInfoForm formik={formik} />
    </form>
  );
};

test("should create", async () => {
  const { getByTestId } = render(<TestComponent />);

  await waitFor(() =>
    expect(getByTestId("basic-data-additional-form")).toBeDefined()
  );
});
test.skip("should update form with checkboxes", async () => {
  const submit = jest.fn();
  const { getByTestId, getByLabelText } = render(
    <TestComponent submit={submit} />
  );

  fireEvent.change(getByLabelText(/building/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/floor and room/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/^responsible person/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/^second responsible person/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/software version/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/configure baseline/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/system status/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/gxp state/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/belonging to group/i), {
    target: { value: "test" }
  });

  fireEvent.change(getByLabelText(/date of executed maintenance/i), {
    target: { value: "01-Jan-2021" }
  });
  fireEvent.change(getByLabelText(/date of next maintenance/i), {
    target: { value: "01-Jan-2021" }
  });

  fireEvent.change(getByLabelText(/equipment id/i), {
    target: { value: "test" }
  });

  fireEvent.change(getByLabelText(/manufacturer/i), {
    target: { value: "test" }
  });

  fireEvent.click(getByTestId("additional-info-bookable-true"));
  fireEvent.click(getByTestId("additional-info-visualized-true"));

  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-building-location-checkbox"
    ).querySelector("input")
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-floor-and-room-location-checkbox"
    ).querySelector("input")
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-responsible-person-checkbox"
    ).querySelector("input")
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-system-status-checkbox"
    ).querySelector("input")
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-gxp-status-checkbox"
    ).querySelector("input")
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-date-of-last-maintanance-checkbox"
    ).querySelector("input")
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-date-of-next-maintanance-checkbox"
    ).querySelector("input")
  );

  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-second-responsible-person-checkbox"
    ).querySelector("input")
  );

  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-req-equipmentId-checkbox"
    ).querySelector("input")
  );

  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-req-manufacturer-checkbox"
    ).querySelector("input")
  );

  await waitFor(() => {
    expect(getByLabelText(/building/i)).toHaveValue("test");
    expect(getByLabelText(/floor and room/i)).toHaveValue("test");
    expect(getByLabelText(/^responsible person/i)).toHaveValue("test");
    expect(getByLabelText(/^second responsible person/i)).toHaveValue("test");
    expect(getByLabelText(/software version/i)).toHaveValue("test");
    expect(getByLabelText(/configure baseline/i)).toHaveValue("test");
    expect(getByLabelText(/system status/i)).toHaveValue("test");
    expect(getByLabelText(/gxp state/i)).toHaveValue("test");
    expect(getByLabelText(/belonging to group/i)).toHaveValue("test");
    expect(getByLabelText(/date of executed maintenance/i)).toHaveValue(
      "01-Jan-2021"
    );
    expect(getByLabelText(/date of next maintenance/i)).toHaveValue(
      "01-Jan-2021"
    );
  });

  expect(getByLabelText(/manufacturer/i)).toHaveValue("test");
  expect(getByLabelText(/equipment Id/i)).toHaveValue("test");

  fireEvent.submit(getByTestId("test-form"));

  await waitFor(() => {
    expect(submit).toHaveBeenCalledWith(
      expect.objectContaining({
        isBookable: true,
        isVisualized: true,
        buildingLocation: {
          value: "test",
          isSynchronized: true
        },
        floorAndRoomLocation: {
          value: "test",
          isSynchronized: true
        },
        responsiblePerson: {
          value: "test",
          isSynchronized: true
        },
        secondResponsiblePerson: {
          value: "test",
          isSynchronized: true
        },
        softwareVersion: "test",
        configurationBaseline: "test",
        systemStatus: {
          value: "test",
          isSynchronized: true
        },
        instrumentGxPStatus: {
          value: "test",
          isSynchronized: true
        },
        belongingToGroup: "test",
        dateOfLastMaintanance: {
          isSynchronized: true,
          value: "2021-01-01"
        },
        dateOfNextMaintanance: {
          isSynchronized: true,
          value: "2021-01-01"
        },
        equipmentId: {
          value: "test",
          isSynchronized: true
        },
        manufacturer: {
          value: "test",
          isSynchronized: true
        }
      })
    );
  });
});

test("should update form with incorrect values", async () => {
  const submit = jest.fn();
  const { getByTestId, getByLabelText } = render(
    <TestComponent submit={submit} />
  );
  fireEvent.change(getByLabelText(/building/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/floor and room/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/^responsible person/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/software version/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/configure baseline/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/system status/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/gxp state/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/belonging to group/i), {
    target: { value: "test" }
  });

  fireEvent.change(getByLabelText(/date of executed maintenance/i), {
    target: { value: "01-Jan-" }
  });
  fireEvent.change(getByLabelText(/date of next maintenance/i), {
    target: { value: "01-Jan-" }
  });

  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-clear-button-building-location-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-clear-button-floor-and-room-location-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-clear-button-responsible-person-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-clear-button-software-version-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-clear-button-configuration-baseline-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-clear-button-system-status-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-clear-button-gxp-status-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-additional-info-fields-instrument-clear-button-belonging-to-group-input"
    )
  );

  await waitFor(() => {
    expect(getByLabelText(/building/i)).toHaveValue("");
    expect(getByLabelText(/floor and room/i)).toHaveValue("");
    expect(getByLabelText(/^responsible person/i)).toHaveValue("");
    expect(getByLabelText(/^second responsible person/i)).toHaveValue("");
    expect(getByLabelText(/software version/i)).toHaveValue("");
    expect(getByLabelText(/configure baseline/i)).toHaveValue("");
    expect(getByLabelText(/system status/i)).toHaveValue("");
    expect(getByLabelText(/gxp state/i)).toHaveValue("");
    expect(getByLabelText(/belonging to group/i)).toHaveValue("");
    expect(getByLabelText(/date of executed maintenance/i)).toHaveValue(
      "01-Jan-____"
    );
    expect(getByLabelText(/date of next maintenance/i)).toHaveValue(
      "01-Jan-____"
    );
  });

  fireEvent.submit(getByTestId("test-form"));

  await waitFor(() => {
    expect(submit).not.toHaveBeenCalled();

    expect(
      getByTestId(
        "basic-data-additional-info-fields-instrument-helper-text-building-location-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-additional-info-fields-instrument-helper-text-floor-and-room-location-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-additional-info-fields-instrument-helper-text-responsible-person-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-additional-info-fields-instrument-helper-text-software-version-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-additional-info-fields-instrument-helper-text-configuration-baseline-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-additional-info-fields-instrument-helper-text-system-status-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-additional-info-fields-instrument-helper-text-gxp-status-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-additional-info-fields-instrument-helper-text-belonging-to-group-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-additional-info-fields-instrument-helper-text-date-of-last-maintanance-input"
      )
    ).toHaveTextContent(/invalid/i);
    expect(
      getByTestId(
        "basic-data-additional-info-fields-instrument-helper-text-date-of-next-maintanance-input"
      )
    ).toHaveTextContent(/invalid/i);
  });
});
