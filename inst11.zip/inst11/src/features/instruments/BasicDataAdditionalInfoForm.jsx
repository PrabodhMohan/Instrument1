import React from "react";
import styled from "styled-components";
import { Checkbox, FormControlLabel, makeStyles } from "@material-ui/core";
import {
  RowInputs,
  TitleRow,
  MainRow,
  CheckboxRow
} from "./BasicDataReqFieldsForm";
import DateFnsUtils from "@date-io/date-fns";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker
} from "@material-ui/pickers";
import BooleanButtons from "./BooleanButtons";
import locale from "date-fns/locale/en-US";
import { format } from "date-fns";
import { commonPropsForInputsWithoutValue } from "./helpers";
import { buttonStyles } from "./buttonStyles";
import { selectedStyles } from "./selectedStyles";
import InputWithCheckbox from "./InputWithCheckbox";

export const useStyles = makeStyles(() => ({
  button: buttonStyles,
  selected: selectedStyles,
  checkbox: {
    color: "#737373",
    marginRight: "3px"
  },
  clearInputButton: {
    color: "#8A8A8A",
    fontSize: "20px",
    paddingRight: 18
  }
}));

const BooleanButtonsLabel = styled.h3`
  font-weight: 500;
  font-size: 14px;
  line-height: 18px;
  color: #333333;
  margin-bottom: 0.5rem;
`;

const DatePicker = ({
  formik,
  dataTestid,
  id,
  name,
  label,
  value,
  formikTouched,
  formikErrors,
  dataTestIdHelp
}) => {
  return (
    <MuiPickersUtilsProvider
      utils={DateFnsUtils}
      locale={{
        ...locale,
        options: {
          ...locale.options,
          weekStartsOn: 1
        }
      }}
    >
      <KeyboardDatePicker
        disableToolbar
        refuse={/[^\dA-Za-z]+/gi}
        format="dd-MMM-yyyy"
        data-testid={dataTestid}
        id={id}
        name={name}
        label={label}
        value={value}
        onChange={date => {
          if (date instanceof Date && !isNaN(date)) {
            formik.setFieldValue(name, format(date, "yyyy-MM-dd"), true);
          } else {
            formik.setFieldValue(name, date, true);
          }
        }}
        variant="inline"
        error={formikTouched && Boolean(formikErrors)}
        helperText={formikTouched && formikErrors}
        FormHelperTextProps={{
          "data-testid": dataTestIdHelp
        }}
        autoOk
      />
    </MuiPickersUtilsProvider>
  );
};

const DatePickers = ({ formik }) => {
  const classes = useStyles();
  return (
    <>
      <RowInputs>
        <DatePicker
          formik={formik}
          dataTestid={
            "basic-data-additional-info-fields-instrument-date-of-next-maintanance-input"
          }
          id={"dateOfNextMaintanance"}
          name={"dateOfNextMaintanance.value"}
          label={"Date of next maintenance"}
          value={formik.values.dateOfNextMaintanance?.value}
          formikTouched={formik.touched.dateOfNextMaintanance?.value}
          formikErrors={formik.errors.dateOfNextMaintanance?.value}
          dataTestIdHelp={
            "basic-data-additional-info-fields-instrument-helper-text-date-of-next-maintanance-input"
          }
        />
        <CheckboxRow
          isChecked={formik.values.dateOfLastMaintanance?.isSynchronized}
        >
          <FormControlLabel
            control={
              <Checkbox
                classes={{
                  root: classes.checkbox
                }}
                color="primary"
                data-testid="basic-data-additional-info-fields-instrument-date-of-last-maintanance-checkbox"
                checked={formik.values.dateOfLastMaintanance?.isSynchronized}
                onChange={formik.handleChange}
                name="dateOfLastMaintanance.isSynchronized"
              />
            }
            label={
              formik.values.dateOfLastMaintanance?.isSynchronized
                ? "Will update"
                : "Update?"
            }
          />
        </CheckboxRow>
      </RowInputs>
      <RowInputs>
        <DatePicker
          formik={formik}
          dataTestid={
            "basic-data-additional-info-fields-instrument-date-of-last-maintanance-input"
          }
          id={"dateOfLastMaintanance"}
          name={"dateOfLastMaintanance.value"}
          label={"Date of executed maintenance"}
          value={formik.values.dateOfLastMaintanance?.value}
          formikTouched={formik.touched.dateOfLastMaintanance?.value}
          formikErrors={formik.errors.dateOfLastMaintanance?.value}
          dataTestIdHelp={
            "basic-data-additional-info-fields-instrument-helper-text-date-of-last-maintanance-input"
          }
        />
        <CheckboxRow
          isChecked={formik.values.dateOfNextMaintanance?.isSynchronized}
        >
          <FormControlLabel
            control={
              <Checkbox
                classes={{
                  root: classes.checkbox
                }}
                color="primary"
                data-testid="basic-data-additional-info-fields-instrument-date-of-next-maintanance-checkbox"
                checked={formik.values.dateOfNextMaintanance?.isSynchronized}
                onChange={formik.handleChange}
                name="dateOfNextMaintanance.isSynchronized"
              />
            }
            label={
              formik.values.dateOfNextMaintanance?.isSynchronized
                ? "Will update"
                : "Update?"
            }
          />
        </CheckboxRow>
      </RowInputs>
    </>
  );
};

const BooleansFields = ({ formik }) => {
  const classes = useStyles();
  return (
    <>
      <TitleRow>Additional informations</TitleRow>
      <BooleanButtonsLabel>Bookable</BooleanButtonsLabel>
      <RowInputs>
        <BooleanButtons
          trueProps={{
            "data-testid": "additional-info-bookable-true"
          }}
          falseProps={{
            "data-testid": "additional-info-bookable-false"
          }}
          fullWidth
          color="primary"
          trueLabel="Yes"
          falseLabel="No"
          onChange={value => formik.setFieldValue("isBookable", value, true)}
          value={formik.values.isBookable}
        />
        <CheckboxRow isDisabled={true}>
          <FormControlLabel
            control={
              <Checkbox
                classes={{
                  root: classes.checkbox
                }}
                disabled
                data-testid="basic-data-additional-info-fields-isBookable-disabled-checkbox"
              />
            }
            label="Update?"
          />
        </CheckboxRow>
      </RowInputs>
      <BooleanButtonsLabel>Status Visualization</BooleanButtonsLabel>
      <RowInputs>
        <BooleanButtons
          trueProps={{
            "data-testid": "additional-info-visualized-true"
          }}
          falseProps={{
            "data-testid": "additional-info-visualized-false"
          }}
          fullWidth
          color="primary"
          trueLabel="Visualized"
          falseLabel="Not shown"
          onChange={value => formik.setFieldValue("isVisualized", value, true)}
          value={formik.values.isVisualized}
        />
        <CheckboxRow isDisabled={true}>
          <FormControlLabel
            control={
              <Checkbox
                classes={{
                  root: classes.checkbox
                }}
                disabled
                data-testid="basic-data-additional-info-fields-isVisualized-disabled-checkbox"
              />
            }
            label="Update?"
          />
        </CheckboxRow>
      </RowInputs>
    </>
  );
};

const BasicDataAdditionalInfoForm = ({ formik }) => {
  return (
    <MainRow data-testid="basic-data-additional-form">
      <BooleansFields formik={formik}/>

      <InputWithCheckbox
        fieldName="buildingLocation"
        formik={formik}
        testid="building-location"
        label="Building"
      />

      <InputWithCheckbox
        fieldName="floorAndRoomLocation"
        formik={formik}
        testid="floor-and-room-location"
        label="Floor and room"
      />

      <InputWithCheckbox
        fieldName="responsiblePerson"
        formik={formik}
        testid="responsible-person"
        label="Responsible Person"
      />

      <InputWithCheckbox
        fieldName="secondResponsiblePerson"
        formik={formik}
        testid="second-responsible-person"
        label="Second Responsible Person"
      />

      <InputWithCheckbox
        fieldName="softwareVersion"
        formik={formik}
        testid="software-version"
        label="Software version"
        commonProps={commonPropsForInputsWithoutValue}
        isDisabled={true}
      />

      <InputWithCheckbox
        fieldName="configurationBaseline"
        formik={formik}
        testid="configuration-baseline"
        label="Configure baseline"
        commonProps={commonPropsForInputsWithoutValue}
        isDisabled={true}
      />

      <InputWithCheckbox
        fieldName="systemStatus"
        formik={formik}
        testid="system-status"
        label="System status"
      />

      <InputWithCheckbox
        fieldName="instrumentGxPStatus"
        formik={formik}
        testid="gxp-status"
        label="GxP state"
      />

      <InputWithCheckbox
        fieldName="belongingToGroup"
        formik={formik}
        testid="belonging-to-group"
        label="Belonging to group"
        commonProps={commonPropsForInputsWithoutValue}
        isDisabled={true}
      />

      <InputWithCheckbox
        fieldName="equipmentId"
        formik={formik}
        testid="req-equipmentId"
        label="Equipment id"
        inputProps={{
          required: true
        }}
      />

      <InputWithCheckbox
        fieldName="manufacturer"
        formik={formik}
        testid="req-manufacturer"
        label="Manufacturer"
      />
      <DatePickers formik={formik} />
    </MainRow>
  );
};
export default BasicDataAdditionalInfoForm;
