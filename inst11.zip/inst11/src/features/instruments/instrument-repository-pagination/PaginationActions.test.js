import React, { useState, useEffect } from "react";
//import { emptyInstruments } from "./InstrumentsModal";
import { waitFor } from "@testing-library/dom";
import { useFormik } from "formik";
import { ButtonNext, ButtonPrev, FirstPage, PageRowNuberSelector } from './PaginationActions';
import { render, cleanup } from "../../../test-utils";
import styled from "styled-components";
import IconButton from "@material-ui/core/IconButton";
import NavigateNextIcon from "@material-ui/icons/NavigateNext";
import NavigatePrevIcon from "@material-ui/icons/NavigateBefore";
import { fireEvent } from "@testing-library/dom";
import { connect } from "react-redux";
import { compose } from "redux";
import { withApollo } from "react-apollo";
import {
  updateLimit as updateLimitAction,
  updateNextToken as updateNextTokenAction,
  loadInstruments as loadInstrumentsAction
} from "../redux/actions";

 
import { LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS } from "../../../gql/landingapi/queries";
import {screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import ReactTestUtils from 'react-dom/test-utils'; // ES6
import { initialState } from '../../instruments/redux/initialState';
import PaginationActions from './PaginationActions'
afterEach(cleanup);

const PaginationActionsStyled = styled.div`
  display: flex;
  justify-content: flex-end;
  height: 70px;
  width: 100%;
  & > .pagination {
    display: flex;
    background-color: #ffffff;
    width: 100%;
    justify-content: flex-end;
    padding: 0 0.5rem;
    align-items: center;
    & button:first-of-type {
      margin-left: 10px;
    }
  }
`;

const nextPage = async () => {
  updateLoading(true);
  const filterObject = filterApplied ? localFilterObject() : null;
  let instrumentList = [];
  let keepFetching = true;
  let recursiveNextToken = nextToken;

  do {
    const localLimit = limit - instrumentList.length;
    if (localLimit <= 0) {
      keepFetching = false;
      break;
    }
    const variables = {
      limit: limit,
      nextToken: recursiveNextToken,
      filter: filterObject
    };
    const { nextToken: latestNextToken, items: result } =
      await getfilterInstrumentList({ client, variables });
    instrumentList.push(...result);
    recursiveNextToken = latestNextToken;
    keepFetching = latestNextToken !== null;
  } while (keepFetching);
  loadInstruments({
    instruments: instrumentList ? instrumentList : []
  });
  updateNextToken(recursiveNextToken ?? null);
  const localPageIndex = pageIndex + 1;
  setPageIndex(localPageIndex);

  const isPresent = pageTokenArray.find(
    (x) => x.pageIndex === localPageIndex
  );
  if (isPresent === undefined) {
    updatePageTokenArray({
      pageIndex: localPageIndex,
      token: recursiveNextToken
    });
  }
  updateLoading(false);
};

const TestComponent = ({
  updateLimit,
  limit,
  loadInstruments,
  client,
  nextToken,
  updateNextToken
}) => {
  const [selected, setSelected] = useState(50);
  const handleChange = (event) => {
    updateLimit(event.target.value);
    setSelected(event.target.value);

    const loadData = async () => {
      const { data } = await client.query({
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        fetchPolicy: "no-cache",
        variables: {
          limit: 5,
          nextToken: nextToken
        },
        dataPath: ["data", "listDigitalLabInstrumentRepositoryEntrys"]
      });
      const nextData =
        data?.listDigitalLabInstrumentRepositoryEntrys?.nextToken;
      const items = data?.listDigitalLabInstrumentRepositoryEntrys?.items;
      console.log("test", "items", nextData, items);
      loadInstruments({
        items
      });
      updateNextToken(nextData);
    };
    loadData();
  };
  return (
    <div className="pagination">
      <PageRowNuberSelector
        updateLimit={updateLimit}
        limit={limit}
        loadInstruments={loadInstruments}
        client={client}
        nextToken={nextToken}
        updateNextToken={updateNextToken}
      />
      <FirstPage />
      <ButtonPrev />
      <ButtonNext />
    </div>
  );
};

const mapStateToProps = (state) => ({
  limit: state.instruments?.limit,
  nextToken: state.instruments?.nextToken
});

compose(
  connect(mapStateToProps, {
    updateLimit: updateLimitAction,
    loadInstruments: loadInstrumentsAction,
    updateNextToken: updateNextTokenAction
  }),
  withApollo
)(TestComponent);

 
test("should create first page", async () => {
  const { getByTestId } = render(
    <PaginationActions>
      <FirstPage />
    </PaginationActions>);
  await waitFor(() =>
    expect(getByTestId("run-log-first-page")).toBeDefined()
  );
});
test("should create prev page", async () => {
  const { getByTestId } = render(
    <PaginationActions>
      <ButtonPrev />
    </PaginationActions>);
  await waitFor(() =>
    expect(getByTestId("button-prev-pagination")).toBeDefined()
  );
});
test("should create next page", async () => {
  const { getByTestId } = render(
    <PaginationActions>
      <ButtonNext />
    </PaginationActions>);
  await waitFor(() =>
    expect(getByTestId("button-next-pagination")).toBeDefined()
  );
});
test("should create the page", async () => {
  const { getByTestId } = render(
    <TestComponent />);
  await waitFor(() =>
    expect(getByTestId("paginator-row-number-selector")).toBeDefined()
  );
});

test("should trigger onchange", async () => {
  const { getByTestId } = render(
    <TestComponent />);
    const changeValue = getByTestId('paginator-row-number-selector')
    changeValue.value = 10
    fireEvent.change(changeValue)
      waitFor(() => {
      expect(handleChange()).toBeCalled()
    })
});

// describe('Component', function() {
//     it('must call getList on button click', function() {
//       var renderedNode = ReactTestUtils.renderIntoDocument(<TestComponent />);
//      // renderedNode.prototype.getList
//       renderedNode.prototype.getList = jest.fn();
//       var button = TestUtils.findRenderedDOMComponentWithTag(renderedNode, 'button');
//       jest.dontMock('./PaginationActions.jsx');
      
//       <script src="https://unpkg.com/react@15/dist/react-with-addons.js">
//       React = require('react/addons'); 
//       const TestUtils = React.addons.TestUtils;
//       TestUtils.Simulate.click(button);
      
//       </script>
//       expect(renderedNode.prototype.getList).toBeCalled();
//     });

// });
 
test("should trigger next page button", async () => {
    render(<TestComponent />);
    let nextButton = screen.getByTitle(/Next page/) ;
  //  userEvent.click(nextButton);
  //  fireEvent.click(nextButton);
    //console.log("nextButton",nextButton);
    expect(1).toBe(1);
    //
    
 //  test("should trigger prev page button", async () => {
//   render(<TestComponent />);
//   let nextButton = screen.getByTitle(/Prev page/) ;
 // userEvent.click(nextButton);
  //console.log("nextButton",nextButton);
});
test.skip("should do next action", () => {
  const dispatchAction = jest.fn();
  var loadInstruments;
  const { getByTestId } = render(
    <IconButton
    aria-label="Next page"
    data-testid="button-next-pagination"
    size="small"
    title="Next page"
    onClick={nextPage}
  >
    {/* <NavigateNextIcon /> */}
  </IconButton>
  );

  expect(getByTestId("button-next-pagination")).toBeInTheDocument();
  fireEvent.click(getByTestId("button-next-pagination"));
  expect(dispatchAction).toHaveBeenCalledWith({
    type: "nextData"
  });
});


 


test("should create", async () => {
    const { getByTestId } = render(
         <ButtonPrev />
 );
      expect(getByTestId("button-prev-pagination")).toBeDefined()
});

test("should create first page", async () => {
    const { getByTestId } = render(
     <FirstPage />
    );
      expect(getByTestId("run-log-first-page")).toBeDefined()
});


test("should create", async () => {
    const { getByTestId } = render(
         <ButtonPrev />
 );
      expect(getByTestId("button-prev-pagination")).toBeDefined()
});


it.skip('must call getList on button click1111', function() {
    var renderedNode = TestUtils.renderIntoDocument(<PaginationActions />);
    renderedNode.prototype.getList = jest.fn()
    var button = TestUtils.findRenderedDOMComponentWithTag(renderedNode, 'button');
    TestUtils.Simulate.click(button);
    expect(renderedNode.prototype.getList).toBeCalled();
});


test.skip("should clear inputs", async () => {
    const { getByTestId, getByLabelText } = render(<TestComponent />);
  
    
    fireEvent.change(getByLabelText(/test name/i), {
      target: {
        value: "test"
      }
    });
    fireEvent.change(getByLabelText(/paginator-row-number-selector/i), {
      target: {
        value: "test"
      }
    });
  
    await waitFor(() => {
      expect(getByLabelText(/test name/i).value.trim()).toBe("test");
      expect(getByLabelText(/paginator-row-number-selector/i).value.trim()).toBe("test");
    });
  
    fireEvent.click(getByTestId("handle-change"));
    // fireEvent.click(
    //   getByTestId("assays-data-form-test-version-input-clear-button")
    // );
  
    await waitFor(() => {
      expect(getByLabelText(/test name/i).value.trim()).toBe("");
      expect(getByLabelText(/paginator-row-number-selector/i).value.trim()).toBe("");
    });
  });
  

  jest.mock("../../../utils/hooks");
  jest.mock("../../../views/AppBar");
 
  const itemList = ['item1', 'item2', 'item3', 'item4'];

  // Mock the external module and the paginate function
  // jest.mock('nestjs-typeorm-PaginationActions', () => ({
  //   paginate: jest.fn().mockResolvedValue({
  //       items: itemList.slice(0, 2),
  //       meta: {
  //         itemCount: 2,
  //         totalItems: 2,
  //         totalPages: 1,
  //         currentPage: 1,
  //       }
  //     }),
  // }));
 



   
  test("should lock first page action", () => {
    const dispatchAction = jest.fn();
    const { getByTestId } = render(
      <PageRowNuberSelector
        value={{
           dispatchAction,
           prevTokens: [],
           limit: 5 ,
           fetching: true,
           updateLoading : true,
           setPageIndex :  0 ,
         }}
      >
        <FirstPage />
      </PageRowNuberSelector>
    );
    
  //expect(getByTestId("run-log-first-page")).toBeDisabled();
 // fireEvent.click(getByTestId("run-log-first-page"));
  expect(getByTestId("run-log-first-page")).toBeInTheDocument()
       expect(dispatchAction).not.toHaveBeenCalledWith({type: "warning"});
  });

  test("should set new limit", () => {
    const dispatchAction = jest.fn();
    const { getByTestId } = render(
      <PageRowNuberSelector
        value={{
          dispatchAction,
          limit: 5
        }}
      >
        <PageRowNuberSelector />
      </PageRowNuberSelector>
    );
  
    expect(getByTestId("paginator-row-number-selector")).toBeInTheDocument();
     fireEvent.mouseDown(getByTestId("paginator-row-number-selector").querySelector("[role=button]")  );
    // fireEvent.click(getByTestId("paginator-row-number-selector").querySelector("[role=button]"));
    // fireEvent.click(getByTestId("paginator-row-number-selector-item-v20"));
    // expect(dispatchAction).toHaveBeenCalledWith({
    //   type: "setLimit",
    //   payload: 20
    // });
  });
  
  test("should create", () => {
    const {container} = render(
      <PageRowNuberSelector value={{ ...initialState }}>
        <PaginationActionsStyled />
      </PageRowNuberSelector>
    );
   // expect(container.contains("pagination")).toBeInTheDocument();
   //expect(getByTestId("container")).toHaveBeenCalled();
    
  });
  
  test("should do first page action", () => {
    const dispatchAction = jest.fn();
    const { getByTestId } = render(
      <PageRowNuberSelector
        value={{
          dispatchAction,
          fetching: false,
          prevTokens: ["123"]
        }}
      >
        <FirstPage />
      </PageRowNuberSelector>
    );
  
    //expect(getByTestId("run-log-first-page")).toBeInTheDocument();
    fireEvent.click(getByTestId("run-log-first-page"));
    expect(dispatchAction).toHaveBeenCalledWith({
      type: "clearAll"
    });
  });


  test("should lock prev action", () => {
    const dispatchAction = jest.fn();
    const { getByTestId } = render(
     <PageRowNuberSelector
        value={{
          dispatchAction,
          fetching: true,
          prevTokens: []
        }}
      >
        <ButtonPrev />
      </PageRowNuberSelector>
     );
  
    expect(getByTestId("button-prev-pagination")).toBeDisabled();
    fireEvent.click(getByTestId("button-prev-pagination"));
    expect(dispatchAction).not.toHaveBeenCalledWith({
      type: "prevData"
    });
  });


  
test("should do next action", () => {
  const dispatchAction = jest.fn();
  const { getByTestId } = render(
    <PageRowNuberSelector
      value={{
        dispatchAction,
        fetching: false,
        nextToken: "123"
      }}
    >
      <ButtonNext />
    </PageRowNuberSelector>
  );

  // expect(getByTestId("button-next-pagination")).toBeInTheDocument();
  // fireEvent.click(getByTestId("button-next-pagination"));
  expect(dispatchAction).toHaveBeenCalledWith({
    type: "nextData"
  });
});