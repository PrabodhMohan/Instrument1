import React, { useState, useEffect } from "react";
import IconButton from "@material-ui/core/IconButton";
import FirstPageIcon from "@material-ui/icons/FirstPage";
import NavigateNextIcon from "@material-ui/icons/NavigateNext";
import NavigatePrevIcon from "@material-ui/icons/NavigateBefore";
import styled from "styled-components";
import { FormControl, MenuItem, Select, withStyles } from "@material-ui/core";
import { connect } from "react-redux";
import { compose } from "redux";
import { withApollo } from "react-apollo";
import {
  updateLimit as updateLimitAction,
  updateNextToken as updateNextTokenAction,
  loadInstruments as loadInstrumentsAction,
  updatePageTokenArray as updatePageTokenArrayAction,
  updateLoading as updateLoadingAction
} from "../redux/actions";
import { LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS } from "../../../gql/landingapi/queries";
import { DEFAULT_LIMIT } from "../../../constants";
import Notify from "../../notifications/Notify";

import {
  getFilterObject,
  getfilterInstrumentList
} from "../../../utils/helpers/filtersAndPagination";
export const ButtonNext = ({
  limit,
  loadInstruments,
  client,
  nextToken,
  updateNextToken,
  pageIndex,
  pageTokenArray,
  setPageIndex,
  updatePageTokenArray,
  filterInstrumentList,
  localFilterObject,
  filterApplied,
  updateLoading,
  loading
}) => {
  const [nextDisable, setNextDisable] = useState(nextToken === null);
  const nextPage = async () => {
    updateLoading(true);
    const filterObject = filterApplied ? localFilterObject() : null;
    let instrumentList = [];
    let keepFetching = true;
    let recursiveNextToken = nextToken;

    do {
      const localLimit = limit - instrumentList.length;
      if (localLimit <= 0) {
        keepFetching = false;
        break;
      }
      const variables = {
        limit: limit,
        nextToken: recursiveNextToken,
        filter: filterObject
      };
      const { nextToken: latestNextToken, items: result } =
        await getfilterInstrumentList({ client, variables });
      instrumentList.push(...result);
      recursiveNextToken = latestNextToken;
      keepFetching = latestNextToken !== null;
    } while (keepFetching);
    loadInstruments({
      instruments: instrumentList ? instrumentList : []
    });
    updateNextToken(recursiveNextToken ?? null);
    const localPageIndex = pageIndex + 1;
    setPageIndex(localPageIndex);

    const isPresent = pageTokenArray.find(
      (x) => x.pageIndex === localPageIndex
    );
    if (isPresent === undefined) {
      updatePageTokenArray({
        pageIndex: localPageIndex,
        token: recursiveNextToken
      });
    }
    updateLoading(false);
  };

  useEffect(() => {
    setNextDisable(nextToken === null || loading);
  }, [nextToken, loading]);
  return (
    <IconButton
      aria-label="Next page"
      data-testid="button-next-pagination"
      size="small"
      title="Next page"
      onClick={nextPage}
      disabled={nextDisable}
    >
      <NavigateNextIcon />
    </IconButton>
  );
};

export const ButtonPrev = ({
  limit,
  loadInstruments,
  client,
  nextToken,
  updateNextToken,
  pageIndex,
  pageTokenArray,
  setPageIndex,
  updatePageTokenArray,
  disabled,
  localFilterObject,
  updateLoading
}) => {
  const prevPage = async () => {
    const currentPageIndex = pageIndex - 1;
    updateLoading(true);
    setPageIndex(currentPageIndex);

    const filterObject = localFilterObject();
    let instrumentList = [];
    let recursiveNextToken = null;
    const prevPageIndex = currentPageIndex - 1;
    const isPrevPage = pageTokenArray.find(
      (x) => x.pageIndex === prevPageIndex
    );
    if (isPrevPage) {
      recursiveNextToken = isPrevPage?.token ?? null;
    }

    do {
      const localLimit = limit - instrumentList.length;
      if (localLimit <= 0) {
        break;
      }
      const variables = {
        limit: limit,
        nextToken: recursiveNextToken,
        filter: filterObject
      };
      const { nextToken: latestNextToken, items: result } =
        await getfilterInstrumentList({ client, variables });
      instrumentList.push(...result);
      recursiveNextToken = latestNextToken;
    } while (recursiveNextToken != null);
    loadInstruments({
      instruments: instrumentList ? instrumentList : []
    });
    updateNextToken(recursiveNextToken ?? null);

    updateLoading(false);
  };

  return (
    <IconButton
      aria-label="Prev page"
      data-testid="button-prev-pagination"
      size="small"
      title="Prev page"
      onClick={prevPage}
      disabled={disabled}
    >
      <NavigatePrevIcon />
    </IconButton>
  );
};

export const FirstPage = ({
  limit,
  client,
  disabled,
  loadInstruments,
  setPageIndex,
  localFilterObject,
  updateNextToken,
  updatePageTokenArray,
  updateLoading
}) => {
  const firstPage = async () => {
    updateLoading(true);
    setPageIndex(0);
    const filterObject = localFilterObject();
    let instrumentList = [];
    let recursiveNextToken = null;

    do {
      const localLimit = limit - instrumentList.length;
      if (localLimit <= 0) {
        break;
      }
      const variables = {
        limit: localLimit,
        nextToken: recursiveNextToken,
        filter: filterObject
      };
      const { nextToken: latestNextToken, items: result } =
        await getfilterInstrumentList({ client, variables });
      instrumentList.push(...result);
      recursiveNextToken = latestNextToken;
    } while (recursiveNextToken !== null);
    loadInstruments({
      instruments: instrumentList ? instrumentList : []
    });
    updateNextToken(recursiveNextToken ?? null);
    updatePageTokenArray({ pageIndex: 0, token: recursiveNextToken });
    updateLoading(false);
  };

  return (
    <IconButton
      aria-label="first page"
      data-testid="run-log-first-page"
      size="small"
      title="First page"
      onClick={firstPage}
      disabled={disabled}
    >
      <FirstPageIcon />
    </IconButton>
  );
};
const PageRowNuberSelectorStyled = styled.div`
  display: flex;
  align-items: center;
  & > div {
    margin-left: 8px;
  }
`;
const PaginatorSelect = withStyles({
  root: {
    paddingTop: 6,
    paddingBottom: 6
  }
})(Select);
export const PageRowNuberSelector = ({
  updateLimit,
  limit,
  loadInstruments,
  client,
  updateNextToken,
  setPageIndex,
  updatePageTokenArray,
  filterInstrumentList,
  search,
  updateLoading,
  disabled
}) => {
  const [selected, setSelected] = useState(DEFAULT_LIMIT);
  const loadRecursiveData = async (localLimit, localToken) => {
    try {
      let localFilter = null;
      if (search) {
        localFilter = {
          and: [{ serialNumber: { beginsWith: search } }]
        };
      }
      const { data } = await client.query({
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        fetchPolicy: "no-cache",
        variables: {
          limit: localLimit,
          nextToken: localToken,
          filter: localFilter
        }
      });

      return {
        result: data?.listDigitalLabInstrumentRepositoryEntrys?.items ?? [],
        latestNextToken:
          data?.listDigitalLabInstrumentRepositoryEntrys?.nextToken ?? null
      };
    } catch (e) {
      return null;
    }
  };
  const handleChange = async (event) => {
    updateLoading(true);
    const globalLimit = event.target.value;
    updateLimit(globalLimit);
    setSelected(globalLimit);
    setPageIndex(0);
    let instrumentList = [];
    let recursiveNextToken = null;

    do {
      const localLimit = globalLimit - instrumentList.length;
      if (localLimit <= 0) {
        break;
      }
      const { result, latestNextToken } = await loadRecursiveData(
        localLimit,
        recursiveNextToken
      );
      instrumentList.push(...result);
      recursiveNextToken = latestNextToken;
    } while (recursiveNextToken !== null);
    updatePageTokenArray({ pageIndex: 0, token: null });
    loadInstruments({
      instruments: instrumentList ? instrumentList : []
    });
    updateNextToken(recursiveNextToken);
    updateLoading(false);
  };

  return (
    <PageRowNuberSelectorStyled>
      <div>Rows per page: </div>
      <FormControl variant="outlined">
        <PaginatorSelect
          margin="dense"
          labelId="paginator-row-number-selector"
          data-testid="paginator-row-number-selector"
          id="paginator-row-number-selector"
          value={selected}
          onChange={handleChange}
          disabled={disabled}
        >
          <MenuItem
            data-testid="paginator-row-number-selector-item-v5"
            value={5}
          >
            5
          </MenuItem>
          <MenuItem
            data-testid="paginator-row-number-selector-item-v10"
            value={10}
          >
            10
          </MenuItem>
          <MenuItem
            data-testid="paginator-row-number-selector-item-v20"
            value={20}
          >
            20
          </MenuItem>
          <MenuItem
            data-testid="paginator-row-number-selector-item-v50"
            value={50}
          >
            50
          </MenuItem>
        </PaginatorSelect>
      </FormControl>
    </PageRowNuberSelectorStyled>
  );
};

const PaginationActionsStyled = styled.div`
  display: flex;
  justify-content: flex-end;
  height: 70px;
  width: 100%;
  & > .pagination {
    display: flex;
    background-color: #ffffff;
    width: 100%;
    justify-content: flex-end;
    padding: 0 0.5rem;
    align-items: center;
    & button:first-of-type {
      margin-left: 10px;
    }
  }
`;

export const PaginationActions = ({
  updateLimit,
  limit,
  loadInstruments,
  client,
  nextToken,
  updateNextToken,
  updatePageTokenArray,
  pageTokenArray,
  filters,
  search,
  groupList,
  categoryList,
  manufacturerList,
  responsiblePersonList,
  siteList,
  filterApplied,
  updateLoading,
  loading
}) => {
  const [pageIndex, setPageIndex] = useState(0);
  useEffect(() => {
    setPageIndex(0);
  }, [search]);
  const filterInstrumentList = async (
    limit = DEFAULT_LIMIT,
    token = null,
    filter = null
  ) => {
    try {
      const result = await client.query({
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        fetchPolicy: "no-cache",
        variables: {
          limit: limit,
          nextToken: token,
          filter: filter
        }
      });
      return {
        nextToken:
          result?.data?.listDigitalLabInstrumentRepositoryEntrys?.nextToken,
        items: result?.data?.listDigitalLabInstrumentRepositoryEntrys?.items
      };
    } catch (err) {
      Notify({
        type: "warning",
        icon: "caution",
        appName: "",
        text: `Filter failed! `
      });
      console.warn(err);
      return null;
    }
  };
  const localFilterObject = () => {
    return filterApplied
      ? getFilterObject({
          filters,
          search,
          groupList,
          categoryList,
          siteList,
          manufacturerList,
          responsiblePersonList
        })
      : search
      ? {
          and: [{ serialNumber: { beginsWith: search } }]
        }
      : null;
  };

  return (
    <PaginationActionsStyled>
      <div className="pagination" data-testid="pagination-action">
        <PageRowNuberSelector
          updateLimit={updateLimit}
          limit={limit}
          loadInstruments={loadInstruments}
          client={client}
          updateNextToken={updateNextToken}
          pageTokenArray={pageTokenArray}
          updatePageTokenArray={updatePageTokenArray}
          setPageIndex={setPageIndex}
          filterInstrumentList={filterInstrumentList}
          localFilterObject={localFilterObject}
          filterApplied={filterApplied}
          search={search}
          updateLoading={updateLoading}
          disabled={loading}
        />
        <FirstPage
          limit={limit}
          client={client}
          disabled={pageIndex === 0 || loading}
          loadInstruments={loadInstruments}
          setPageIndex={setPageIndex}
          localFilterObject={localFilterObject}
          updateNextToken={updateNextToken}
          updatePageTokenArray={updatePageTokenArray}
          updateLoading={updateLoading}
        />
        <ButtonPrev
                      data-testid="button-prev-pagination"
          updateLimit={updateLimit}
          limit={limit}
          loadInstruments={loadInstruments}
          client={client}
          nextToken={nextToken}
          updateNextToken={updateNextToken}
          pageIndex={pageIndex}
          setPageIndex={setPageIndex}
          pageTokenArray={pageTokenArray}
          disabled={pageIndex === 0 || loading}
          filterInstrumentList={filterInstrumentList}
          localFilterObject={localFilterObject}
          filterApplied={filterApplied}
          updateLoading={updateLoading}
        />
        <ButtonNext
           data-testid="button-next-pagination"
          limit={limit}
          loadInstruments={loadInstruments}
          client={client}
          nextToken={nextToken}
          updateNextToken={updateNextToken}
          pageIndex={pageIndex}
          setPageIndex={setPageIndex}
          pageTokenArray={pageTokenArray}
          updatePageTokenArray={updatePageTokenArray}
          filterInstrumentList={filterInstrumentList}
          localFilterObject={localFilterObject}
          filterApplied={filterApplied}
          updateLoading={updateLoading}
          loading={loading}
        />
      </div>
    </PaginationActionsStyled>
  );
};
const mapStateToProps = (state) => ({
  limit: state.instruments?.limit,
  loading: state.instruments?.loading,
  nextToken: state.instruments?.nextToken,
  pageTokenArray: state.instruments?.pageTokenArray,
  filters: state.instruments?.filters,
  search: state.instruments?.search,
  filterApplied: state.instruments?.filterApplied,
  groupList: state.instruments?.groupList,
  manufacturerList: state.instruments?.manufacturerList,
  categoryList: state.instruments?.categoryList,
  responsiblePersonList: state.instruments?.responsiblePersonList,
  siteList: state.user?.sites ?? []
});

export default compose(
  connect(mapStateToProps, {
    updateLimit: updateLimitAction,
    loadInstruments: loadInstrumentsAction,
    updateNextToken: updateNextTokenAction,
    updatePageTokenArray: updatePageTokenArrayAction,
    updateLoading: updateLoadingAction
  }),
  withApollo
)(PaginationActions);
