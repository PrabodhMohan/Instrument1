import React, { useCallback, useEffect } from "react";
import styled, { css } from "styled-components";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import MuiDialogContent from "@material-ui/core/DialogContent";
import MuiDialogActions from "@material-ui/core/DialogActions";
import { Backdrop, CircularProgress, IconButton } from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import BasicDataAdditionalInfoForm from "./BasicDataAdditionalInfoForm";
import BasicDataReqFieldsForm from "./BasicDataReqFieldsForm";
import TabsForModalEditInstrument from "./TabsForModalEditInstrument";
import AssaysDataForm from "./AssaysDataForm";
import DocumentsDataForm from "./DocumentsDataForm";
import { useFormik } from "formik";
import * as yup from "yup";
import { set } from "lodash";
import { DEFAULT_SITE_NAME, DEFAULT_SITE_TIMEZONE } from "../../constants";
import { comparatorInstrument } from "./redux/reducer";

const styles = theme => ({
  root: {
    margin: 0,
    padding: `20px 0 20px 16px`,
    borderBottom: "1px solid #D3D3D3"
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});
const ModalTitle = styled.div`
  font-size: 16px;
  font-weight: 500;
  line-height: 19px;
  color: #333333;
`;
const DialogTitle = withStyles(styles)(props => {
  const { children, classes, onClose, ...other } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root} {...other}>
      <ModalTitle>{children}</ModalTitle>
      {onClose ? (
        <IconButton
          aria-label="close"
          className={classes.closeButton}
          onClick={onClose}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});

const actionOutlinedStyles = css`
  background-color: #fafafa;
  border: 1px solid #bababa;
`;

export const ActionbuttonStyled = styled(Button)`
  && {
    margin-right: 16px;
    text-transform: capitalize;
    ${props =>
      props.variant && props.variant === "outlined" && actionOutlinedStyles}
  }
`;
const DialogContent = withStyles(theme => ({
  root: {
    padding: `${theme.spacing(0)}px ${theme.spacing(0)}px`,
    backgroundColor: "#ffffff",
    borderTop: "1px solid #D3D3D3",
    borderBottom: "1px solid #D3D3D3",
    height: "500px"
  }
}))(MuiDialogContent);

const DialogActions = withStyles(() => ({
  root: {
    margin: 0,
    padding: "20px 0px 16px 16px"
  }
}))(MuiDialogActions);

const DialogForm = styled.form`
  max-height: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
`;

export const emptyInstruments = {
  siteName: DEFAULT_SITE_NAME,
  siteTimezone: DEFAULT_SITE_TIMEZONE,
  belongingToGroup: "",
  floorAndRoomLocation: {
    isSynchronized: false,
    value: ""
  },
  instrumentGTIN: {
    isSynchronized: false,
    value: ""
  },
  buildingLocation: {
    key: "",
    value: ""
  },
  instrumentGxPStatus:"",
  instrumentRUDI: "",
  instrumentName: {
    isSynchronized: false,
    value: ""
  },
  instrumentType:"",
  isBookable: false,
  isVisualized: false,
  materialNumber: "",
  responsiblePerson: {
    isSynchronized: false,
    value: ""
  },
  softwareVersion: "",
  systemStatus: {
    isSynchronized: false,
    value: ""
  },
  serialNumber: "",
  configurationBaseline: "",
  dateOfLastMaintanance: {
    isSynchronized: false,
    value: null
  },
  dateOfNextMaintanance: {
    isSynchronized: false,
    value: null
  },
  qualificationDocuments: {
    isSynchronized: false,
    value: []
  },
  installedTests: [],
  secondResponsiblePerson: {
    isSynchronized: false,
    value: ""
  },
  equipmentId: {
    isSynchronized: false,
    value: ""
  },
  manufacturer: {
    key: "",
    value: ""
  },
  systemOwner:"",
  technicalPlace:"",
  remark:"",
  instrumentDescription:{
    key:"",
    value:""
  },
  module:{
    key:"",
    value:""
  },
  sop:{
    key:"",
    value:""
  },
  csv:"",
  electronicRecord:"",
  electronicSignatures:"",
  dateOfNextPeriodicReview:"",
  maintenancePlan:"",
  gxpRelevant:"",
  location:"",
  sourceSystem:"",
  testEquipment:"",
  equipmentCategory:{
    key:"",
    value:""
  }

};

const useStyles = makeStyles(() => ({
  dialog: {
    width: 550
  },
  backdrop: {
    zIndex: 2000,
    position: "absolute"
  }
}));
const getCustomNullableBool = () =>
  yup
    .bool()
    .nullable()
    .default(false)
    .transform(value => value ?? false);

const getCustomNullable = (schema, changeTo = "") =>
  schema.nullable().transform(value => value ?? changeTo);

const validationSchema = yup.object({
  siteName: getCustomNullable(
    yup.string("Select site").required("Site is required")
  ),
  siteTimezone: getCustomNullable(
    yup.string("Select timezone").required("Timezone is required")
  ),
  serialNumber: getCustomNullable(
    yup
      .string("Enter serial number")
      .test("unique", "Serial and material numers are not unique", function (
        val,
        context
      ) {
        const materialNumber = this.parent.materialNumber;
        const { instruments = [], isEdit } = context.options.context;
        if (isEdit) return true;
        return !instruments.some(existingInstrument =>
          comparatorInstrument(existingInstrument, {
            materialNumber,
            serialNumber: val
          })
        );
      })
      .required("Serial number is required")
  ),
  materialNumber: getCustomNullable(
    yup
      .string("Enter material number")
      .test("unique", "Material and serial numers are not unique", function (
        val,
        context
      ) {
        const serialNumber = this.parent.serialNumber;
        const { instruments = [], isEdit } = context.options.context;
        if (isEdit) return true;
        return !instruments.some(existingInstrument =>
          comparatorInstrument(existingInstrument, {
            serialNumber,
            materialNumber: val
          })
        );
      })
      .required("Material number is required")
  ),
  instrumentRUDI: getCustomNullable(yup.string("Enter RUDI number")),
  buildingLocation: yup
    .object({
      value: getCustomNullable(yup.string("Enter building location")),
      isSynchronized: getCustomNullableBool()
    })
    .nullable(),
  instrumentGTIN: yup
    .object({
      value: getCustomNullable(
        yup
          .string("Enter instrument GTIN")
          .required("instrument GTIN is required")
      ),
      isSynchronized: getCustomNullableBool()
    })
    .typeError("Enter instrument GTIN"),
  instrumentName: yup
    .object({
      value: getCustomNullable(
        yup
          .string("Enter instrument name")
          .required("Instrument name is required")
      ),
      isSynchronized: getCustomNullableBool()
    })
    .typeError("Enter instrument name"),
  instrumentType: yup
    .object({
      value: getCustomNullable(
        yup
          .string("Enter instrument type")
          .required("Instrument type is required")
      ),
      isSynchronized: getCustomNullableBool()
    })
    .typeError("Enter instrument type"),
  isBookable: getCustomNullableBool(),
  isVisualized: getCustomNullableBool(),
  floorAndRoomLocation: yup
    .object({
      value: getCustomNullable(yup.string("Enter instrument location")),
      isSynchronized: getCustomNullableBool()
    })
    .nullable(),
  responsiblePerson: yup
    .object({
      value: getCustomNullable(yup.string("Enter responsible person")),
      isSynchronized: getCustomNullableBool()
    })
    .nullable(),
  softwareVersion: getCustomNullable(yup.string("Enter software version")),

  configurationBaseline: getCustomNullable(
    yup.string("Enter configuration baseline")
  ),
  systemStatus: yup
    .object({
      value: getCustomNullable(yup.string("Enter system status")),
      isSynchronized: getCustomNullableBool()
    })
    .nullable(),
  instrumentGxPStatus: getCustomNullable(
    yup.string("Enter instrument GxP Status")
  ),
  belongingToGroup: getCustomNullable(yup.string("Enter belonging to group")),
  equipmentId: yup
    .object({
      value: getCustomNullable(
        yup.string("Enter equipment ID").required("Equipment ID is required")
      ),
      isSynchronized: getCustomNullableBool()
    })
    .typeError("Enter equipment ID"),
  manufacturer: yup
    .object({
      value: getCustomNullable(yup.string("Enter manufacturer")),
      isSynchronized: getCustomNullableBool()
    })
    .nullable(),
  secondResponsiblePerson: yup
    .object({
      value: getCustomNullable(yup.string("Enter second responsible person")),
      isSynchronized: getCustomNullableBool()
    })
    .nullable(),
  dateOfLastMaintanance: yup
    .object({
      value: yup.date().typeError("invalid date").nullable(),
      isSynchronized: getCustomNullableBool()
    })
    .nullable(),
  dateOfNextMaintanance: yup
    .object({
      value: yup.date().typeError("invalid date").nullable(),
      isSynchronized: getCustomNullableBool()
    })
    .nullable(),
  installedTests: getCustomNullable(yup.array(), []),
  qualificationDocuments: yup
    .object({
      value: getCustomNullable(yup.array(), []),
      isSynchronized: getCustomNullableBool()
    })
    .nullable()
});

const DialogActionsPart = ({ onCancel, instrument }) => {
  return (
    <DialogActions data-testid="instrument-repositorium-modal-action-buttons">
      <ActionbuttonStyled
        data-testid="instrument-repositorium-modal-action-button-cancel"
        variant="outlined"
        onClick={onCancel}
        color="primary"
      >
        Cancel
      </ActionbuttonStyled>
      <ActionbuttonStyled
        data-testid="instrument-repositorium-modal-action-button-confirm"
        autoFocus
        type="submit"
        variant="contained"
        color="primary"
      >
        {instrument?.materialNumber && instrument?.serialNumber
          ? "Confirm changes"
          : "Add instrument"}
      </ActionbuttonStyled>
    </DialogActions>
  );
};

const validateValues = ({ instrument, instruments }) => values => {
  try {
    validationSchema.validateSync(values, {
      abortEarly: false,
      context: {
        instruments,
        isEdit: instrument?.serialNumber && instrument?.materialNumber
      }
    });
  } catch (error) {
    if (error.name !== "ValidationError") {
      throw error;
    }

    return error.inner.reduce((errors, currentError) => {
      errors = set(errors, currentError.path, currentError.message);
      return errors;
    }, {});
  }

  return {};
};

const InstrumentsModal = ({
  open,
  cancel,
  save,
  title,
  instrument = emptyInstruments,
  instruments
}) => {
  const classes = useStyles();

  const formik = useFormik({
    initialValues: { ...emptyInstruments },
    validate: validateValues({ instruments, instrument }),
    onSubmit: values => {
      const {
        dateOfLastMaintanance,
        dateOfNextMaintanance,
        ...newValues
      } = validationSchema.cast(values);
      save({
        ...values,
        ...newValues
      });
    }
  });
  const [choosenTab, setChoosenTab] = React.useState("basicData");
  useEffect(() => {
    const instrumentOrEmpty = instrument || emptyInstruments;

    formik.resetForm({
      values: { ...instrumentOrEmpty }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [instrument]);
  const onCancel = useCallback(() => {
    setChoosenTab("basicData");
    cancel();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <Dialog
      classes={{
        paper: classes.dialog
      }}
      onClose={cancel}
      open={open}
      data-testid="modal-for-instrument-editing"
    >
      <Backdrop classes={{ root: classes.backdrop }} open={formik.isSubmitting}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <DialogForm
        data-testid="instrument-repositorium-modal-form"
        noValidate
        onSubmit={e => {
          formik.handleSubmit(e);
          setChoosenTab("basicData");
        }}
      >
        <DialogTitle
          data-testid="instrument-repositorium-modal-title"
          onClose={cancel}
        >
          {title}
        </DialogTitle>
        <TabsForModalEditInstrument
          choosenTab={choosenTab}
          setChoosenTab={setChoosenTab}
        />
        <DialogContent
          dividers
          data-testid="instrument-repositorium-modal-content"
        >
          {choosenTab === "basicData" && (
            <>
              <BasicDataReqFieldsForm
                formik={formik}
                isEdit={instrument?.materialNumber && instrument?.serialNumber}
              />
              <BasicDataAdditionalInfoForm formik={formik} />
            </>
          )}
          {choosenTab === "assays" && <AssaysDataForm formik={formik} />}
          {choosenTab === "documents" && <DocumentsDataForm formik={formik} />}
        </DialogContent>
        <DialogActionsPart instrument={instrument} onCancel={onCancel} />
      </DialogForm>
    </Dialog>
  );
};

export default InstrumentsModal;
