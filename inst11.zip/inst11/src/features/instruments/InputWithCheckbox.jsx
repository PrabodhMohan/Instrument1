import React from "react";
import { Checkbox, FormControlLabel, makeStyles } from "@material-ui/core";
import { RowInputs, CheckboxRow } from "./BasicDataReqFieldsForm";

import { RocheTextField } from "@one/react-kit";
import { commonPropsForInputsWithValue } from "./helpers";
import { buttonStyles } from "./buttonStyles";
import { selectedStyles } from "./selectedStyles";

export const useStyles = makeStyles(() => ({
  button: buttonStyles,
  selected: selectedStyles,
  checkbox: {
    color: "#737373",
    marginRight: "3px"
  },
  clearInputButton: {
    color: "#8A8A8A",
    fontSize: "20px",
    paddingRight: 18
  }
}));

const InputWithCheckbox = ({
  formik,
  fieldName,
  testid,
  label,
  isDisabled = false,
  commonProps = commonPropsForInputsWithValue,
  inputProps = {},
  prefixTest = "basic-data-additional-info-fields-instrument",
  isReadOnly = false
}) => {
  const classes = useStyles();
  const checkboxLabel = formik.values?.[fieldName]?.isSynchronized
    ? "Will update"
    : "Update?";
  return (
    <RowInputs>
      <RocheTextField
        data-testid={`${prefixTest}-${testid}-input`}
        color="primary"
        variant="filled"
        fullWidth
        id={fieldName}
        name={isDisabled ? fieldName : `${fieldName}.value`}
        label={label}
        value={
          isDisabled
            ? formik.values?.[fieldName]
            : formik.values?.[fieldName]?.value
        }
        onChange={formik.handleChange}
        disabled={isReadOnly}
        {...commonProps(
          classes,
          formik,
          fieldName,
          testid,
          prefixTest,
          isReadOnly
        )}
        {...inputProps}
      />
      {isDisabled ? (
        <CheckboxRow isDisabled={true}>
          <FormControlLabel
            control={
              <Checkbox
                classes={{
                  root: classes.checkbox
                }}
                disabled
                data-testid={`${prefixTest}-${testid}-disabled-checkbox`}
              />
            }
            label="Update?"
          />
        </CheckboxRow>
      ) : (
        <CheckboxRow isChecked={formik.values?.[fieldName]?.isSynchronized}>
          <FormControlLabel
            data-testid={`${prefixTest}-${testid}-checkbox-label`}
            control={
              <Checkbox
                classes={{
                  root: classes.checkbox
                }}
                color="primary"
                data-testid={`${prefixTest}-${testid}-checkbox`}
                checked={formik.values?.[fieldName]?.isSynchronized}
                onChange={formik.handleChange}
                name={`${fieldName}.isSynchronized`}
              />
            }
            label={checkboxLabel}
          />
        </CheckboxRow>
      )}
    </RowInputs>
  );
};

export default InputWithCheckbox;
