import { makeStyles } from "@material-ui/core";

export const useFormStyles = makeStyles(() => ({
  clearInputButton: {
    color: "#8A8A8A",
    fontSize: "20px",
    paddingRight: 18
  },
  noPaddingButton: {
    padding: 0
  }
}));
