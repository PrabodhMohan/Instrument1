import * as yup from "yup";

/**
 *
 * @param {descriptionValidationSchema} schema the schema which is used to validate that field
 * @param {changeTo} changeTo param to change the value if we need, default to empty string
 * @returns
 */
const getCustomNullable = (schema, changeTo = "") =>
  schema.nullable().transform((value) => value ?? changeTo);

/**
 * schema for validating the equpiment identification form fields
 * have used formik and yup for setting up the validations
 * input type of select is validated against key, value or string based on the options
 * input type of text is validated against string
 */
export const descriptionValidationSchema = yup.object({
  instrumentName: yup
    .object({
      value: yup.string("Name is required").typeError("Name is required")
    })
    .nullable(),
  instrumentGTIN: yup
    .object({
      value: yup.string("GTIN is required").typeError("GTIN is required")
    })
    .nullable(),
  equipmentId: yup
    .object({
      value: yup
        .string("Equipment id is required")
        .typeError("Equipment id is required")
        .required("Equipment id is required")
    })
    .required("Equipment id is required")
    .nullable(),
  instrumentRUDI: getCustomNullable(yup.string().typeError("RUDI is required")),
  equipmentCategory: yup
    .object({
      key: yup.string("Category is required").typeError("Category is required"),
      value: yup.string("Name is required").typeError("Category is required")
    })
    .nullable(),
  technicalPlace: getCustomNullable(yup.string().typeError("Site is required")),
  remark: getCustomNullable(yup.string().typeError("Comments is required"))
});
