import * as yup from "yup";

/**
 *
 * @param {laboratoryValidationSchema} schema the schema which is used to validate that field
 * @param {changeTo} changeTo param to change the value if we need, default to empty string
 * @returns
 */
const getCustomNullable = (schema, changeTo = "") =>
  schema.nullable().transform((value) => value ?? changeTo);

/**
 * schema for validating the equpiment identification form fields
 * have used formik and yup for setting up the validations
 * input type of select is validated against key, value or string based on the options
 * input type of text is validated against string
 */
export const laboratoryValidationSchema = yup.object({
  belongingToGroup: getCustomNullable(
    yup.string().required("Belonging to group is required")
  ),
  buildingLocation: yup
    .object({
      key: yup
        .string("Building is required")
        .typeError("Building is required")
        .required("Building is required"),
      value: yup
        .string("Building is required")
        .typeError("Building is required")
        .required("Building is required")
    })
    .required("Building is required")
    .nullable(),
  responsiblePerson: yup
    .object({
      value: yup
        .string("Responsible person is required")
        .typeError("Responsible person is required")
        .required("Responsible person is required")
    })
    .required("Responsible person is required")
    .nullable(),
  secondResponsiblePerson: yup
    .object({
      value: yup
        .string("Second responsible person is required")
        .typeError("Second responsible person is required")
    })
    .nullable(),
  floorAndRoomLocation: yup
    .object({
      value: yup
        .string("Room is required")
        .typeError("Room is required")
        .required("Room is required")
    })
    .required("Room is required")
    .nullable(),
  systemOwner: getCustomNullable(
    yup.string().typeError("systemOwner is required")
  )
});
