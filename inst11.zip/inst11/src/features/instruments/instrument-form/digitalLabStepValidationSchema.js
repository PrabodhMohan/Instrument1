import * as yup from "yup";

/**
 * schema for validating the equpiment identification form fields
 * have used formik and yup for setting up the validations
 * input type of select is validated against key, value or string based on the options
 * input type of text is validated against string
 */
export const digitalLabStepValidationSchema = yup.object({
  isBookable: yup.bool(),
  isVisualized: yup.bool()
});
