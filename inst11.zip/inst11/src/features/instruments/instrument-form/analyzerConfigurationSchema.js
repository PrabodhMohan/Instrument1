import * as yup from "yup";

/**
 *
 * @param {analyzerConfigurationSchema} schema the schema which is used to validate that field
 * @param {changeTo} changeTo param to change the value if we need, default to empty string
 * @returns
 */
const getCustomNullable = (schema, changeTo = "") =>
  schema.nullable().transform((value) => value ?? changeTo);

/**
 * schema for validating the equpiment gxp maintainance form fields
 * have used formik and yup for setting up the validations
 * input type of select is validated against key, value or string based on the options
 * input type of text is validated against string
 */
export const analyzerConfigurationSchema = yup.object({
  softwareVersion: getCustomNullable(
    yup.string().typeError("softwareVersion is required")
  ),
  configurationBaseline: getCustomNullable(
    yup.string().typeError("configurationBaseline is required")
  ),
  installedTests: yup.array(
    yup
      .object({
        name: yup.string("Enter name").typeError("Enter name"),
        version: yup.string("Enter version").typeError("Ente  version")
      })
      .nullable()
  ),
  qualificationDocuments: yup
    .object({
      value: yup.array(
        yup.object({
          name: yup.string("Enter name").typeError("Enter name"),
          documentId: yup
            .string("Enter documentId")
            .typeError("Enter documentId")
        })
      )
    })
    .nullable()
});
