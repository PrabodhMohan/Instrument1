export const findOrFallbackByObject = (
  array,
  obj,
  { propLabel = "value", propValue = "key", defaultValue = "" } = {}
) => {
  const theItem = array.find((item) => item[propValue] === obj?.[propValue]);
  return theItem?.[propLabel] ?? obj?.[propLabel] ?? defaultValue;
};
