import * as yup from "yup";

/**
 *
 * @param {gxpValidationSchema} schema the schema which is used to validate that field
 * @param {changeTo} changeTo param to change the value if we need, default to empty string
 * @returns
 */
const getCustomNullable = (schema, changeTo = "") =>
  schema.nullable().transform((value) => value ?? changeTo);

/**
 * schema for validating the equpiment gxp maintainance form fields
 * have used formik and yup for setting up the validations
 * input type of select is validated against key, value or string based on the options
 * input type of text is validated against string
 */
export const gxpValidationSchema = yup.object({
  sop: yup
    .array(
      yup.object({
        key: yup.string("sop is required").typeError("sop is required"),
        value: yup.string("sop is required").typeError("sop is required")
      })
    )
    .nullable(),
  csv: yup
    .object({
      key: yup.string("csv is required").typeError("csv is required"),
      value: getCustomNullable(
        yup.string().required("csv is required").typeError("csv is required")
      )
    })
    .nullable(),
  electronicSignatures: yup
    .object({
      key: yup
        .string("Electronic Signatures is required")
        .typeError("Electronic Signatures is required"),
      value: getCustomNullable(
        yup
          .string()
          .required("Electronic Signatures is required")
          .typeError("Electronic Signatures is required")
      )
    })
    .nullable(),
  electronicRecord: yup
    .object({
      key: yup
        .string("Electronic Record is required")
        .typeError("Electronic Record is required"),
      value: getCustomNullable(
        yup
          .string()
          .required("Electronic Record is required")
          .typeError("Electronic Record is required")
      )
    })
    .nullable(),
  gxpRelevant: yup
    .object({
      key: yup
        .string("GxP relevant is required")
        .typeError("GxP relevant is required"),
      value: getCustomNullable(
        yup
          .string()
          .required("GxP relevant is required")
          .typeError("GxP relevant is required")
      )
    })
    .nullable(),
  instrumentGxPStatus: yup
    .object({
      key: yup
        .string("GxP state is required")
        .typeError("GxP state is required")
        .required("GxP state is required"),
      value: yup
        .string("GxP state is required")
        .typeError("GxP state is required")
        .required("GxP state is required")
    })
    .required("GxP state is required")
    .nullable(),
  dateOfNextPeriodicReview: yup.date().typeError("Invalid date").nullable(),
  dateOfNextMaintanance: yup.object({
    value: yup.date().typeError("Invalid date").nullable()
  }),
  dateOfLastMaintanance: yup.object({
    value: yup.date().typeError("Invalid date").nullable()
  }),
  maintenancePlan: yup
    .string("Maintenance plan is required")
    .typeError("Maintenance plan is required")
});
