import { identificationValidationSchema } from "./identificationValidationSchema";
import { descriptionValidationSchema } from "./descriptionValidationSchema";
import { gxpValidationSchema } from "./gxpValidationSchema";
import { laboratoryValidationSchema } from "./laboratoryValidationSchema";
import { analyzerConfigurationSchema } from "./analyzerConfigurationSchema";
import { digitalLabStepValidationSchema } from "./digitalLabStepValidationSchema";
import {
  emptyEquipmentDescription,
  emptyInstrumentIdentification,
  GXPemptyInstruments,
  emptyLaboratoryInfo,
  emptyAnalyzerConfiguration,
  emptyDigitalLabInfo
} from "./../../../constants";
export const getValidationSchema = (activeStep) => {
  switch (activeStep) {
    case 0:
      return identificationValidationSchema;
    case 1:
      return descriptionValidationSchema;
    case 2:
      return laboratoryValidationSchema;
    case 3:
      return gxpValidationSchema;
    case 4:
      return analyzerConfigurationSchema;
    case 5:
      return digitalLabStepValidationSchema;

    default:
      return "Invalid Schema";
  }
};

export const getInitialValue = (activeStep) => {
  switch (activeStep) {
    case 0:
      return emptyInstrumentIdentification;
    case 1:
      return emptyEquipmentDescription;
    case 2:
      return emptyLaboratoryInfo;
    case 3:
      return GXPemptyInstruments;
    case 4:
      return emptyAnalyzerConfiguration;
    case 5:
      return emptyDigitalLabInfo;
    default:
      return "Invalid Schema";
  }
};
