import * as yup from "yup";

/**
 *
 * @param {identificationValidationSchema} schema the schema which is used to validate that field
 * @param {changeTo} changeTo param to change the value if we need, default to empty string
 * @returns
 */
const getCustomNullable = (schema, changeTo = "") =>
  schema.nullable().transform((value) => value ?? changeTo);

/**
 * schema for validating the equpiment identification form fields
 * have used formik and yup for setting up the validations
 * input type of select is validated against key, value or string based on the options
 * input type of text is validated against string
 */
export const identificationValidationSchema = yup.object({
  siteName: getCustomNullable(
    yup.string().required("Site is required").typeError("Site is required")
  ),
  manufacturer: yup
    .object({
      key: yup
        .string("Manufacturer is required")
        .typeError("Manufacturer is required")
        .required("Manufacturer is required"),
      value: yup
        .string("Manufacturer is required")
        .typeError("Manufacturer is required")
        .required("Manufacturer is required")
    })
    .required("Manufacturer is required")
    .nullable(),
  instrumentDescription: yup
    .object({
      key: yup
        .string("Description is required")
        .typeError("Description is required"),
      value: yup
        .string("Description is required")
        .typeError("Description is required")
    })
    .nullable(),
  instrumentType: getCustomNullable(yup.string().required("Type is required")),
  module: yup
    .object({
      key: yup.string("Module is required").typeError("Module is required"),
      value: yup.string("Module is required").typeError("Module is required")
    })
    .nullable(),
  serialNumber: getCustomNullable(
    yup.string().trim().required("Serial number is required")
  ),
  materialNumber: getCustomNullable(yup.string().trim())
});
