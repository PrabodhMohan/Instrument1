import CustomSelect from "../../../components/shared/CustomSelect";
// import { useFormikContext } from "formik";
// import { findOrFallbackByObject } from "./find-or-fallback-by-object";
// import { find } from "lodash";
import { render, cleanup, waitFor, fireEvent } from "@testing-library/react";
import SelectInput from './select-input';

afterEach(cleanup);

const testStyle = {
    color: "#0066cc"
};

test("should create custom select", () => {
    const { queryByTestId } = render( 
      < CustomSelect/> 
    );
    expect(queryByTestId("select-inp")).toBeDefined();
}); 

test("should create span inp", () => {
    const { queryByTestId } = render( 
      <SelectInput/> 
    );
    expect(queryByTestId("select-span")).toBeDefined();
    expect(queryByTestId("select-inp")).toBeDefined();
}); 


test("should render span inp", () => {
    const { queryByTestId } = render( 
      <renderMutiValueObject/> 
    );
    expect(queryByTestId("select-span")).toBeDefined(); 
    expect(queryByTestId("select-inp")).toBeDefined();

});