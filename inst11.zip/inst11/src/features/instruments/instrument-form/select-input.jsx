import CustomSelect from "../../../components/shared/CustomSelect";
import { useFormikContext } from "formik";
import { findOrFallbackByObject } from "./find-or-fallback-by-object";
import { find } from "lodash";

const testStyle = {
  color: "#0066cc"
};

const SelectInput = ({
  options,
  property,
  Selectlabel,
  testid,
  propValue,
  propLabel,
  className,
  testidPrefix,
  customMethodInHandleChange,
  multiple = false,
  required = false,
  fullWidth = multiple,
  objectAsValue = false
}) => {
  const formik = useFormikContext();
  let selectValue;
  let renderValue;
  const renderValueObject = () =>
    findOrFallbackByObject(options, formik.values[property], {
      propValue,
      propLabel
    });
  const renderMutiValueObject = (selectedValue) => {
    let renderTag;
    if (selectedValue.length <= 1) {
      renderTag = <span>{selectedValue[0]?.value || ""}</span>;
    } else {
      renderTag = (
        <span data-testid="select-span"
        >
          {selectedValue[0]?.value || ""}
          <span style={testStyle}> +{selectedValue.length - 1}</span>
        </span>
      );
    }
    return <>{renderTag}</>;
  };

  if (multiple && objectAsValue) {
    selectValue =
      formik.values[property]?.length > 0
        ? options.filter((value) => {
            const obj = find(formik.values[property], { key: value.key });
            return obj;
          })
        : [];
    renderValue = renderMutiValueObject;
  } else if (multiple) {
    selectValue = formik.values[property] ?? [];
  } else if (objectAsValue) {
    selectValue = formik.values[property]?.[propValue] ?? "";
    renderValue = renderValueObject;
  } else {
    selectValue = formik.values[property] ?? "";
    renderValue = undefined;
  }

  const handleChange = (event) => {
    customMethodInHandleChange?.(event.target.value);
    if (!objectAsValue || (multiple && objectAsValue)) {
      return formik.handleChange(event);
    }

    const obj = options.find((item) => item.key === event.target.value);

    return formik.handleChange({
      ...event,
      target: {
        ...event.target,
        value: obj
          ? {
              key: obj.key,
              value: obj.value
            }
          : null
      }
    });
  };
  return (
    <CustomSelect data-testid="select-inp"

      onBlur={formik.handleBlur}
      variant="filled"
      options={options}
      required={required}
      name={property}
      className={className}
      onChange={handleChange}
      selectLabel={Selectlabel}
      propValue={propValue}
      propLabel={propLabel}
      testid={`${testidPrefix}-inputs-${testid}-input`}
      error={formik.touched[property] && Boolean(formik.errors[property])}
      helperText={formik.errors[property]?.value ?? formik.errors[property]}
      multiple={multiple}
      fullWidth={fullWidth}
      value={selectValue}
      renderValue={renderValue}
    />
  );
};

export default SelectInput;
