import React from "react";
import FilterAction from "./FilterAction";
import { render, cleanup, fireEvent } from "../../test-utils";

test("should create filter action", () => {
    const { queryByTestId } = render( 
      < FilterAction/>     );
    expect(queryByTestId("instrument-repositorium-modal-action-button-confirm")).toBeDefined();
}); 
 