import React from "react";
import styled from "styled-components";
import Search from "./Search";

export const TopBarStyled = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: centre;
  height: 40px;
  margin-bottom: 30px;
  margin-top: 15px;
`;

const TopBar = ({ setQuery, label, "data-testid": dataTestId, children }) => {
  return (
    <TopBarStyled>
      <Search setQuery={setQuery} label={label} data-testid={dataTestId} />
      {children}
    </TopBarStyled>
  );
};

export default TopBar;
