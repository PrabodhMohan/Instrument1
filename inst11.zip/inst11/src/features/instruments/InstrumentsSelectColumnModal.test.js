import React, { useCallback,useState } from "react";
import styled, { css } from "styled-components";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import MuiDialogContent from "@material-ui/core/DialogContent";
import MuiDialogActions from "@material-ui/core/DialogActions";
import { Backdrop, CircularProgress, IconButton } from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import DraggableTable from "./instrument-draggable-form/DraggableTable";
import { UPDATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE_PERSONAL_FIELDS } from "../../gql/landingapi/mutations";
import Notify from "../notifications/Notify";
import { withApollo } from "react-apollo";
import { compose } from "redux";
import { connect } from "react-redux";
import { loadUserInfo as loadUserInfoAction } from "../user/redux/actions";
import InstrumentsSelectColumnModal from './InstrumentsSelectColumnModal'
import { updateInstrumentsBatchFlow } from "./utils/updateInstrumentsBatchFlow";
import { filterDataToImport } from "./utils/structure";


import { render, cleanup } from "../../test-utils";
import InstrumentsMainPage from "./InstrumentsMainPage";

jest.mock("../instruments/redux/actions");
jest.mock("./utils/updateInstrumentsBatchFlow");
jest.mock("./components/ImportInstrumentsDialog", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});
jest.mock("./utils/structure");
jest.mock("../notifications/Notify");

const styles = (theme) => ({
  root: {
    margin: 0,
    padding: `20px 0 20px 16px`,
    borderBottom: "1px solid #D3D3D3"
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});
const ModalTitle = styled.div`
  font-size: 16px;
  font-weight: 500;
  line-height: 19px;
  color: #333333;
`;
const DialogTitle = withStyles(styles)((props) => {
  const { children, classes, onClose, ...other } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root} {...other}>
      <ModalTitle>{children}</ModalTitle>
      {onClose ? (
        <IconButton
          aria-label="close"
          className={classes.closeButton}
          onClick={onClose}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});

const actionOutlinedStyles = css`
  background-color: #fafafa;
  border: 1px solid #bababa;
`;

export const ActionbuttonStyled = styled(Button)`
  && {
    margin-right: 16px;
    text-transform: capitalize;
    ${(props) =>
      props.variant && props.variant === "outlined" && actionOutlinedStyles}
  }
`;
const DialogContent = withStyles((theme) => ({
  root: {
    padding: `${theme.spacing(0)}px ${theme.spacing(0)}px`,
    backgroundColor: "#ffffff",
    borderTop: "1px solid #D3D3D3",
    borderBottom: "1px solid #D3D3D3",
    height: "500px"
  }
}))(MuiDialogContent);

const DialogActions = withStyles(() => ({
  root: {
    margin: 0,
    padding: "20px 0px 16px 16px"
  }
}))(MuiDialogActions);

const DialogForm = styled.form`
  max-height: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
`;

const useStyles = makeStyles(() => ({
  dialog: {
    width: 617
  },
  backdrop: {
    zIndex: 2000,
    position: "absolute"
  }
}));


 
afterEach(cleanup);

test("should create with table mock", () => {
  const { queryByTestId } = render(<ActionbuttonStyled/>);
  expect(queryByTestId("instrument-repositorium-modal-action-button-cancel")).toBeDefined();
  expect(queryByTestId("instrument-repositorium-modal-action-button-confirm")).toBeDefined();
});

test("should create with dialogue content", () => {
    const { queryByTestId } = render(<DialogContent/>);
    expect(queryByTestId("instrument-repositorium-modal-content")).toBeDefined();
   });
  
 test("should create with dialogue content part", () => {
    const { queryByTestId } = render(<DialogActionsPart/>);
    expect(queryByTestId("instrument-repositorium-modal-content-part")).toBeDefined();
});
 
test("should show notification with error", async () => {
  ImportInstrumentsDialog.mockImplementation(ImportInstrumentsDialogTest);
  const mockNotify = jest.fn();
  Notify.mockImplementation(mockNotify);
  filterDataToImport.mockImplementation(() => {
    throw new Error("Error message");
  });
  updateInstrumentsBatchFlow.mockReturnValue(
    Promise.resolve([
      {
        status: "fulfilled",
        value: {
          errors: []
        }
      }
    ])
  );

  const { getByTestId } = render(
    <FileContextWapper instruments={[]}>
      <UploadInstruments />
    </FileContextWapper>
  );
  const onUploadInstruments = getByTestId("onUploadInstruments");
  const uploading = getByTestId("uploading");

  expect(uploading.textContent).toEqual("not uploading");
  fireEvent.click(onUploadInstruments);
  await waitFor(() => {
    expect(mockNotify).toHaveBeenCalledTimes(1);
    expect(mockNotify).toHaveBeenLastCalledWith({
      type: "warning",
      icon: "caution",
      appName: "",
      text: `Error message`
    });
    expect(uploading.textContent).toEqual("not uploading");
  });

  filterDataToImport.mockImplementation(() => {
    throw new Error("");
  });
  fireEvent.click(onUploadInstruments);
  await waitFor(() => {
    expect(mockNotify).toHaveBeenCalledTimes(2);
    expect(mockNotify).toHaveBeenLastCalledWith({
      type: "warning",
      icon: "caution",
      appName: "",
      text: `Error`
    });
  });
});
