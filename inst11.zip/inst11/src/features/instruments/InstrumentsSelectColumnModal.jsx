import React, { useCallback,useState } from "react";
import styled, { css } from "styled-components";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import MuiDialogContent from "@material-ui/core/DialogContent";
import MuiDialogActions from "@material-ui/core/DialogActions";
import { Backdrop, CircularProgress, IconButton } from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import DraggableTable from "./instrument-draggable-form/DraggableTable";
import { UPDATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE_PERSONAL_FIELDS } from "../../gql/landingapi/mutations";
import Notify from "../notifications/Notify";
import { withApollo } from "react-apollo";
import { compose } from "redux";
import { connect } from "react-redux";
import { loadUserInfo as loadUserInfoAction } from "../user/redux/actions";

const styles = (theme) => ({
  root: {
    margin: 0,
    padding: `20px 0 20px 16px`,
    borderBottom: "1px solid #D3D3D3"
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});
const ModalTitle = styled.div`
  font-size: 16px;
  font-weight: 500;
  line-height: 19px;
  color: #333333;
`;
const DialogTitle = withStyles(styles)((props) => {
  const { children, classes, onClose, ...other } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root} {...other}>
      <ModalTitle>{children}</ModalTitle>
      {onClose ? (
        <IconButton
          aria-label="close"
          className={classes.closeButton}
          onClick={onClose}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});

const actionOutlinedStyles = css`
  background-color: #fafafa;
  border: 1px solid #bababa;
`;

export const ActionbuttonStyled = styled(Button)`
  && {
    margin-right: 16px;
    text-transform: capitalize;
    ${(props) =>
      props.variant && props.variant === "outlined" && actionOutlinedStyles}
  }
`;
const DialogContent = withStyles((theme) => ({
  root: {
    padding: `${theme.spacing(0)}px ${theme.spacing(0)}px`,
    backgroundColor: "#ffffff",
    borderTop: "1px solid #D3D3D3",
    borderBottom: "1px solid #D3D3D3",
    height: "500px"
  }
}))(MuiDialogContent);

const DialogActions = withStyles(() => ({
  root: {
    margin: 0,
    padding: "20px 0px 16px 16px"
  }
}))(MuiDialogActions);

const DialogForm = styled.form`
  max-height: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
`;

const useStyles = makeStyles(() => ({
  dialog: {
    width: 617
  },
  backdrop: {
    zIndex: 2000,
    position: "absolute"
  }
}));

const DialogActionsPart = ({ onCancel,confirmColumn }) => {
  return (
    <DialogActions data-testid="instrument-repositorium-modal-action-buttons">
      <ActionbuttonStyled
        data-testid="instrument-repositorium-modal-action-button-cancel"
        variant="outlined"
        onClick={onCancel}
        color="primary"
      >
        Cancel
      </ActionbuttonStyled>
      <ActionbuttonStyled
        data-testid="instrument-repositorium-modal-action-button-confirm"
        autoFocus
        variant="contained"
        color="primary"
        onClick={confirmColumn}
      >
        Confirm
      </ActionbuttonStyled>
    </DialogActions>
  );
};

const InstrumentsSelectColumnModal = ({
  client,
  user,
  open,
  cancel,
  loadUserInfo
}) => {
  const classes = useStyles();
  const onCancel = useCallback(() => {
    cancel();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [showList , setShowList] = useState([]);
  const [hideList , setHideList] = useState([]);
  const updateLastFilter = async (data) => {
    try {
      const result = await client.mutate({
        mutation: UPDATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE_PERSONAL_FIELDS,
        variables: {
          ...data
        },
        fetchPolicy: "no-cache"
      });
      return result?.data?.updateDigitalLabInstrumentRepositoryUserProfile;
    } catch (error) {
      return null;
    }
  };

  const confirmColumn = async() =>{
    user.lastFilter = {
      ...user.lastFilter,
      showColumns:showList,
      hideColumns:hideList
    };
    user.lastFilter = JSON.stringify(user.lastFilter);
    const result = await updateLastFilter(user);
    if (result) {
      if (result?.lastFilter) {
        try { 
          user.lastFilter = JSON.parse(user.lastFilter);
          loadUserInfo(user);
        } catch (error) {
          loadUserInfo(user);
        }
      }
      Notify({
        type: "success",
        icon: "yes",
        appName: "",
        text:  `Saved select columns successfully! `
      });
     
    } else {
      Notify({
        type: "warning",
        icon: "caution",
        appName: "",
        text:  `Saved select columns  failed! `
      });
    }
    onCancel();
    
  }
   
  return (
    <Dialog
      classes={{
        paper: classes.dialog
      }}
      onClose={cancel}
      open={open}
      data-testid="modal-for-instrument-editing"
    >
      <Backdrop classes={{ root: classes.backdrop }}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <DialogForm data-testid="instrument-repositorium-modal-form">
        <DialogTitle
          data-testid="instrument-repositorium-modal-title"
          onClose={cancel}
        >
          Equipment repository columns and order
        </DialogTitle>

        <DialogContent
          dividers
          data-testid="instrument-repositorium-modal-content"
        >
          <DraggableTable setShowList={setShowList} setHideList={setHideList} />
        </DialogContent>
        <DialogActionsPart   onCancel={onCancel} confirmColumn={confirmColumn} />
      </DialogForm>
    </Dialog>
  );
};

const mapStateToProps = (state) => ({
  user: state.user
});
export default compose(
  connect(mapStateToProps,
     {
       loadUserInfo : loadUserInfoAction
     }
  ),
  withApollo
)(InstrumentsSelectColumnModal);

