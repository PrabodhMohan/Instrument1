import React, { useState } from "react";
import { Button, CircularProgress } from "@material-ui/core";
import CloudDownloadOutlined from "@material-ui/icons/CloudDownloadOutlined";
import { withApollo } from "react-apollo";
import { GET_INSTRUMENT_FROM_DATA_RIVER } from "../../gql/landingapi/queries";
import Notify from "../notifications/Notify";

const FetchInstrumentFromDataRiver = ({
  client,
  materialNumber,
  serialNumber,
  onFetched
}) => {
  const [fetching, setFetching] = useState();
  const fetchDataCallback = async () => {
    try {
      setFetching(true);
      const result = await client.query({
        query: GET_INSTRUMENT_FROM_DATA_RIVER,
        fetchPolicy: "no-cache",
        variables: {
          materialNumber,
          serialNumber
        }
      });
      const data = result?.data?.getInstrumentFromDataRiver;
      if (!data) throw new Error("No instrument found");
      onFetched(result?.data?.getInstrumentFromDataRiver);
      Notify({
        type: "success",
        icon: "yes",
        appName: "",
        text: `Instrument have been fetched successfully!`
      });
    } catch (err) {
      Notify({
        type: "warning",
        icon: "caution",
        appName: "",
        text: `Failed to fetch instrument.`
      });
    } finally {
      setFetching(false);
    }
  };
  return (
    <Button
      color="primary"
      startIcon={
        fetching ? <CircularProgress size={18} /> : <CloudDownloadOutlined />
      }
      style={{ textTransform: "initial" }}
      data-testid="fetchInstrumentFromDataRiver"
      onClick={fetchDataCallback}
      disabled={fetching || !serialNumber || !materialNumber}
    >
      Try to fetch data
    </Button>
  );
};

export default withApollo(FetchInstrumentFromDataRiver);
