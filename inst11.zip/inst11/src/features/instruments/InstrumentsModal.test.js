import { render, cleanup, fireEvent } from "../../test-utils";
import InstrumentsModal from "./InstrumentsModal";
import { data } from "../../utils/test/data-test";
import { waitFor } from "@testing-library/react";

afterEach(cleanup);

test("should open modal for editing instrument then call cancel  callback", async () => {
  const open = true;
  const cancel = jest.fn();
  const save = jest.fn();
  const title = "test";
  const instrument = data.instruments.instruments[0];
  const instruments = [...data.instruments.instruments];

  const { getByTestId } = render(
    <InstrumentsModal
      open={open}
      cancel={cancel}
      save={save}
      title={title}
      instrument={instrument}
      instruments={instruments}
    />
  );
  const modal = getByTestId("modal-for-instrument-editing");
  expect(modal).toBeDefined();
  expect(getByTestId("instrument-repositorium-modal-title").textContent).toBe(
    "test"
  );
  const cancelButton = getByTestId(
    "instrument-repositorium-modal-action-button-cancel"
  );
  fireEvent.click(cancelButton);
  expect(cancel).toHaveBeenCalled();
});
test.skip("should create new instrument", async () => {
  const open = true;
  const cancel = jest.fn();
  const save = jest.fn();
  const instruments = undefined;

  const { getByTestId, getByLabelText } = render(
    <InstrumentsModal
      open={open}
      cancel={cancel}
      save={save}
      instrument={null}
      instruments={instruments}
    />,
    {
      initialState: {
        user: {
          sites: [
            {
              siteName: "siteName",
              siteTimezone: "siteTimezone"
            },
            {
              siteName: "siteName 2",
              siteTimezone: "siteTimezone 2"
            }
          ]
        }
      }
    }
  );

  fireEvent.change(getByLabelText(/material number/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/serial number/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/instrument name/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/instrument type/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/gtin number/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/rudi number/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/equipment id/i), {
    target: { value: "test" }
  });

  const siteNameInput = getByTestId(
    "basic-data-req-fields-instrument-siteName"
  ).querySelector("input");
  fireEvent.change(siteNameInput, {
    target: { value: "siteName 2" }
  });

  await waitFor(() => {
    expect(getByLabelText(/material number/i)).toHaveValue("test");
    expect(getByLabelText(/serial number/i)).toHaveValue("test");
    expect(getByLabelText(/instrument name/i)).toHaveValue("test");
    expect(getByLabelText(/instrument type/i)).toHaveValue("test");
    expect(getByLabelText(/gtin number/i)).toHaveValue("test");
    expect(getByLabelText(/rudi number/i)).toHaveValue("test");
    expect(getByLabelText(/equipment id/i)).toHaveValue("test");
    expect(
      getByTestId("basic-data-req-fields-instrument-siteName").querySelector(
        "input"
      )
    ).toHaveValue("siteName 2");
  });

  fireEvent.submit(getByTestId("instrument-repositorium-modal-form"));

  await waitFor(() =>
    expect(save).toHaveBeenCalledWith({
      belongingToGroup: "",
      siteName: "siteName 2",
      siteTimezone: "siteTimezone 2",
      buildingLocation: {
        isSynchronized: false,
        value: ""
      },
      configurationBaseline: "",
      dateOfLastMaintanance: {
        isSynchronized: false,
        value: null
      },
      dateOfNextMaintanance: {
        isSynchronized: false,
        value: null
      },
      floorAndRoomLocation: {
        isSynchronized: false,
        value: ""
      },
      installedTests: [],
      instrumentGTIN: {
        isSynchronized: false,
        value: "test"
      },
      instrumentGxPStatus: {
        isSynchronized: false,
        value: ""
      },
      instrumentName: {
        isSynchronized: false,
        value: "test"
      },
      instrumentRUDI: "test",
      instrumentType: {
        isSynchronized: false,
        value: "test"
      },
      isBookable: false,
      isVisualized: false,
      materialNumber: "test",
      qualificationDocuments: {
        isSynchronized: false,
        value: []
      },
      responsiblePerson: {
        isSynchronized: false,
        value: ""
      },
      secondResponsiblePerson: {
        isSynchronized: false,
        value: ""
      },
      manufacturer: {
        isSynchronized: false,
        value: ""
      },
      equipmentId: {
        isSynchronized: false,
        value: "test"
      },
      serialNumber: "test",
      softwareVersion: "",
      systemStatus: {
        isSynchronized: false,
        value: ""
      }
    })
  );
});

test.skip("should edit  malformed instrument", async () => {
  const open = true;
  const cancel = jest.fn();
  const save = jest.fn();
  const instrument = {
    ...data.instruments.instruments[0],
    equipmentId: {
      isSynchronized: false,
      value: "test"
    },
    responsiblePerson: {
      value: null,
      isSynchronized: null
    },
    instrumentGTIN: {
      value: null,
      isSynchronized: null
    }
  };
  const instruments = [...data.instruments.instruments];

  const { getByTestId, getByLabelText } = render(
    <InstrumentsModal
      open={open}
      cancel={cancel}
      save={save}
      instrument={instrument}
      instruments={instruments}
    />,
    {
      initialState: {
        user: {
          sites: [
            {
              siteName: "siteName",
              siteTimezone: "siteTimezone"
            },
            {
              siteName: "siteName 2",
              siteTimezone: "siteTimezone 2"
            }
          ]
        }
      }
    }
  );

  fireEvent.change(getByLabelText(/instrument name/i), {
    target: { value: "test edit" }
  });

  fireEvent.change(getByLabelText(/gtin/i), {
    target: { value: "test" }
  });
  const siteNameInput = getByTestId(
    "basic-data-req-fields-instrument-siteName"
  ).querySelector("input");
  fireEvent.change(siteNameInput, {
    target: { value: "siteName 2" }
  });

  await waitFor(() => {
    expect(getByLabelText(/instrument name/i)).toHaveValue("test edit");
    expect(getByLabelText(/gtin/i)).toHaveValue("test");
    expect(
      getByTestId("basic-data-req-fields-instrument-siteName").querySelector(
        "input"
      )
    ).toHaveValue("siteName 2");
  });

  fireEvent.submit(getByTestId("instrument-repositorium-modal-form"));

  await waitFor(() =>
    expect(save).toHaveBeenCalledWith({
      ...instrument,
      siteName: "siteName 2",
      siteTimezone: "siteTimezone 2",
      equipmentId: {
        isSynchronized: false,
        value: "test"
      },
      responsiblePerson: {
        value: "",
        isSynchronized: false
      },
      instrumentName: {
        ...instrument.instrumentName,
        value: "test edit"
      },
      instrumentGTIN: {
        value: "test",
        isSynchronized: false
      }
    })
  );
});

test.skip("should edit instrument", async () => {
  const open = true;
  const cancel = jest.fn();
  const save = jest.fn();
  const instrument = data.instruments.instruments[0];
  const instruments = [...data.instruments.instruments];

  const { getByTestId, getByLabelText } = render(
    <InstrumentsModal
      open={open}
      cancel={cancel}
      save={save}
      instrument={instrument}
      instruments={instruments}
    />
  );

  fireEvent.change(getByLabelText(/instrument name/i), {
    target: { value: "test edit" }
  });
  fireEvent.change(getByLabelText(/equipment id/i), {
    target: { value: "test edit" }
  });

  await waitFor(() => {
    expect(getByLabelText(/instrument name/i)).toHaveValue("test edit");
    expect(getByLabelText(/equipment id/i)).toHaveValue("test edit");
  });

  fireEvent.submit(getByTestId("instrument-repositorium-modal-form"));

  await waitFor(() =>
    expect(save).toHaveBeenCalledWith({
      ...instrument,
      equipmentId: {
        __typename: "StringAttribute",
        isSynchronized: false,
        value: "test edit"
      },
      instrumentName: {
        ...instrument.instrumentName,
        value: "test edit"
      }
    })
  );
});

test.skip("should not create new instrument due to not unique material and serial", async () => {
  const open = true;
  const cancel = jest.fn();
  const save = jest.fn();
  const instruments = [...data.instruments.instruments];

  const { getByTestId, getByLabelText } = render(
    <InstrumentsModal
      open={open}
      cancel={cancel}
      save={save}
      instruments={instruments}
    />
  );

  fireEvent.change(getByLabelText(/serial number/i), {
    target: { value: instruments[0].serialNumber }
  });

  fireEvent.change(getByLabelText(/material number/i), {
    target: { value: instruments[0].materialNumber }
  });

  fireEvent.change(getByLabelText(/instrument name/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/instrument type/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/gtin number/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/rudi number/i), {
    target: { value: "test" }
  });

  await waitFor(() => {
    expect(getByLabelText(/rudi number/i)).toHaveValue("test");
    expect(getByLabelText(/instrument name/i)).toHaveValue("test");
    expect(getByLabelText(/instrument type/i)).toHaveValue("test");
    expect(getByLabelText(/gtin number/i)).toHaveValue("test");
    expect(getByLabelText(/material number/i)).toHaveValue(
      instruments[0].materialNumber
    );
    expect(getByLabelText(/serial number/i)).toHaveValue(
      instruments[0].serialNumber
    );
  });

  fireEvent.submit(getByTestId("instrument-repositorium-modal-form"));

  await waitFor(() => {
    expect(save).not.toHaveBeenCalled();
  });
});

test.skip("should switch between tabs", async () => {
  const open = true;

  const { getByTestId, queryByTestId } = render(
    <InstrumentsModal open={open} />
  );

  fireEvent.click(getByTestId("tabs-for-modal-edit-tab-installed-tests"));

  await waitFor(() => expect(queryByTestId("assays-data-form")).not.toBe(null));

  fireEvent.click(getByTestId("tabs-for-modal-edit-tab-documents"));

  await waitFor(() =>
    expect(queryByTestId("documents-data-form")).not.toBe(null)
  );
});
