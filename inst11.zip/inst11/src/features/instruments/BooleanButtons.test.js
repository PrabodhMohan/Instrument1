import { render, cleanup, fireEvent } from "../../test-utils";
import BooleanButtons from "./BooleanButtons";

afterEach(cleanup);

test("should create boolean buttons", () => {
  const onchange = jest.fn();
  const { queryByTestId: getByTestId, rerender } = render(
    <BooleanButtons
      onChange={onchange}
      trueLabel="true label"
      falseLabel="false label"
      value={true}
      trueProps={{
        "data-testid": "true-button"
      }}
      falseProps={{
        "data-testid": "false-button"
      }}
    />
  );
  const trueButton = getByTestId("true-button");
  const falseButton = getByTestId("false-button");
  expect(trueButton).toBeDefined();
  expect(falseButton).toBeDefined();
  expect(trueButton.textContent).toBe("true label");
  expect(falseButton.textContent).toBe("false label");
  fireEvent.click(trueButton);
  expect(onchange).toHaveBeenCalledWith(true);
  rerender(
    <BooleanButtons
      onChange={onchange}
      trueLabel="true label"
      falseLabel="false label"
      value={false}
      trueProps={{
        "data-testid": "true-button"
      }}
      falseProps={{
        "data-testid": "false-button"
      }}
    />
  );
  fireEvent.click(falseButton);
  expect(onchange).toHaveBeenCalledWith(false);
});
