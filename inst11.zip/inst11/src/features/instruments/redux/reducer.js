import * as types from "./actionTypes";
import initialState from "./initialState";

export const comparatorInstrument = (x, y) =>
  x?.materialNumber === y?.materialNumber &&
  x?.serialNumber === y?.serialNumber;

export const keyIds = ["materialNumber", "serialNumber"];

export default function instrumentsReducer(
  state = initialState,
  action = { type: "", payload: {} }
) {
  switch (action?.type) {
    case types.LOAD_INSTRUMENTS:
      return {
        ...state,
        ...action?.payload
      };
    case types.LOAD_ALL_LISTS:
      return {
        ...state,
        buildingList: action?.payload?.listIRBuildingMasters?.items,
        descriptionList: action?.payload?.listIRDescriptionMasters?.items,
        manufacturerList: action?.payload?.listIRManufacturerMasters?.items,
        groupList: action?.payload?.listIRGroupMasters?.items,
        moduleList: action?.payload?.listIRModuleMasters?.items,
        sopList: action?.payload?.listIRSOPMasters?.items,
        typeList: action?.payload?.listIREquipmentTypeConfigurations?.items,
        categoryList:
          action?.payload?.listIREquipmentCategoryConfigurations?.items,
        responsiblePersonList:
          action?.payload?.listIRResponsiblePersonLookups?.items
      };
    case types.UPDATE_INSTRUMENT_DETAIL:
      return {
        ...state,
        instrumentDetail: action?.payload
      };

    case types.UPDATE_INSTRUMENT_FILTER:
      return {
        ...state,
        filters: action?.payload
      };

    case types.UPDATE_LIMIT:
      return {
        ...state,
        limit: action?.payload
      };
    case types.UPDATE_NEXT_TOKEN:
      return {
        ...state,
        nextToken: action?.payload
      };
    case types.RESET_PAGE_TOKEN_ARRAY:
      return {
        ...state,
        pageTokenArray: []
      };
    case types.UPDATE_PAGE_TOKEN_ARRAY:
      return {
        ...state,
        pageTokenArray: [...state.pageTokenArray, action?.payload]
      };
    case types.UPDATE_FILTER_APPLIED:
      return {
        ...state,
        filterApplied: action?.payload
      };
    case types.UPDATE_SEARCH_FILTER:
      return {
        ...state,
        search: action?.payload
      };

    case types.UPDATE_LOADING:
      return {
        ...state,
        loading: action?.payload
      };

    default:
      return state;
  }
}
