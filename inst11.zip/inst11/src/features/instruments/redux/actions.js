import * as types from "./actionTypes";

export const loadInstruments = (instruments) => ({
  type: types.LOAD_INSTRUMENTS,
  payload: instruments
});

export const loadStepFormList = (list) => ({
  type: types.LOAD_ALL_LISTS,
  payload: list ?? []
});

export const updateInstrumentDetail = (payload) => ({
  type: types.UPDATE_INSTRUMENT_DETAIL,
  payload: payload
});

export const updateInstrumentFilter = (payload) => ({
  type: types.UPDATE_INSTRUMENT_FILTER,
  payload: payload
});
export const updateLimit = (payload) => ({
  type: types.UPDATE_LIMIT,
  payload: payload
});
export const updateNextToken = (payload) => ({
  type: types.UPDATE_NEXT_TOKEN,
  payload: payload
});
export const resetPageTokenArray = (payload) => ({
  type: types.RESET_PAGE_TOKEN_ARRAY,
  payload: payload
});
export const updatePageTokenArray = (payload) => ({
  type: types.UPDATE_PAGE_TOKEN_ARRAY,
  payload: payload
});
export const updateFilterApplied = (payload) => ({
  type: types.UPDATE_FILTER_APPLIED,
  payload: payload
});
export const updateSearchFilter = (payload) => ({
  type: types.UPDATE_SEARCH_FILTER,
  payload: payload
});
export const updateLoading = (payload) => ({
  type: types.UPDATE_LOADING,
  payload: payload
});
