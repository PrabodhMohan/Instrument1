import { render, cleanup, fireEvent, waitFor } from "../../test-utils";
import FetchInstrumentFromDataRiver from "./FetchInstrumentFromDataRiver";
import { GET_INSTRUMENT_FROM_DATA_RIVER } from "../../gql/landingapi/queries";
import { data } from "../../utils/test/data-test";
import Notify from "../notifications/Notify";
import { useFormik } from "formik";
import BasicDataReqFieldsForm from "./BasicDataReqFieldsForm";
import { emptyInstruments } from "./InstrumentsModal";

export const TestComponent = ({ submit }) => {
  const formik = useFormik({
    initialValues: {
      ...emptyInstruments
    },
    onSubmit: (values) => {
      if (submit) {
        submit(values);
      }
    }
  });

  return (
    <form data-testid="test-form" onSubmit={formik.handleSubmit}>
      <BasicDataReqFieldsForm formik={formik} />
    </form>
  );
};

afterEach(cleanup);
jest.mock("../notifications/Notify", () => ({
  __esModule: true,
  default: jest.fn()
}));
describe("FetchInstrumentFromDataRiver test", () => {
  test("should call fetch query function", async () => {
    const materialNumber = "542568153454";
    const serialNumber = "SD9212969";
    const onFetched = jest.fn();
    const { getByTestId } = render(
      <FetchInstrumentFromDataRiver
        materialNumber={materialNumber}
        serialNumber={serialNumber}
        onFetched={onFetched}
      />,
      {
        mocksForApollo: [
          {
            request: {
              query: GET_INSTRUMENT_FROM_DATA_RIVER,
              variables: {
                materialNumber,
                serialNumber
              }
            },
            result: {
              data: {
                getInstrumentFromDataRiver: data.instruments.instruments[0]
              }
            }
          }
        ]
      }
    );
    const fetchInstrumentFromDataRiver = getByTestId(
      "fetchInstrumentFromDataRiver"
    );
    expect(getByTestId("fetchInstrumentFromDataRiver")).toBeDefined();
    expect(fetchInstrumentFromDataRiver).toBeEnabled();
    fireEvent.click(fetchInstrumentFromDataRiver);
    expect(fetchInstrumentFromDataRiver).toBeDisabled();
    await waitFor(() => {
      expect(onFetched).toHaveBeenCalledTimes(1);
      expect(onFetched).toHaveBeenCalledWith(data.instruments.instruments[0]);
    });
  });

  test("should show error notification", async () => {
    const materialNumber = "542568153454";
    const serialNumber = "SD9212969";
    const onFetched = jest.fn();
    const notify = jest.fn();
    Notify.mockImplementation(notify);
    const { getByTestId } = render(
      <FetchInstrumentFromDataRiver
        materialNumber={materialNumber}
        serialNumber={serialNumber}
        onFetched={onFetched}
      />,
      {
        mocksForApollo: [
          {
            request: {
              query: GET_INSTRUMENT_FROM_DATA_RIVER,
              variables: {
                serialNumber
              }
            },
            result: {
              data: null
            }
          }
        ]
      }
    );
    const fetchInstrumentFromDataRiver = getByTestId(
      "fetchInstrumentFromDataRiver"
    );
    expect(getByTestId("fetchInstrumentFromDataRiver")).toBeDefined();
    expect(fetchInstrumentFromDataRiver).toBeEnabled();
    fireEvent.click(fetchInstrumentFromDataRiver);
    expect(fetchInstrumentFromDataRiver).toBeDisabled();
    await waitFor(() => {
      expect(onFetched).toHaveBeenCalledTimes(0);
      expect(notify).toHaveBeenCalledTimes(1);
    });
  });

  test("should populate form with data", async () => {
    const submit = jest.fn();
    const materialNumber = "542568153454";
    const serialNumber = "SD9212969";
    const { getByTestId, getByLabelText } = render(
      <TestComponent submit={submit} />,
      {
        mocksForApollo: [
          {
            request: {
              query: GET_INSTRUMENT_FROM_DATA_RIVER,
              variables: {
                materialNumber,
                serialNumber
              }
            },
            result: {
              data: {
                getInstrumentFromDataRiver: data.instruments.instruments[0]
              }
            }
          }
        ]
      }
    );
    const fetchInstrumentFromDataRiver = getByTestId(
      "fetchInstrumentFromDataRiver"
    );
    expect(fetchInstrumentFromDataRiver).toBeDefined();
    fireEvent.change(getByLabelText(/material number/i), {
      target: { value: materialNumber }
    });
    fireEvent.change(getByLabelText(/serial number/i), {
      target: { value: serialNumber }
    });
    fireEvent.click(fetchInstrumentFromDataRiver);
    await waitFor(() => {
      expect(getByLabelText(/instrument type/i)).toHaveValue("Cobas 6400");
    });
  });
  test("should handle null data", async () => {
    const submit = jest.fn();
    const materialNumber = "542568153454";
    const serialNumber = "SD9212969";
    const { getByTestId, getByLabelText } = render(
      <TestComponent submit={submit} />,
      {
        mocksForApollo: [
          {
            request: {
              query: GET_INSTRUMENT_FROM_DATA_RIVER,
              variables: {
                materialNumber,
                serialNumber
              }
            },
            result: {
              data: null
            }
          }
        ]
      }
    );
    const fetchInstrumentFromDataRiver = getByTestId(
      "fetchInstrumentFromDataRiver"
    );
    expect(fetchInstrumentFromDataRiver).toBeDefined();
    fireEvent.change(getByLabelText(/material number/i), {
      target: { value: materialNumber }
    });
    fireEvent.change(getByLabelText(/serial number/i), {
      target: { value: serialNumber }
    });
    fireEvent.click(fetchInstrumentFromDataRiver);
    await waitFor(() => {
      expect(getByLabelText(/instrument type/i)).toHaveValue("");
    });
  });
});
