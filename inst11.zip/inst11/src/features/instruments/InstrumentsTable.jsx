import React, { useState, useEffect } from "react";
import { IconButton, Tooltip } from "@material-ui/core";
import { ImportExampleDownload } from "../importFile/components/ImportButton";
import { ImportFile } from "../importFile/ImportFile";
import InstrumentSettingIcon from "../instruments/InstrumentsSettingIcon";
import { makeStyles } from "@material-ui/core";
import {
  Highlighter,
  NavReactangleBar,
  CustomTypography,
  TestCover,
  CoverMenuItem
} from "../instruments/addEditEquipment/AddEquipmentStyle";
import AddIcon from "@material-ui/icons/Add";
import InstrumentsModal from "./InstrumentsModal";
import InstrumentsSelectColumnModal from "./InstrumentsSelectColumnModal";
import FilterModal from "./FilterModal";
import { withApollo } from "react-apollo";
import { connect } from "react-redux";
import { emptyTableColumn } from "../../constants";
import useDialog from "../../utils/hooks/useDialog";
import ConfirmDialog from "../../components/shared/ConfirmDialog";
import Table from "../../components/shared/Table";
import EditIcon from "@material-ui/icons/EditOutlined";
import DeleteIcon from "@material-ui/icons/DeleteOutlined";
import TopBar from "./TopBar";
import { compose } from "redux";
import { RocheSelectDropdown, RocheMenuItem } from "@one/react-kit";
import { getDynamicFields } from "../../utils/helpers/text";
import {
  getFilterObject,
  getfilterInstrumentList
} from "../../utils/helpers/filtersAndPagination";
import {
  loadInstruments as loadInstrumentsAction,
  updateSearchFilter as updateSearchFilterAction,
  updateNextToken as updateNextTokenAction,
  updatePageTokenArray as updatePageTokenArrayAction,
  updateLoading as updateLoadingAction,
  resetPageTokenArray as resetPageTokenArrayAction
} from "./redux/actions";
import styled from "styled-components";
import { addItem, deleteItem, updateItem } from "../../utils/store/crud";
import {
  CREATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
  DELETE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
  UPDATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY
} from "../../gql/landingapi/mutations";
import omitDeep from "omit-deep-lodash";
import { keyIds } from "./redux/reducer";
import { getInstrumentWithDefaultValues } from "../importFile/utils/actions";
import { checkRoleInstrumentRepo } from "../../utils/helpers/checkRoleInstrumentRepo";
import KeyboardArrowDownIcon from "@material-ui/icons/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@material-ui/icons/KeyboardArrowUp";
import { filterByQuery } from "../../utils/helpers/text/index";

export const DescriptionForm = styled.div`
  & > .button-box-equipment {
    padding: 6px 22px;
    font-size: 16px;
  }
`;

const SettingIconcover = styled.div`
  padding-left: 20px;
`;

const ActionStyled = styled.div`
  display: flex;
  justify-content: flex-end;
`;
const ActionsCell = styled.div`
  display: flex;
  align-items: center;
  justify-content: flex-end;
`;

const IconStyle = styled.div`
  display: flex;
  padding-right: 10px;
`;

const TopBarButtons = styled.div`
  display: flex;
  margin-left: auto;
`;

const InstrumentsTableMeta = {
  rowId: ["materialNumber", "serialNumber"],
  fields: {}
};

const Actions = ({
  item,
  setInstrument,
  setInstrumentToDelete,
  openDialog,
  actionStatus,
  triggerSetCollapse,
  addInstrumentClick,
  expanderColumns
}) => {
  const [open, setOpen] = useState(item.isExpanded);
  const openSetInstrument = (item) => {
    setInstrument(item);
    addInstrumentClick(true, true, item);
  };
  if (expanderColumns.length <= 0) {
    triggerSetCollapse(false);
  }
  return (
    <ActionStyled>
      {expanderColumns.length > 0 ? (
        <Tooltip
          data-testid="instrument-edit-button-tooltip"
          title={!actionStatus ? "More details" : ""}
          placement="left"
          arrow
        >
          <IconButton
            aria-label="expand row"
            onClick={() => {
              setOpen(!open);
              triggerSetCollapse(!open);
            }}
          >
            {open ? (
              <KeyboardArrowUpIcon size="small" />
            ) : (
              <KeyboardArrowDownIcon size="small" />
            )}
          </IconButton>
        </Tooltip>
      ) : (
        ""
      )}
      <Tooltip
        data-testid="instrument-edit-button-tool"
        title={!actionStatus ? "Edit equipment" : ""}
        placement="left"
        arrow
      >
        <IconButton
          data-testid="instrument-table-edit-button"
          onClick={() => openSetInstrument(item)}
          disabled={actionStatus}
        >
          <EditIcon fontSize="small" />
        </IconButton>
      </Tooltip>
      <Tooltip
        data-testid="instrument-delete-button-tooltip"
        title={!actionStatus ? "Delete equipment" : ""}
        placement="left"
        arrow
      >
        <IconButton
          data-testid="instrument-table-delete-button"
          onClick={() => {
            setInstrumentToDelete(item);
            openDialog();
          }}
          disabled={actionStatus}
        >
          <DeleteIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    </ActionStyled>
  );
};

const saveInstrumentAction =
  ({ instrument, client, loadInstruments, instruments, setInstrument }) =>
  async (instru) => {
    if (instrument?.materialNumber && instrument?.serialNumber) {
      await client.mutate({
        mutation: UPDATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
        variables: getInstrumentWithDefaultValues({
          instrument: omitDeep(instru, "__typename")
        }),
        fetchPolicy: "no-cache"
      });
      loadInstruments({
        instruments: updateItem(instruments, instru, keyIds)
      });
    } else {
      await client.mutate({
        mutation: CREATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
        variables: getInstrumentWithDefaultValues({
          instrument: omitDeep(instru, "__typename")
        }),
        fetchPolicy: "no-cache"
      });
      loadInstruments({
        instruments: addItem(instruments, instru, keyIds)
      });
    }
    setInstrument(null);
  };

const deleteInstrumentAction =
  ({ client, loadInstruments, instruments, setInstrumentToDelete }) =>
  async (instru) => {
    await client.mutate({
      mutation: DELETE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
      variables: {
        materialNumber: instru.materialNumber,
        serialNumber: instru.serialNumber
      },
      fetchPolicy: "no-cache"
    });
    loadInstruments({
      instruments: deleteItem(instruments, instru, keyIds)
    });
    setInstrumentToDelete(null);
  };

const InstrumentToDelete = ({ instrumentToDelete }) => (
  <>
    Are you sure you want to delete{" "}
    <strong>{instrumentToDelete?.instrumentName?.value ?? "-"}</strong>
    <br />{" "}
    <em>
      (material number: {instrumentToDelete?.materialNumber}, serial number:{" "}
      {instrumentToDelete?.serialNumber})
    </em>{" "}
    ?
  </>
);
const useStyles = makeStyles((theme) => ({
  focused: true,
  root: {
    "&:hover": {
      color: "#0066cc",
      background: "#D2E9FF",
      borderLeft: "4px solid #0066cc"
    }
  }
}));

const TableTopBar = ({
  setQuery,
  setSelectColumn,
  actionStatus,
  addInstrumentClick,
  setInstrument
}) => {
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const handleChange = (event) => {
    // setActions(event.target.value);
    // console.log(event.target.value);
  };
  const topbaricon = "topbaricon";
  const classes = useStyles();

  return (
    <TopBar setQuery={setQuery} label="Search for equipment">
      <FilterModal
        isFilterModalOpen={isFilterModalOpen}
        setIsFilterModalOpen={setIsFilterModalOpen}
      />
      <TopBarButtons>
        <RocheSelectDropdown
          className={classes.label}
          onChange={handleChange}
          variant="outlined"
          style={{
            width: 164,
            textcolor: "red"
          }}
          label="Action"
          value=""
        >
          <RocheMenuItem
            className={classes.root}
            value={0}
            onClick={() => addInstrumentClick(true, false)}
          >
            <IconStyle>
              <AddIcon />
            </IconStyle>
            Add new equipment
          </RocheMenuItem>
          <CoverMenuItem />

          <RocheMenuItem value={1} className={classes.root}>
            <IconStyle>
              <i className="one-icons">import</i>
            </IconStyle>
            <ImportFile />
          </RocheMenuItem>
          <CoverMenuItem />

          <RocheMenuItem value={2} className={classes.root}>
            <IconStyle>
              <i className="one-icons">download</i>
            </IconStyle>
            <ImportExampleDownload />
          </RocheMenuItem>
        </RocheSelectDropdown>
      </TopBarButtons>
      <SettingIconcover>
        <IconButton>
          <InstrumentSettingIcon
            name={topbaricon}
            setSelectColumn={setSelectColumn}
            setIsFilterModalOpen={setIsFilterModalOpen}
          />
        </IconButton>
      </SettingIconcover>
    </TopBar>
  );
};

const onSort =
  ({ setIsReverseOrder, setOrderBy }) =>
  (key, isReverse) => {
    setIsReverseOrder(isReverse);
    if (
      ["isBookable", "isVisualized", "materialNumber", "serialNumber"].includes(
        key
      )
    ) {
      setOrderBy([key]);
    } else {
      setOrderBy([key, "value"]);
    }
  };

const InstrumentsTable = ({
  instruments,
  lastFilter,
  filters,
  limit,
  user,
  loadInstruments,
  client,
  addInstrumentClicked,
  groupList,
  categoryList,
  siteList,
  manufacturerList,
  responsiblePersonList,
  updateSearchFilter,
  updatePageTokenArray,
  updateNextToken,
  updateLoading,
  filterApplied,
  pageTokenArray,
  resetPageTokenArray
}) => {
  let expanderColumns = [];
  if (lastFilter) {
    if (typeof lastFilter === "string") {
      lastFilter = JSON.parse(lastFilter);
    }
    const showColumns = lastFilter?.showColumns ?? emptyTableColumn;
    const tableColumns = showColumns.filter((item, index) => index < 7);
    expanderColumns = showColumns.filter((item, index) => index >= 7);
    const fields = getDynamicFields(tableColumns);
    InstrumentsTableMeta.fields = fields;
  }

  const [instrument, setInstrument] = useState(null);
  const [instrumentToDelete, setInstrumentToDelete] = useState(null);
  const { openDialog, ...dialogProps } = useDialog();
  const [filteredInstruments, setFilteredInstruments] = useState(instruments);
  const [query, setQuery] = useState("");
  const [orderBy, setOrderBy] = useState(["instrumentName", "value"]);
  const [isReverseOrder, setIsReverseOrder] = useState(false);
  const [actionStatus, setActionStatus] = useState(false);
  const addInstrumentClick = (state, isEditMode, item) => {
    addInstrumentClicked(state, isEditMode, item);
  };

  const [selectColumn, setSelectColumn] = useState(false);
  useEffect(() => {
    resetPageTokenArray([]);
    const checkIsInstrumentRepoViewUser = async () => {
      const checkAccessGroups = await checkRoleInstrumentRepo();
      if (checkAccessGroups) {
        setActionStatus(true);
      }
    };
    checkIsInstrumentRepoViewUser();
    getSearchedInstrumentList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const getSearchedInstrumentList = async (search) => {
    updateLoading(true);
    updateSearchFilter(search);
    const filter = filterApplied ? filters : [];
    const filterObject = getFilterObject({
      filters: filter,
      search,
      groupList,
      categoryList,
      siteList,
      manufacturerList,
      responsiblePersonList
    });

    let instrumentList = [];
    let recursiveNextToken = null;

    do {
      const localLimit = limit - instrumentList.length;
      if (localLimit === 0) {
        break;
      }
      const variables = {
        limit: limit,
        nextToken: recursiveNextToken,
        filter: filterObject
      };
      const { nextToken: latestNextToken, items: result } =
        await getfilterInstrumentList({ client, variables });
      instrumentList.push(...result);
      recursiveNextToken = latestNextToken;
    } while (recursiveNextToken !== null);
    loadInstruments({
      instruments: instrumentList ? instrumentList : []
    });
    updateLoading(false);
    updatePageTokenArray({ pageIndex: 0, token: recursiveNextToken });
    updateNextToken(recursiveNextToken ?? null);
  };
  const filterData = async (q = "") => {
    setFilteredInstruments(
      filterByQuery(instruments, q, undefined, orderBy, isReverseOrder)
    );
    // setFilteredInstruments(instruments);
  };

  useEffect(() => {
    filterData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [instruments, orderBy, isReverseOrder]);

  return (
    <>
      <ConfirmDialog
        {...dialogProps}
        approveText="Delete equipment"
        approveColor="error"
        approveVariant="contained"
        cancelText="Cancel"
        cancelVariant="outlined"
        cancelColor="primary"
        onApprove={() =>
          deleteInstrumentAction({
            loadInstruments,
            instruments,
            client,
            setInstrumentToDelete
          })(instrumentToDelete)
        }
        onCancel={() => setInstrumentToDelete(null)}
        title="Delete equipment"
        content={<InstrumentToDelete instrumentToDelete={instrumentToDelete} />}
      />
      <InstrumentsSelectColumnModal
        open={selectColumn}
        cancel={() => setSelectColumn(false)}
        selectColumn={selectColumn}
        InstrumentsTableMeta={InstrumentsTableMeta}
      ></InstrumentsSelectColumnModal>
      {/**
       * the below InstrumentsModal code can be removed after implementation of the unicity check
       * until then it can remain commented for reference
       */}
      <InstrumentsModal  data-testid="instrument-model"
        instruments={instruments}
        open={instrument !== null}
        title={
          instrument?.materialNumber && instrument?.serialNumber
            ? "Edit equipment"
            : "Add equipment"
        }
        instrument={instrument}
        cancel={() => setInstrument(null)}
        save={saveInstrumentAction({
          instrument,
          client,
          instruments,
          loadInstruments,
          setInstrument
        })}
      ></InstrumentsModal>
      <NavReactangleBar data-testid="rect-bar">
        <TestCover>
          <CustomTypography>Test equipment</CustomTypography>
          <Highlighter />
        </TestCover>
      </NavReactangleBar>
      <TableTopBar
        setQuery={(q) => {
          setQuery(q);
          filterData(q);
          getSearchedInstrumentList(q);
        }}
        query={query}
        actionStatus={actionStatus}
        addInstrumentClick={addInstrumentClick}
        setSelectColumn={setSelectColumn}
        setInstrument={setInstrument}
      ></TableTopBar>

      <Table
        isReverseOrder={isReverseOrder}
        orderBy={orderBy[0]}
        onRequestSort={onSort({
          setIsReverseOrder,
          setOrderBy
        })}
        data={filteredInstruments}
        fieldArray={expanderColumns}
        meta={{
          ...InstrumentsTableMeta,
          fields: {
            ...InstrumentsTableMeta.fields,
            actions: {
              text: "Actions",
              HeadCellComponent: ActionsCell,
              component: ({ item, triggerSetCollapse }) => (
                <Actions
                  item={item}
                  openDialog={openDialog}
                  setInstrument={setInstrument}
                  setInstrumentToDelete={setInstrumentToDelete}
                  actionStatus={actionStatus}
                  triggerSetCollapse={triggerSetCollapse}
                  addInstrumentClick={addInstrumentClick}
                  expanderColumns={expanderColumns}
                />
              )
            }
          }
        }}
      />
    </>
  );
};

const mapStateToProps = (state) => ({
  instruments: state?.instruments?.instruments,
  lastFilter: state?.user?.lastFilter,
  limit: state.instruments?.limit,
  nextToken: state.instruments?.nextToken,
  pageTokenArray: state.instruments?.pageTokenArray,
  filters: state.instruments?.filters,
  filterApplied: state.instruments?.filterApplied,
  groupList: state.instruments?.groupList,
  manufacturerList: state.instruments?.manufacturerList,
  categoryList: state.instruments?.categoryList,
  responsiblePersonList: state.instruments?.responsiblePersonList,
  siteList: state.user?.sites ?? []
});

export default compose(
  connect(mapStateToProps, {
    loadInstruments: loadInstrumentsAction,
    updateSearchFilter: updateSearchFilterAction,
    updateNextToken: updateNextTokenAction,
    updatePageTokenArray: updatePageTokenArrayAction,
    updateLoading: updateLoadingAction,
    resetPageTokenArray: resetPageTokenArrayAction
  }),
  withApollo
)(InstrumentsTable);
