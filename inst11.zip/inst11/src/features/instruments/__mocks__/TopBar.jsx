module.exports = jest.requireActual("../TopBar");
module.exports.setQueryMock = jest.fn();

const TopBar = ({ setQuery, label, children }) => (
  <div data-testid="instruments-top-bar">
    <div data-testid="instruments-top-bar-label">{label}</div>
    <button
      data-testid="instruments-top-bar-set-query"
      onClick={() => setQuery(module.exports.setQueryMock())}
    ></button>
    {children}
  </div>
);
module.exports.default = TopBar;
