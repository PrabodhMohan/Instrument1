module.exports = jest.requireActual("../InstrumentsModal");
module.exports.instrumentsMock = jest.fn();

const InstrumentsModal = ({ save, cancel, open }) => (
  <div data-testid="instruments-modal">
    <div data-testid="instruments-modal-is-open">{open ? "open" : "close"}</div>
    <button
      data-testid="instruments-modal-cancel-button"
      onClick={() => cancel()}
    ></button>
    <button
      data-testid="instruments-modal-save-button"
      onClick={() => save(module.exports.instrumentsMock())}
    ></button>
  </div>
);

module.exports.default = InstrumentsModal;
