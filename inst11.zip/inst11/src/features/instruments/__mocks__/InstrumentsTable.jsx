const InstrumentsTable = () => <div data-testid="instruments-table"></div>;

export default InstrumentsTable;
