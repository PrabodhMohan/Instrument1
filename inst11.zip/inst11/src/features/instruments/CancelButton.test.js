import React from "react";
import { ConfirmDialog } from "../../components/shared";
import useDialog from "../../utils/hooks/useDialog";
import { PreviousButtonStyled } from "./addEditEquipment/AddEquipmentStyle";
import CancelButton from './CancelButton';
import { render, cleanup, fireEvent } from "../../test-utils";

//   CancelButton = ({ cancelStep }) => {
//   const { openDialog, ...dialogProps } = useDialog();
// }

  afterEach(cleanup);
  test("should create with cancel step", () => {
    const { queryByTestId } = render(<CancelButton />);
    expect(queryByTestId("add-instrument-previous-step-button")).toBeDefined();
  });

  test("should create with cancel button", () => {
    const { queryByTestId } = render(<PreviousButtonStyled />);
    expect(queryByTestId("add-instrument-previous-step-button")).toBeDefined();
  });