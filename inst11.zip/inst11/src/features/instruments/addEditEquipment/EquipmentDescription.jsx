import React, { useEffect } from "react";
import { RocheTextField } from "@one/react-kit";
import { DescriptionForm } from "./AddEquipmentStyle";
import { useFormikContext } from "formik";
import {
  commonPropsForInputsWithoutValue,
  commonPropsForInputsWithValue
} from "../helpers";
import { useFormStyles } from "./../instrument-form/FormStyles";
import { connect } from "react-redux";

const EquipmentDescription = ({ instrumentDetail }) => {
  const formik = useFormikContext();
  const classes = useFormStyles();

  useEffect(() => {
    formik.setFieldValue(
      "equipmentCategory",
      instrumentDetail?.equipmentCategory,
      true
    );
    formik.setFieldTouched("instrumentRUDI");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <DescriptionForm>
        <RocheTextField
          data-testid={`text-field-Instrument-name`}
          label="Instrument name"
          className="TextFieldInput"
          name="instrumentName.value"
          value={formik.values?.instrumentName?.value}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          {...commonPropsForInputsWithValue(
            classes,
            formik,
            "instrumentName",
            "instrumentName",
            "text-field"
          )}
        />

        <RocheTextField
          data-testid={`text-field-GTIN`}
          label="GTIN"
          className="TextFieldInput"
          name="instrumentGTIN.value"
          value={formik.values?.instrumentGTIN?.value}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          {...commonPropsForInputsWithValue(
            classes,
            formik,
            "instrumentGTIN",
            "instrumentGTIN",
            "text-field"
          )}
        />

        <RocheTextField
          data-testid={`text-field-Equipment-ID`}
          label="Equipment ID"
          className="TextFieldInput"
          name="equipmentId.value"
          value={formik.values?.equipmentId?.value}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          required
          {...commonPropsForInputsWithValue(
            classes,
            formik,
            "equipmentId",
            "equipmentId",
            "text-field"
          )}
        />

        <RocheTextField
          data-testid={`text-field-RUDI`}
          label="RUDI"
          className="TextFieldInput"
          name="instrumentRUDI"
          value={formik.values?.instrumentRUDI}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          {...commonPropsForInputsWithoutValue(
            classes,
            formik,
            "instrumentRUDI",
            "instrumentRUDI",
            "text-field"
          )}
        />

        <RocheTextField
          data-testid={`text-field-Category`}
          label="Category"
          className="TextFieldInput"
          disabled
          name="equipmentCategory"
          propValue="key"
          propLabel="value"
          value={formik.values?.equipmentCategory?.value}
          onBlur={formik.handleBlur}
        />

        <RocheTextField
          data-testid={`text-field-Technical-position`}
          label="Technical position"
          name="technicalPlace"
          className="TextFieldInput"
          value={formik.values?.technicalPlace}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          {...commonPropsForInputsWithoutValue(
            classes,
            formik,
            "technicalPlace",
            "technicalPlace",
            "text-field"
          )}
        />

        <RocheTextField
          style={{ width: "320px" }}
          formik={formik}
          data-testid={`textarea-field-comment`}
          label="Comment"
          name="remark"
          value={formik.values?.remark}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          {...commonPropsForInputsWithoutValue(
            classes,
            formik,
            "remark",
            "remark",
            "text-field"
          )}
          multiline
          rows={6}
        />
      </DescriptionForm>
    </>
  );
};

const mapStateToProps = (state) => ({
  instrumentDetail: state.instruments?.instrumentDetail
});

export default connect(mapStateToProps)(EquipmentDescription);
