import React from  "react";
import DigitalLabStep from "./DigitalLabStep";
import { render, cleanup, waitFor } from "@testing-library/react";
import { ThemeProvider, theme } from "@material-ui/core/styles";
import { store } from "../../../store";
import { Provider } from "react-redux";
import { emptyDigitalLabInfo } from "./../../../constants";
import { Formik } from "formik";
import { digitalLabStepValidationSchema } from "../instrument-form/digitalLabStepValidationSchema";
import { screen, fireEvent } from "@testing-library/react";



afterEach(cleanup);

describe("DigitalLabStep", () => {
  it("should render successfully - base", async () => {
    const onSubmit = jest.fn();
    const { getByTestId } = render(
      <Provider store={store}>
        <Formik
          initialValues={{
            ...emptyDigitalLabInfo
          }}
          validationSchema={digitalLabStepValidationSchema}
          onSubmit={onSubmit}
          isInitialValid={false}
        >
          <ThemeProvider theme={theme}>
            <DigitalLabStep activeStep={6} />
          </ThemeProvider>
        </Formik>
      </Provider>
    );

    expect(getByTestId("toggle-field-booking")).toBeInTheDocument();
  });
});




describe("DigitalLabStep second", () => {

  const defaultProps = {
    isBookable: true,
    setIsBookable: jest.fn(),
    isVisualized: true,
    setIsVisualized: jest.fn(),
    instrumentDetail: {
      instrumentDescription: {
        key: 2,
        equipmentCategory: {
          value: null
        }
      }
    },
    descriptionList: [
      {
        key: 2, equipmentCategory: {
          isVisualized: true,
          isBookable: true,
        }
      },
      {
        key: 1, equipmentCategory: {
          isVisualized: true,
          isBookable: true,
        }
      }
    ],
    isEditMode: true
  };

 
  it(" Booking text is vissible by default", () => {
    //  if loop and is editmode true
    const onSubmit = jest.fn();

    render(
      <Provider store={store}>
        <Formik
          initialValues={{
            ...emptyDigitalLabInfo
          }}
          validationSchema={digitalLabStepValidationSchema}
          onSubmit={onSubmit}
          isInitialValid={false}
        >
          <ThemeProvider theme={theme}>
            <DigitalLabStep {...defaultProps} activeStep={6} />
          </ThemeProvider>
        </Formik>
      </Provider>
    )
    expect(screen.getByText("Booking ?")).toBeTruthy()
  })

  it("Monitoring  text vissible when isEditMode is false  ", () => {
    //  if loop and is editmode false and line 28 if is not possible
    const onSubmit = jest.fn();

    const props = {
      ...defaultProps,
      isEditMode: false,
    }
    render(
      <Provider store={store}>
        <Formik
          initialValues={{
            ...emptyDigitalLabInfo
          }}
          validationSchema={digitalLabStepValidationSchema}
          onSubmit={onSubmit}
          isInitialValid={false}
        >
          <ThemeProvider theme={theme}>
            <DigitalLabStep {...props} activeStep={6} />
          </ThemeProvider>
        </Formik>
      </Provider>
    )
    expect(screen.getByText("Monitoring ?")).toBeTruthy()
  })

  it("should call setIsVisualized when isBookable is checked", () => {
    const onSubmit = jest.fn();

    // line 41 ==> run and find the class for checkbox
    const props = {
      ...defaultProps,
      isEditMode: false,
    }
    const { getByTestId } = render(
      <Provider store={store}>
        <Formik
          initialValues={{
            ...emptyDigitalLabInfo
          }}
          validationSchema={digitalLabStepValidationSchema}
          onSubmit={onSubmit}
          isInitialValid={false}
        >
          <ThemeProvider theme={theme}>
            <DigitalLabStep {...props} activeStep={6} />
          </ThemeProvider>
        </Formik>
      </Provider>
    )
    fireEvent.change(getByTestId("doc-data-isbookable"))
    expect(defaultProps.setIsVisualized).not.toHaveBeenCalled()

  });


  it("should not call setIsBookable when isVisualized is checked", () => {
    const onSubmit = jest.fn();

    // line 50 ==> run and find the class for checkbox
    const props = {
      ...defaultProps,
      isEditMode: false,
    }
    const { getByTestId } = render(
      <Provider store={store}>
        <Formik
          initialValues={{
            ...emptyDigitalLabInfo
          }}
          validationSchema={digitalLabStepValidationSchema}
          onSubmit={onSubmit}
          isInitialValid={false}
        >
          <ThemeProvider theme={theme}>
            <DigitalLabStep {...defaultProps} activeStep={6} />
          </ThemeProvider>
        </Formik>
      </Provider>
    )
    fireEvent.change(getByTestId("doc-data-isVisualized"))
    expect(defaultProps.setIsBookable).not.toHaveBeenCalled()
  })
})


test("should create", async () => {
  const onSubmit = jest.fn();

  const { getByTestId } = render(
    <Provider store={store}>
      <Formik
        initialValues={{
          ...emptyDigitalLabInfo
        }}
        validationSchema={digitalLabStepValidationSchema}
        onSubmit={onSubmit}
        isInitialValid={false}
      >
        <ThemeProvider theme={theme}>
          <DigitalLabStep activeStep={6} />
        </ThemeProvider>
      </Formik>
    </Provider>
  );

  await waitFor(() =>
    expect(getByTestId("toggle-field-booking")).toBeDefined()
  );
});


