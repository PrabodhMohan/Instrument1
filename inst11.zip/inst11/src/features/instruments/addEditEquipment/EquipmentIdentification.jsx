import React from "react";
import { useSelector } from "react-redux";
import { RocheTextField } from "@one/react-kit";
import styled from "styled-components";
import SelectInput from "./../instrument-form/select-input";
import { useFormikContext } from "formik";
import { commonPropsForInputsWithoutValue } from "../helpers";
import { useFormStyles } from "./../instrument-form/FormStyles";
import { find } from "lodash";
import { removeSpaceInString } from "./../helpers";

const IdentificationForm = styled.div`
  & > .selectBox {
    margin: 0 20px 20px 0px;
    width: 100%;
    max-width: 220px;
  }
  & > .textInputBox {
    margin: 0 20px 20px 0px;
    width: 100%;
    max-width: 220px;
  }
  & > .selectBoxLarge {
    margin: 0 20px 20px 0px;
    width: 100%;
    max-width: 300px;
  }
  & > .displayNone {
    display: none;
  }
`;

export const EquipmentIdentification = ({ isEditMode }) => {
  const formik = useFormikContext();
  const classes = useFormStyles();
  const sites = useSelector((state) => state.user.sites);
  const listOptions = useSelector((state) => state.instruments);
  const setPropertiesBasedOnType = (type) => {
    const selectedEquipmentType = find(listOptions?.typeList, {
      equipmentType: type
    });
    formik.setValues({
      ...formik.values,
      displayImage: selectedEquipmentType?.displayImage ?? "",
      equipmentCategory: {
        key: selectedEquipmentType?.equipmentCategory?.equipmentCategory ?? "",
        value: selectedEquipmentType?.equipmentCategory?.equipmentCategory ?? ""
      },
      isBookable: selectedEquipmentType?.equipmentCategory?.isBookable ?? false,
      isVisualized:
        selectedEquipmentType?.equipmentCategory?.isVisualized ?? false
    });
  };

  return (
    <IdentificationForm>
      <SelectInput
        className="selectBox"
        testidPrefix="action-data"
        options={sites.map((x) => x.siteName)}
        property="siteName"
        Selectlabel="Site"
        testid="siteName"
        required
      />
      <SelectInput
        className="selectBox"
        objectAsValue
        testidPrefix="action-data"
        options={listOptions?.manufacturerList}
        property="manufacturer"
        Selectlabel="Manufacturer"
        testid="manufacturer"
        propValue="key"
        propLabel="value"
        required
      />
      <SelectInput
        className="selectBoxLarge"
        objectAsValue
        testidPrefix="action-data"
        options={listOptions?.descriptionList}
        property="instrumentDescription"
        Selectlabel="Description"
        testid="instrumentDescription"
        propValue="key"
        propLabel="value"
      />
      <RocheTextField
        data-testid="text-field-instrument-type"
        color="primary"
        variant="filled"
        className="textInputBox"
        label="Type"
        name="instrumentType"
        id="instrumentType"
        required
        value={formik.values?.instrumentType}
        onChange={formik.handleChange}
        onBlur={(event) => {
          formik.handleBlur(event);
          setPropertiesBasedOnType(formik.values?.instrumentType);
        }}
        {...commonPropsForInputsWithoutValue(
          classes,
          formik,
          "instrumentType",
          "instrumentType",
          "text-field"
        )}
      />
      <SelectInput
        className="selectBox"
        objectAsValue
        testidPrefix="action-data"
        options={listOptions?.moduleList}
        property="module"
        Selectlabel="Module"
        testid="module"
        propValue="key"
        propLabel="value"
      />
      <RocheTextField
        data-testid="text-field-serial-number"
        color="primary"
        variant="filled"
        className="textInputBox"
        label="Serial number"
        name="serialNumber"
        id="serialNumber"
        disabled={isEditMode}
        required
        value={removeSpaceInString(formik.values?.serialNumber)}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        {...commonPropsForInputsWithoutValue(
          classes,
          formik,
          "serialNumber",
          "serialNumber",
          "text-field",
          isEditMode
        )}
      />
      <RocheTextField
        data-testid="text-field-material-number"
        color="primary"
        variant="filled"
        className="textInputBox"
        label="Material number"
        name="materialNumber"
        id="materialNumber"
        disabled={isEditMode}
        value={removeSpaceInString(formik.values?.materialNumber)}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        {...commonPropsForInputsWithoutValue(
          classes,
          formik,
          "materialNumber",
          "materialNumber",
          "text-field",
          isEditMode
        )}
      />
      <RocheTextField
        type="hidden"
        data-testid="text-field-display-image"
        color="primary"
        variant="filled"
        className="textInputBox displayNone"
        label="Display image"
        name="displayImage"
        id="displayImage"
        value={formik.values?.displayImage}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        {...commonPropsForInputsWithoutValue(
          classes,
          formik,
          "displayImage",
          "displayImage",
          "text-field"
        )}
      />
    </IdentificationForm>
  );
};
