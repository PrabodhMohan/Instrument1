import styled from "styled-components";
import { RocheSwitch, RocheTypography } from "@one/react-kit";
import React, { useEffect } from "react";
import { connect } from "react-redux";
import { useFormikContext } from "formik";

const BookMoniterStyled = styled.div`
  display: flex;
`;

const DigitalLabStep = ({ instrumentDetail }) => {
  const formik = useFormikContext();

  useEffect(() => {
    formik.setFieldValue(
      "isBookable",
      instrumentDetail.isBookable ?? false,
      true
    );
    formik.setFieldValue(
      "isVisualized",
      instrumentDetail.isVisualized ?? false,
      true
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <BookMoniterStyled>
        <RocheTypography
          variant="subtitle1"
          style={{ marginRight: "36px" }}
          data-testid={`doc-data-isbookable`}
        >
          <RocheSwitch
            data-testid={`toggle-field-booking`}
            checked={formik.values?.isBookable}
            onChange={() =>
              formik.setFieldValue(
                "isBookable",
                !formik.values?.isBookable,

                true
              )
            }
            color="primary"
          />
          Booking ?
        </RocheTypography>
        <RocheTypography
          variant="subtitle1"
          id="testtypo"
          data-testid={`doc-data-isVisualized`}
        >
          <RocheSwitch
            checked={formik.values?.isVisualized}
            onChange={() =>
              formik.setFieldValue(
                "isVisualized",
                !formik.values?.isVisualized,

                true
              )
            }
          />
          Monitoring ?
        </RocheTypography>
      </BookMoniterStyled>
    </>
  );
};

const mapStateToProps = (state) => ({
  instrumentDetail: state.instruments?.instrumentDetail
});

export default connect(mapStateToProps)(DigitalLabStep);
