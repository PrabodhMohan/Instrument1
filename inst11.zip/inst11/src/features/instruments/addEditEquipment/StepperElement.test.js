import React from "react";
import StepperElement from "./StepperElement";
import { render, cleanup } from "@testing-library/react";
import { ThemeProvider, theme } from "@material-ui/core/styles";
import { Provider } from "react-redux";
import { store } from "../../../store";
import { ApolloProvider } from "react-apollo";
import { appSyncClient } from "../../../appSyncClient";

afterEach(cleanup);

const activeStep = [0, 1, 2, 3, 4, 5];

describe("EquipmentButtonBoxComponent", () => {
  it("should render successfully - base", async () => {
    const { getByTestId } = render(
      <ApolloProvider client={appSyncClient}>
        <Provider store={store}>
          <ThemeProvider theme={theme}>
            <StepperElement activeStep={activeStep} />
          </ThemeProvider>
        </Provider>
      </ApolloProvider>
    );

    expect(getByTestId("add-equipment-stepper-element")).toBeInTheDocument();
  });
});
