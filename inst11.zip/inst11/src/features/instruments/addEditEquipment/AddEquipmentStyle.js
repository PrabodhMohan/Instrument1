import styled from "styled-components";
import { Typography, withStyles, Button } from "@material-ui/core";
import SettingsOutlinedIcon from "@material-ui/icons/SettingsOutlined";

export const CoverMenuItem = styled.div`
  height: 0.973480224609375px;
  width: 100%;
  border-radius: 0px;
  background: #d3d3d3;
`;
export const DescriptionForm = styled.div`
  & > .TextFieldInput {
    margin: 0 20px 20px 0px;
    max-width: 230px;
  }
`;

export const CustomSettingsOutlinedIcon = withStyles({
  root: {
    color: "#737373",
    height: 30,
    width: 30
  }
})(SettingsOutlinedIcon);
export const StepperElementStyled = styled.div`
  width: 100%;
  background: #ffffff;
  margin-bottom: 10px;
  box-shadow: 0px 1px 0px #d3d3d3;
`;

export const AddContainer = styled.div`
  width: 100%;
  height: 420px;
  background: #ffffff;
  border: 1px solid #d3d3d3;
`;

export const Highlighter = styled.div`
  width: 147px;
  height: 2px;
  background: #0066cc;
  margin-top: 10px;
`;

export const NavReactangleBar = styled.div`
  width: 100%;
  height: 48px;
  background: #ffffff;
  margin-bottom: 10px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.34902);
`;

export const TestCover = styled.div`
  float: left;
  margin-right: 20px;
`;
export const LabCover = styled.div``;
export const AddContainerHeader = styled.div`
  width: 100%;
  height: 60px;
  padding: 21px 16px;
  border-bottom: 1px solid #d3d3d3;
  font-family: "Roboto", sans-serif;
  font-weight: 400;
  font-size: 16px;
  line-height: 19px;
  color: #333333;
`;

export const AddContainerBody = styled.div`
  width: 100%;
  height: 300px;
  padding: 20px 16px;
`;
export const FinishButton = styled.div`
  padding-left: 20px;
  float: right;
`;

export const AddContainerFooter = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
  padding: 0px 16px;
`;

export const PreviousButtonStyled = styled(Button)`
  && {
    text-transform: none;
    background-color: #ffffff;
    color: #0066cc;
    font-weight: 500;
    border: 1px solid #d3d3d3;
    margin-right: 24px;
  }
`;

export const CustomTypography = withStyles({
  root: {
    paddingTop: 13,
    paddingLeft: 16,
    letterSpacing: "0.02em",
    color: "#0066CC"
  }
})(Typography);

export const AddEquipmentDescription = styled.div`
  display: flex;
  flex-wrap: wrap;
  float: left;
  padding-right: 20px;
  padding-bottom: 20px;
  padding-top: 10px;
`;
