// import React from "react";
// import { render, cleanup, waitFor, fireEvent } from "@testing-library/react";

// import { useSelector } from "react-redux";
// import styled from "styled-components";
// import SelectInput from "./../instrument-form/select-input";
// import { useFormikContext } from "formik";
// import { commonPropsForInputsWithoutValue } from "../helpers";
// import { useFormStyles } from "./../instrument-form/FormStyles";
// import { find } from "lodash";
// import { removeSpaceInString } from "./../helpers";

// import { ThemeProvider, theme } from "@material-ui/core/styles";
// //import { Provider } from "react-redux";

// import { store } from "../../../store";
// import { ApolloProvider } from "react-apollo";
// import { Provider } from "react-redux";
// //import EquipmentIdentification from './EquipmentIdentification';
// import { RocheTextField } from "@one/react-kit";

// // import SelectInput from "./../instrument-form/select-input";
// //import { commonPropsForInputsWithoutValue } from "../helpers";
// //import { useFormStyles } from "./../instrument-form/FormStyles";
// //import { removeSpaceInString } from "./../helpers";
 

// export const EquipmentIdentification = ({ isEditMode }) => {
//     const formik = useFormikContext();
//     const classes = useFormStyles();
//     const sites = useSelector((state) => state.user.sites);
//     const listOptions = useSelector((state) => state.instruments);
//     const setPropertiesBasedOnType = (type) => {
//       const selectedEquipmentType = find(listOptions?.typeList, {
//         equipmentType: type
//       });
//       formik.setValues({
//         ...formik.values,
//         displayImage: selectedEquipmentType?.displayImage ?? "",
//         equipmentCategory: {
//           key: selectedEquipmentType?.equipmentCategory?.equipmentCategory ?? "",
//           value: selectedEquipmentType?.equipmentCategory?.equipmentCategory ?? ""
//         },
//         isBookable: selectedEquipmentType?.equipmentCategory?.isBookable ?? false,
//         isVisualized:
//           selectedEquipmentType?.equipmentCategory?.isVisualized ?? false
//       });
//     };
// };
// const IdentificationForm = styled.div`
//   & > .selectBox {
//     margin: 0 20px 20px 0px;
//     width: 100%;
//     max-width: 220px;
//   }
//   & > .textInputBox {
//     margin: 0 20px 20px 0px;
//     width: 100%;
//     max-width: 220px;
//   }
//   & > .selectBoxLarge {
//     margin: 0 20px 20px 0px;
//     width: 100%;
//     max-width: 300px;
//   }
//   & > .displayNone {
//     display: none;
//   }
// `;
 
// test("should create with table instrument", () => {
//     const { getByTestId } = render(
//        <EquipmentIdentification/>
//    );
//    expect(getByTestId("modal-for-instrument-identification")).toBeDefined();
//    expect(getByTestId("text-field-instrument-type")).toBeDefined();
// });
 

// test("should create with roche instrument", () => {
//     const { getByTestId } = render(
//         <EquipmentIdentification>
//               <RocheTextField className="selectBox"/>
//        </EquipmentIdentification>
//    );
//    expect(getByTestId("text-field-instrument-type")).toBeDefined();
//    expect(getByTestId("text-field-serial-numbe")).toBeDefined();

//    expect(getByTestId("text-field-material-number")).toBeDefined();
//    expect(getByTestId("text-field-display-image")).toBeDefined();
// });
 

 
// test("should create with identification instrument", () => {
//     const { getByTestId } = render(
//        <EquipmentIdentification/>
//    );
//    expect(getByTestId("modal-for-instrument-identification")).toBeDefined();
// });
 
import React from "react";
import { CustomSelect } from "../../../components/shared/CustomSelect";
import { useSelector } from "react-redux";
import { RocheTextField } from "@one/react-kit";
import styled from "styled-components";
import { getSteps } from "./../../../constants";
import { render, cleanup, fireEvent, waitFor } from "../../../test-utils";
import { Formik, useFormik, useFormikContext } from "formik";
import * as yup from "yup";
import {EquipmentIdentification} from "./EquipmentIdentification";
import {emptyInstrumentIdentification} from "../InstrumentsMainPage";

//import {identificationValidationSchema} from "../instruments/instrument-form/identificationValidationSchema";
import { identificationValidationSchema } from "../instrument-form/identificationValidationSchema";
import { Provider } from "react-redux";
import { store } from "../../../store";

afterEach(cleanup);

const testValidationSchema = identificationValidationSchema;

const TestComponent = ({ submit }) => {
  return (
    <Formik
      validationSchema={testValidationSchema}
      initialValues={{ ...emptyInstrumentIdentification }}
      onSubmit={(values) => { }}
      isInitialValid={false}
    >
      <form data-testid="test-form" onSubmit={(values) => {
        if (submit)
          submit(values)
      }}>
        <EquipmentIdentification
          instrument={false} />
      </form>
    </Formik>
  );
};

test("should create", async () => {
  const { getByTestId } = render(
    <TestComponent />
  );

    waitFor(() =>
    expect(getByTestId("equipment-level1")).toBeDefined()
  );
});


test("should update form with incorrect values", async () => {
  const submit = jest.fn();
  const { getByTestId, getByLabelText } = render(
    <TestComponent submit={submit} />
  );

 // testid={`${testidPrefix}-inputs-${testid}-input`}

  fireEvent.click(
    getByTestId(
      "action-data-inputs-siteName-input"
    )
  );

  fireEvent.click(
    getByTestId(
      "action-data-inputs-manufacturer-input"
    )
  );
//   fireEvent.click(
//     getByTestId(
//       "action-data-inputs-description-input"
//     )
//   );

//   fireEvent.click(
//     getByTestId(
//       "action-data-inputs-instrumentType-input"
//     )
//   );
//   fireEvent.click(
//     getByTestId(
//       "action-data-inputs-instrumentModule-input"
//     )
//   );

  fireEvent.click(
    getByTestId(
      "text-field-material-number"
    )
  );
  fireEvent.click(
    getByTestId(
      "text-field-serial-number"
    )
  );
  fireEvent.submit(getByTestId("test-form"));
});


describe("DigitalLabblurr", () => {

    const defaultProps = {
        isBookable: true,
        setIsBookable: jest.fn(),
        isVisualized: true,
        setIsVisualized: jest.fn(),
        instrumentDetail: {
          instrumentDescription: {
            key: 2,
            equipmentCategory: {
              value: null
            }
          }
        },
        descriptionList: [
          {
            key: 2, equipmentCategory: {
              isVisualized: true,
              isBookable: true,
            }
          },
          {
            key: 1, equipmentCategory: {
              isVisualized: true,
              isBookable: true,
            }
          }
        ],
        isEditMode: true
      };

    it("should blurr successfully - base", async () => {
    const onChange = jest.fn();
    const onBlur = jest.fn();
    
    const props = {
      ...defaultProps,
      isEditMode: false,
    }
    const { getByTestId } = render(
            <Provider store={store}>
            <Formik
            validationSchema={testValidationSchema}
            onChange={onChange}
             onBlur={(event) => {
                formik.handleBlur(event);
                setPropertiesBasedOnType(formik.values?.instrumentType);
              }}
            isInitialValid={false}
          >
            <TestComponent activeStep={6} />
           </Formik>
        </Provider>
       );
      expect(getByTestId("text-field-serial-number")).toBeInTheDocument();
    });
});
   
