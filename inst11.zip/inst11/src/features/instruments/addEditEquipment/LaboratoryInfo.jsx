import { RocheTextField } from "@one/react-kit";
import styled from "styled-components";
import SelectInput from "./../instrument-form/select-input";
import { connect } from "react-redux";
import { updateInstrumentDetail as updateInstrumentDetailAction } from "../redux/actions";
import { useFormikContext } from "formik";
import {
  commonPropsForInputsWithoutValue,
  commonPropsForInputsWithValue
} from "../helpers";
import { useFormStyles } from "./../instrument-form/FormStyles";
import { useEffect } from "react";

const AddContainerBody = styled.div`
  & > .selectBox {
    margin: 0 20px 20px 0px;
    width: 100%;
    max-width: 220px;
  }
  & > .selectBoxLarge {
    margin: 0 20px 20px 0px;
    width: 100%;
    max-width: 300px;
  }
  & > .TextFieldInput {
    margin: 0 20px 20px 0px;
    max-width: 220px;
    width: 100%;
  }
`;

const LaboratoryInfo = ({
  buildingList,
  instrumentDetail,
  updateInstrumentDetail
}) => {
  const formik = useFormikContext();
  const classes = useFormStyles();
  useEffect(() => {
    formik.setFieldTouched("systemOwner");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <AddContainerBody>

        <RocheTextField
          data-testid={`select-field-belongingToGroup`}
          label="Group"
          className="TextFieldInput"
          name="belongingToGroup"
          value={formik.values?.belongingToGroup}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          required
          {...commonPropsForInputsWithoutValue(
            classes,
            formik,
            "belongingToGroup",
            "belongingToGroup",
            "text-field"
          )}
        />
        <SelectInput
          className="selectBox"
          objectAsValue
          testidPrefix="action-data"
          options={buildingList}
          property="buildingLocation"
          Selectlabel="Building"
          testid="buildingLocation"
          propValue="key"
          propLabel="value"
          required
          data-testid={`select-field-buildingLocation`}
        />

        <RocheTextField
          data-testid={`text-field-floor-and-room`}
          label="Room"
          className="TextFieldInput"
          name="floorAndRoomLocation.value"
          value={formik.values?.floorAndRoomLocation?.value}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          required
          {...commonPropsForInputsWithValue(
            classes,
            formik,
            "floorAndRoomLocation",
            "floorAndRoomLocation",
            "text-field"
          )}
        />

        <RocheTextField
          data-testid={`text-field-responsible-person`}
          label="Responsible person"
          className="TextFieldInput"
          name="responsiblePerson.value"
          value={formik.values?.responsiblePerson?.value}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          required
          {...commonPropsForInputsWithValue(
            classes,
            formik,
            "responsiblePerson",
            "responsiblePerson",
            "text-field"
          )}
        />

        <RocheTextField
          data-testid={`text-field-system-owner`}
          label="System owner"
          className="TextFieldInput"
          name="systemOwner"
          value={formik.values?.systemOwner}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          {...commonPropsForInputsWithoutValue(
            classes,
            formik,
            "systemOwner",
            "systemOwner",
            "text-field"
          )}
        />

        <RocheTextField
          data-testid={`text-field-second-responsible-person`}
          label="Responsible person 2"
          className="TextFieldInput"
          name="secondResponsiblePerson.value" 
          value={formik.values?.secondResponsiblePerson?.value}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          {...commonPropsForInputsWithValue(
            classes,
            formik,
            "secondResponsiblePerson",
            "secondResponsiblePerson",
            "text-field"
          )}
        />
      </AddContainerBody>
    </>
  );
};

const mapStateToProps = (state) => ({
  buildingList: state.instruments?.buildingList,
  instrumentDetail: state.instruments?.instrumentDetail
});

export default connect(mapStateToProps, {
  updateInstrumentDetail: updateInstrumentDetailAction
})(LaboratoryInfo);
