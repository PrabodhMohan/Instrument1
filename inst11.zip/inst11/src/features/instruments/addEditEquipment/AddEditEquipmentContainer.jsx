import React, { useEffect, useState } from "react";
import { Button } from "@material-ui/core";
import { getSteps } from "./../../../constants";
import StepperElement from "./StepperElement";
import GpxMaintainanceInformation from "./GpxMaintainanceInformation";
import EquipmentDescription from "./EquipmentDescription";
import LaboratoryInfo from "./LaboratoryInfo";
import AnalyzerConfiguration from "./AnalyzerConfiguration";
import { EquipmentIdentification } from "./EquipmentIdentification";
import { useFormikContext } from "formik";
import DigitalLabStep from "./DigitalLabStep";
import { ConfirmDialog } from "../../../components/shared";
import useDialog from "../../../utils/hooks/useDialog";
import { compose, withApollo } from "react-apollo";
import { connect } from "react-redux";
import {
  updateInstrumentDetail as updateInstrumentDetailAction,
  loadInstruments as loadInstrumentsAction
} from "../redux/actions";
import omitDeep from "omit-deep-lodash";
import {
  AddContainer,
  Highlighter,
  NavReactangleBar,
  AddContainerHeader,
  AddContainerBody,
  AddContainerFooter,
  PreviousButtonStyled,
  CustomTypography
} from "./AddEquipmentStyle";
import {
  GET_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
  LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS
} from "./../../../gql/landingapi/queries";
import { emptyInstrument } from "../../importFile/utils/emptyInstrument";
import {
  CREATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
  UPDATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY
} from "./../../../gql/landingapi/mutations";
import Notify from "../../notifications/Notify";
import CancelButton from "./../CancelButton";
import { removeSpaceInString } from "./../helpers";

export const emptyEquipmentDescription = {
  instrumentName: null,
  instrumentGTIN: null,
  equipmentId: null,
  instrumentRUDI: null,
  equipmentCategory: null,
  technicalPlace: null,
  remark: null
};

const AddInstrumentContainer = ({
  isEditMode,
  setIsEditMode,
  cancelStep,
  client,
  activeStep,
  setActiveStep,
  updateInstrumentDetail,
  loadInstruments,
  instrumentDetail,
  selectedItem,
  setSelectedItem
}) => {
  const { dirty, errors, isValid, values, setValues, setErrors } =
    useFormikContext();

  const steps = getSteps();

  const { openDialog, ...dialogProps } = useDialog();
  const [tempSelecetedInstrument, setTempSelecetedInstrument] = useState(null);
  const [materialNumber, setMaterialNumber] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  /**
   * This effect is used to trigger the setEquipmentValueOnEdit method
   * this triggers only if the instrument is passed upon edit mode
   */
  useEffect(() => {
    const fetchData = async () => {
      if (selectedItem?.serialNumber && selectedItem?.materialNumber) {
        const result = await checkUnicityForEquipment(
          selectedItem?.serialNumber,
          selectedItem?.materialNumber
        );
        if (result) {
          handleFieldValuesForEdit(
            result?.data?.getDigitalLabInstrumentRepositoryEntry
          );
        }
      }
    };
    if (isEditMode) {
      fetchData();
    } else {
      setActiveStep(0);
      updateInstrumentDetail({ ...emptyInstrument, sourceSystem: "MANUAL" });
      setEquipmentValueOnEdit({ ...emptyInstrument, sourceSystem: "MANUAL" });
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * This method is used to get the selected instrument and populated the form fields
   * @param {instrument} instrument the current instrument that is selected
   * the values of the instrument will be updated as per the fields
   */
  const setEquipmentValueOnEdit = (instrumentObj) => {
    for (const key in instrumentObj) {
      values[key] = instrumentObj[key];
    }
    setValues({ ...values });
  };

  const setValuesinRedux = () => {
    for (const key in values) {
      instrumentDetail[key] = values[key];
    }
    updateInstrumentDetail(instrumentDetail);
  };

  const setGxpTempValues = (instrumentDetail) => {
    const arr = [
      "csv",
      "electronicRecord",
      "electronicSignatures",
      "gxpRelevant",
      "instrumentGxPStatus"
    ];

    for (const key in instrumentDetail) {
      if (arr.includes(key)) {
        instrumentDetail[key] = instrumentDetail[key]?.key;
      }
    }

    return instrumentDetail;
  };

  const getNewMaterialNumber = (values) => {
    const materialNo =
      `${values?.manufacturer?.value}${values?.instrumentType}${values?.serialNumber}`.replace(
        / /g,
        ""
      );
    setMaterialNumber(materialNo);
    return materialNo;
  };

  const isAnalyser = (values) => {
    if (values?.equipmentCategory?.value !== "Analyzer") {
      values.softwareVersion = "";
      values.qualificationDocuments = {
        isSynchronized: false,
        value: []
      };
      values.installedTests = [];
      values.configurationBaseline = "";
    }
  };

  /**
   * This method is used to handle the previous button click on the add wizard
   * it updates the activeSetp value by decreasing one through setactiveStep props
   */
  const handlePreviousButton = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
    if (
      instrumentDetail?.equipmentCategory?.value === "Analyzer" &&
      activeStep === 5
    ) {
      setActiveStep((prevActiveStep) => activeStep - 1);
    } else if (
      instrumentDetail?.equipmentCategory?.value !== "Analyzer" &&
      activeStep === 5
    ) {
      setActiveStep((prevActiveStep) => activeStep - 2);
    }
    setErrors({});
  };

  /**
   * This method is used to handle the next button click on the add wizard
   * it submits the form and if valid moves to the next step, unicity check is also handled
   */
  const handleNextButton = async () => {
    setTempSelecetedInstrument(null);

    switch (activeStep) {
      case 0:
        if (isValid) {
          if (isEditMode) {
            if (
              instrumentDetail?.serialNumber !== values.serialNumber ||
              instrumentDetail?.materialNumber !== values.materialNumber
            ) {
              let newMaterialNumber = "";
              if (!values?.materialNumber) {
                newMaterialNumber = getNewMaterialNumber(values);
              }
              const checkedInstrument = await checkUnicityForEquipment(
                values?.serialNumber,
                newMaterialNumber !== ""
                  ? newMaterialNumber
                  : values.materialNumber
              );
              if (
                !checkedInstrument?.data?.getDigitalLabInstrumentRepositoryEntry
              ) {
                const tempIdentificationFields = {
                  siteName: values.siteName,
                  manufacturer: values.manufacturer,
                  instrumentDescription: values.instrumentDescription,
                  instrumentType: values.instrumentType,
                  module: values.module,
                  serialNumber: values.serialNumber,
                  materialNumber:
                    values.materialNumber === "" || !values.materialNumber
                      ? newMaterialNumber
                      : values.materialNumber,
                  displayImage: values.displayImage
                };
                const identifyFormOnEdit = {
                  ...emptyInstrument,
                  ...tempIdentificationFields
                };
                updateInstrumentDetail(identifyFormOnEdit);
                setEquipmentValueOnEdit(identifyFormOnEdit);
                setActiveStep((prevActiveStep) => prevActiveStep + 1);
                setIsEditMode(false);
              } else {
                setTempSelecetedInstrument(
                  omitDeep(
                    checkedInstrument?.data
                      ?.getDigitalLabInstrumentRepositoryEntry,
                    "__typename"
                  )
                );
                setIsEditMode(true);
                openDialog();
              }
            } else {
              setIsEditMode(true);
              setValuesinRedux();
              setActiveStep((prevActiveStep) => prevActiveStep + 1);
            }
          } else {
            instrumentDetail.serialNumber = values?.serialNumber;
            let newMaterialNumber = "";
            if (!values?.materialNumber) {
              newMaterialNumber = getNewMaterialNumber(values);
            } else {
              instrumentDetail.materialNumber = values.materialNumber;
              setValues({
                ...values,
                materialNumber: instrumentDetail.materialNumber
              });
              setMaterialNumber(instrumentDetail.materialNumber);
            }
            const checkedInstrument = await checkUnicityForEquipment(
              instrumentDetail?.serialNumber,
              newMaterialNumber !== ""
                ? newMaterialNumber
                : instrumentDetail.materialNumber
            );
            if (
              !checkedInstrument?.data?.getDigitalLabInstrumentRepositoryEntry
            ) {
              setValuesinRedux();
              setActiveStep((prevActiveStep) => prevActiveStep + 1);
            } else {
              openDialog();
            }
          }
        }

        break;
      case 1:
        setValuesinRedux();
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
        break;
      case 2:
        setValuesinRedux();
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
        break;
      case 3:
        if (instrumentDetail?.equipmentCategory?.value === "Analyzer") {
          setActiveStep((prevActiveStep) => prevActiveStep + 1);
        } else {
          isAnalyser(values);
          setActiveStep((prevActiveStep) => prevActiveStep + 2);
        }
        setValuesinRedux();
        break;
      case 4:
        setValuesinRedux();
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
        break;
      case 5:
        setValuesinRedux();
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
        break;

      default:
        break;
    }
  };

  /**
   * This method is used to handle the save changes button in the add equipment wizard
   * TODO: update mutation has to be called in here for each form
   */
  const handleSaveChangesButton = () => {
    setValuesinRedux();
    saveOrUpdateInstrumentAction();
  };

  /**
   * This method is used to handle the final add instrument in the add equipment wizard
   * TODO: all form fields has to be merged and add mutation has to be called
   */
  const handleFinishButton = () => {
    setValuesinRedux();
    saveOrUpdateInstrumentAction();
  };

  /**
   * This method is used to get the form component based on the activeStep
   * @param {step} step the current step number for the corresponding form
   * @returns the form component based on the current step in the wizard
   */
  const getStepContent = (step) => {
    switch (step) {
      case 0:
        return <EquipmentIdentification isEditMode={isEditMode} />;
      case 1:
        return <EquipmentDescription />;
      case 2:
        return <LaboratoryInfo />;
      case 3:
        return <GpxMaintainanceInformation />;
      case 4:
        return <AnalyzerConfiguration />;
      case 5:
        return <DigitalLabStep isEditMode={isEditMode} />;
      default:
        return "Unknown Step";
    }
  };

  /**
   * This method is used to check the unicity of the instrument that is being added
   * @param {*} serialNumber the serial number of the instrument
   * @param {*} materialNumber the material number of the instrument
   * @returns the instrument object if the instrument already exists
   * or retuns null if instrument is not present
   * It calls an gql query to check the unicity
   */
  const checkUnicityForEquipment = async (serialNumber, materialNumber) => {
    try {
      setIsLoading(true);
      const result = await client.query({
        query: GET_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
        fetchPolicy: "no-cache",
        variables: {
          materialNumber: materialNumber,
          serialNumber: serialNumber
        }
      });
      return result;
    } catch (err) {
      console.log("unicity check error", err);
    } finally {
      console.log("executed finally");
      setIsLoading(false);
    }
  };

  const getEquipmentListAndUpdateRedux = async () => {
    try {
      const result = await client.query({
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        fetchPolicy: "no-cache",
        variables: {
          limit: 1000
        }
      });
      return omitDeep(
        result?.data?.listDigitalLabInstrumentRepositoryEntrys?.items,
        "__typename"
      );
    } catch (err) {
      console.log("unicity check error", err);
    } finally {
      console.log("executed finally");
    }
  };

  const handleFieldValuesForEdit = (instrument) => {
    setSelectedItem(instrument);
    let tempInstrumentDetail = omitDeep(instrument, "__typename");

    if (tempInstrumentDetail.csv) {
      tempInstrumentDetail.csv = {
        key: tempInstrumentDetail?.csv,
        value: tempInstrumentDetail?.csv
      };
    }

    if (tempInstrumentDetail.electronicRecord) {
      tempInstrumentDetail.electronicRecord = {
        key: tempInstrumentDetail?.electronicRecord,
        value: tempInstrumentDetail?.electronicRecord
      };
    }

    if (tempInstrumentDetail.electronicSignatures) {
      tempInstrumentDetail.electronicSignatures = {
        key: tempInstrumentDetail?.electronicSignatures,
        value: tempInstrumentDetail?.electronicSignatures
      };
    }

    if (tempInstrumentDetail.gxpRelevant) {
      tempInstrumentDetail.gxpRelevant = {
        key: tempInstrumentDetail?.gxpRelevant,
        value: tempInstrumentDetail?.gxpRelevant
      };
    }

    tempInstrumentDetail.instrumentGxPStatus = {
      key: tempInstrumentDetail?.instrumentGxPStatus,
      value: tempInstrumentDetail?.instrumentGxPStatus
    };

    updateInstrumentDetail(tempInstrumentDetail);
    setEquipmentValueOnEdit(tempInstrumentDetail);
  };

  const saveOrUpdateInstrumentAction = async () => {
    setIsLoading(true);
    const updatedInstrumentData = setGxpTempValues(instrumentDetail);
    updatedInstrumentData.testEquipment = "Yes";
    if (
      !updatedInstrumentData.materialNumber ||
      updatedInstrumentData.materialNumber === ""
    ) {
      updatedInstrumentData.materialNumber = removeSpaceInString(
        materialNumber || getNewMaterialNumber(values)
      );
    }
    if (
      !updatedInstrumentData.instrumentName ||
      updatedInstrumentData.instrumentName?.value === ""
    ) {
      updatedInstrumentData.instrumentName = {};
      const instrumentNameObject = {
        isSynchronized: false,
        value: removeSpaceInString(
          `${updatedInstrumentData?.serialNumber}${updatedInstrumentData?.instrumentType}`
        )
      };
      updatedInstrumentData.instrumentName = instrumentNameObject;
    }
    updatedInstrumentData.materialNumber = removeSpaceInString(
      updatedInstrumentData.materialNumber
    ).trim();
    updatedInstrumentData.serialNumber = removeSpaceInString(
      updatedInstrumentData.serialNumber
    ).trim();

    const inputData = omitDeep(updatedInstrumentData, "__typename");

    try {
      const result = await client.mutate({
        mutation: isEditMode
          ? UPDATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY
          : CREATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
        variables: {
          instrument: inputData
        },
        fetchPolicy: "no-cache"
      });
      if (result) {
        if (result?.errors) {
          Notify({
            type: "warning",
            icon: "caution",
            appName: "",
            text: isEditMode
              ? `Equipment updated failed!`
              : `Equipment created failed! `
          });
        }

        if (isEditMode) {
          handleFieldValuesForEdit(
            result?.data?.updateDigitalLabInstrumentRepositoryEntry
          );
        }

        const instruments = await getEquipmentListAndUpdateRedux();
        loadInstruments({ instruments });

        Notify({
          type: "success",
          icon: "yes",
          appName: "",
          text: isEditMode
            ? `Equipment updated successfully! `
            : `Equipment created successfully! `
        });
        cancelStep();
      } else {
        Notify({
          type: "warning",
          icon: "caution",
          appName: "",
          text: isEditMode
            ? `Equipment updated failed!`
            : `Equipment created failed! `
        });
      }
    } catch (error) {
      console.log(error);
      Notify({
        type: "warning",
        icon: "caution",
        appName: "",
        text: isEditMode
          ? `Equipment updated failed!`
          : `Equipment created failed! `
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {isEditMode ? (
        <ConfirmDialog
          {...dialogProps}
          approveText="Edit"
          approveColor="primary"
          approveVariant="contained"
          cancelText="Cancel"
          cancelVariant="outlined"
          cancelColor="primary"
          onApprove={() => {
            handleFieldValuesForEdit(tempSelecetedInstrument);
          }}
          title="Add equipment"
          content="This equipment already exists. Do you want to edit it ?"
        />
      ) : (
        <ConfirmDialog
          {...dialogProps}
          cancelText="Cancel"
          cancelVariant="outlined"
          cancelColor="primary"
          title="Add equipment"
          content="This equipment already exists."
        />
      )}

      <NavReactangleBar>
        <CustomTypography>Test equipment</CustomTypography>
        <Highlighter />
      </NavReactangleBar>
      <StepperElement
        activeStep={activeStep}
        setActiveStep={setActiveStep}
        isEditMode={isEditMode}
        errors={errors}
      />
      <AddContainer>
        <AddContainerHeader>
          {steps?.map((item, index) => {
            if (activeStep !== index) {
              return null;
            }
            return (
              <span value={item} key={index}>
                {item}
              </span>
            );
          })}
        </AddContainerHeader>
        <AddContainerBody>{getStepContent(activeStep)}</AddContainerBody>
        <AddContainerFooter>
          <div>
            {activeStep !== 0 && (
              <PreviousButtonStyled
                variant="contained"
                onClick={() => handlePreviousButton()}
                data-testid="add-instrument-previous-step-button"
              >
                Previous Step
              </PreviousButtonStyled>
            )}
            {activeStep + 1 !== steps?.length && (
              <Button
                color="primary"
                variant="contained"
                style={{ textTransform: "none" }}
                disabled={
                  Object.keys(errors).length > 0 || !isValid || isLoading
                }
                type="submit"
                onClick={() => handleNextButton()}
                data-testid="add-instrument-next-step-button"
              >
                Next Step
              </Button>
            )}
          </div>
          <div>
            <CancelButton cancelStep={cancelStep} />
            {isEditMode && (
              <Button
                color="primary"
                variant="contained"
                style={{ textTransform: "none" }}
                disabled={!dirty || Object.keys(errors).length > 0 || isLoading}
                onClick={() => handleSaveChangesButton()}
                data-testid="add-instrument-next-step-button"
              >
                Save Changes
              </Button>
            )}
            {!isEditMode && activeStep + 1 === steps?.length && (
              <Button
                color="primary"
                variant="contained"
                style={{ textTransform: "none" }}
                disabled={isLoading}
                onClick={() => handleFinishButton()}
                data-testid="add-instrument-next-step-button"
              >
                Finish
              </Button>
            )}
          </div>
        </AddContainerFooter>
      </AddContainer>
    </>
  );
};
const mapStateToProps = (state) => ({
  instrumentDetail: state.instruments?.instrumentDetail
});
export default compose(
  connect(mapStateToProps, {
    updateInstrumentDetail: updateInstrumentDetailAction,
    loadInstruments: loadInstrumentsAction
  }),
  withApollo
)(AddInstrumentContainer);
