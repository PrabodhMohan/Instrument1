import React from "react";
import GpxMaintainanceInformation from "./GpxMaintainanceInformation";
import { render, cleanup, waitFor, fireEvent } from "@testing-library/react";
import { ThemeProvider, theme } from "@material-ui/core/styles";
import { store } from "../../../store";
import { Provider } from "react-redux";
import { GXPemptyInstruments } from "./../../../constants";
import { Formik } from "formik";
import { gxpValidationSchema } from "../instrument-form/gxpValidationSchema";
afterEach(cleanup);

describe("Laboratory Information", () => {
  it("should render successfully laboratory info form", async () => {
    const onSubmit = jest.fn();
    const { getByTestId, getByLabelText } = render(
      <Provider store={store}>
        <Formik
          initialValues={{
            ...GXPemptyInstruments
          }}
          validationSchema={gxpValidationSchema}
          onSubmit={onSubmit}
          isInitialValid={false}
        >
          <ThemeProvider theme={theme}>
            <GpxMaintainanceInformation activeStep={3} />
          </ThemeProvider>
        </Formik>
      </Provider>
    );

    fireEvent.change(getByLabelText(/Periodic review for CSV systems/i), {
      target: { value: "01-012-2021" }
    });

    await waitFor(() => {
      expect(getByTestId("action-data-inputs-sop-input")).toBeInTheDocument();

      expect(getByLabelText(/Periodic review for CSV systems/i)).toHaveValue(
        "01-012-2021"
      );
    });
  });
});
