import React from "react";
import LaboratoryInfo from "./LaboratoryInfo";
import { render, cleanup, waitFor } from "@testing-library/react";
import { ThemeProvider, theme } from "@material-ui/core/styles";
import { store } from "../../../store";
import { Provider } from "react-redux";
import { emptyEquipmentDescription } from "./../../../constants";
import { Formik } from "formik";
import { laboratoryValidationSchema } from "../instrument-form/laboratoryValidationSchema";

afterEach(cleanup);

describe("Laboratory Information", () => {
  it("should render successfully laboratory info form", async () => {
    const onSubmit = jest.fn();
    const { getByTestId } = render(
      <Provider store={store}>
        <Formik
          initialValues={{
            ...emptyEquipmentDescription
          }}
          validationSchema={laboratoryValidationSchema}
          onSubmit={onSubmit}
          isInitialValid={false}
        >
          <ThemeProvider theme={theme}>
            <LaboratoryInfo activeStep={2} groupList={[]} buildingList={[]}/>
          </ThemeProvider>
        </Formik>
      </Provider>
    );

    await waitFor(() =>
      expect(getByTestId("text-field-floor-and-room")).toBeInTheDocument()
    );
  });
});
