import { RocheTextField } from "@one/react-kit";
import { useEffect } from "react";
import styled from "styled-components";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker
} from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import { format } from "date-fns";
import locale from "date-fns/locale/en-US";
import { useSelector } from "react-redux";
import { GXPemptyInstrumentsOptions } from "./../../../constants";
import { useFormikContext } from "formik";
import { useFormStyles } from "./../instrument-form/FormStyles";
import { commonPropsForInputsWithoutValue } from "../helpers";
import SelectInput from "./../instrument-form/select-input";

const IdentificationForm = styled.div`
  & > .selectBox {
    margin: 0 20px 20px 0px;
    width: 100%;
    max-width: 210px;
  }
  & > .textInputBox {
    margin: 0 20px 20px 0px;
    width: 100%;
    max-width: 260px;
  }
  & > .selectBoxLarge {
    margin: 0 20px 20px 0px;
    width: 100%;
    max-width: 300px;
  }
  & > .datePicker {
    margin: 0 20px 20px 0px;
    min-width: 290px;
    background-color: rgb(245, 245, 245);
    border-radius: 7px;
  }
  & > .datePicker > label {
    padding-left: 15px;
  }
  & > .datePicker input {
    padding-left: 15px;
  }
`;

const DatePicker = ({
  formik,
  dataTestid,
  id,
  name,
  label,
  value,
  formikErrors,
  dataTestIdHelp,
  maxDate=false,
  minDate=false
}) => {
  const Rest =[];

  if(maxDate === true){ Rest["maxDate"] =  new Date(); }
  if(minDate === true){ Rest["minDate"] =  new Date(); }
 
  return (
    <MuiPickersUtilsProvider
      utils={DateFnsUtils}
      locale={{
        ...locale,
        options: {
          ...locale.options,
          weekStartsOn: 1
        }
      }}
    >
      <KeyboardDatePicker
        disableToolbar
        refuse={/[^\dA-Za-z]+/gi}
        format="dd-MMM-yyyy"
        className="datePicker"
        data-testid={dataTestid}
        id={id}
        name={name}
        label={label}
        value={value}
        autoOk={true}
        onChange={(date) => {
          if (date instanceof Date && !isNaN(date)) {
            formik.setFieldValue(name, format(date, "yyyy-MM-dd"), true);
          } else {
            formik.setFieldValue(name, date, true);
          }
        }}
        variant="inline"
        error={Boolean(formikErrors)}
        helperText={formikErrors}
        FormHelperTextProps={{
          "data-testid": dataTestIdHelp
        }}
        {...Rest}
      />
    </MuiPickersUtilsProvider>
  );
};

const GpxMaintainanceInformation = () => {
  const formik = useFormikContext();
  const classes = useFormStyles();
  const listOptions = useSelector((state) => state.instruments);
  const sopListRemovedIsactive = listOptions.sopList.filter(
    (sop) => delete sop?.isActive
  );
  useEffect(() => {
    formik.setFieldTouched("maintenancePlan");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <IdentificationForm>
        <SelectInput
          className="selectBox"
          multiple={true}
          testidPrefix="action-data"
          options={sopListRemovedIsactive}
          property="sop"
          Selectlabel="SOP"
          testid="sop"
          propValue="key"
          propLabel="value"
          objectAsValue
        />

        <SelectInput
          className="selectBox"
          testidPrefix="action-data"
          objectAsValue
          options={GXPemptyInstrumentsOptions?.csv}
          property="csv"
          Selectlabel="CSV relevant?"
          testid="csv"
          propValue="key"
          propLabel="value"
        />

        <SelectInput
          className="selectBox"
          testidPrefix="action-data"
          objectAsValue
          options={GXPemptyInstrumentsOptions?.electronicRecord}
          property="electronicRecord"
          Selectlabel="Electronic records(ER)?"
          testid="electronicRecord"
          propValue="key"
          propLabel="value"
        />
        <SelectInput
          className="selectBox"
          testidPrefix="action-data"
          objectAsValue
          options={GXPemptyInstrumentsOptions?.electronicSignatures}
          property="electronicSignatures"
          Selectlabel="Electronic signatures?"
          testid="electronicSignatures"
          propValue="key"
          propLabel="value"
        />

        <DatePicker
          formik={formik}
          dataTestid={
            "basic-data-additional-info-fields-date-Of-Next-Periodic-Review"
          }
          id="dateOfNextPeriodicReview"
          name="dateOfNextPeriodicReview"
          label="Periodic review for CSV systems"
          value={formik.values.dateOfNextPeriodicReview}
          formikErrors={formik.errors.dateOfNextPeriodicReview}
          dataTestIdHelp={
            "basic-data-additional-info-fields-instrument-helper-text-date-Of-Next-Periodic-Review"
          }
        />

        <RocheTextField
          data-testid={`text-field-maintenancePlan`}
          color="primary"
          variant="filled"
          className="textInputBox"
          label="Maintenance or calibration plan"
          name="maintenancePlan"
          onChange={formik.handleChange}
          value={formik.values?.maintenancePlan}
          onBlur={formik.handleBlur}
          {...commonPropsForInputsWithoutValue(
            classes,
            formik,
            "maintenancePlan",
            "maintenancePlan",
            "text-field"
          )}
        />

        <SelectInput
          className="selectBox"
          testidPrefix="action-data"
          objectAsValue
          options={GXPemptyInstrumentsOptions?.gxpRelevant}
          property="gxpRelevant"
          Selectlabel="GxP relevant?"
          testid="gxpRelevant"
          propValue="key"
          propLabel="value"
        />

        <SelectInput
          className="selectBox"
          testidPrefix="action-data"
          objectAsValue
          options={GXPemptyInstrumentsOptions?.instrumentGxPStatus}
          property="instrumentGxPStatus"
          Selectlabel="GxP state?"
          testid="instrumentGxPStatus"
          required
          propValue="key"
          propLabel="value"
        />

        <DatePicker
          formik={formik}
          dataTestid={
            "basic-data-additional-info-fields-instrument-date-Of-Last-Maintanance"
          }
          id="dateOfLastMaintanance"
          name="dateOfLastMaintanance.value"
          label="Date of executed maintenance"
          value={formik.values.dateOfLastMaintanance?.value}
          maxDate = {true}
          minDate = {false}
          formikTouched={formik.touched.dateOfLastMaintanance?.value}
          formikErrors={formik.errors.dateOfLastMaintanance?.value}
          dataTestIdHelp={
            "basic-data-additional-info-fields-instrument-helper-text-date-Of-Last-Maintanance-input"
          }
        />

        <DatePicker
          formik={formik}
          dataTestid={
            "basic-data-additional-info-fields-instrument-date-of-next-maintanance-input"
          }
          id="dateOfNextMaintanance"
          name="dateOfNextMaintanance.value"
          label="Next maintenance or calibration"
          maxDate = {false}
          minDate = {true}
          value={formik.values.dateOfNextMaintanance?.value}
          formikErrors={formik.errors.dateOfNextMaintanance?.value}
          dataTestIdHelp={
            "basic-data-additional-info-fields-instrument-helper-text-date-of-next-maintanance-input"
          }
        />
      </IdentificationForm>
    </>
  );
};

export default GpxMaintainanceInformation;
