import styled, { css } from "styled-components";
import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Stepper from "@material-ui/core/Stepper";
import Step from "@material-ui/core/Step";
import StepLabel from "@material-ui/core/StepLabel";
import { getSteps } from "./../../../constants";
import { Check } from "@material-ui/icons";
import { StepperElementStyled } from "./AddEquipmentStyle";
import { compose } from "redux";
import { connect } from "react-redux";
import {
  updateInstrumentDetail as updateInstrumentDetailAction,
  loadInstruments as loadInstrumentsAction
} from "../redux/actions";
import { withApollo } from "react-apollo";

const useStyles = makeStyles(() => ({
  root: {
    width: "100%"
  },
  stepper: {
    padding: "10px 70px"
  },
  step: {
    padding: "0 29px",
    "&:first-child": {
      paddingLeft: 60
    },
    "&:last-child": {
      paddingRight: 60
    }
  },
  stepLabel: {
    minWidth: 90,
    textTransform: "capitalize",
    "&$stepAlternativeLabel": {
      marginTop: 8
    }
  },
  stepAlternativeLabel: {},
  stepActiveLabel: {
    "&$stepLabel": {
      color: "#0066CC"
    }
  },
  stepCompletedLabel: {
    "&$stepLabel": {
      fontWeight: "400",
      color: "#333333"
    }
  }
}));
const stepIconActive = css`
  font-weight: 500;
  background: #0066cc;
  color: #fff;
`;
const stepIconInactive = css`
  font-weight: 400;
  border: 1px solid #737373;
  color: #737373;
`;
const StepIconStyled = styled.div`
  width: 32px;
  height: 32px;
  border-radius: 50%;

  display: flex;
  align-items: center;
  justify-content: center;

  font-size: 16px;
  line-height: 19px;

  ${(props) => props.active && stepIconActive}
  ${(props) => !props.active && stepIconInactive}
`;
const CompletedStepIconStyled = styled.div`
  width: 32px;
  height: 32px;

  display: flex;
  align-items: center;
  justify-content: center;

  border: 2px solid #00875a;
  border-radius: 50%;

  color: #00875a;
`;

const StepConnector = styled.div`
  position: absolute;
  top: 15px;
  left: -50px;

  width: 100px;
  height: 2px;

  background-image: linear-gradient(
    to right,
    #bababa 50%,
    rgba(255, 255, 255, 0) 0%
  );
  background-position: bottom;
  background-size: 12px 2px;
  background-repeat: repeat-x;
`;

const StepIcon = (props) =>
  props.completed ? (
    <CompletedStepIconStyled data-testid="completed-step-icon-styled">
      <Check />
    </CompletedStepIconStyled>
  ) : (
    <StepIconStyled active={props.active}>{props.icon}</StepIconStyled>
  );

const StepperElement = ({
  activeStep,
  setActiveStep,
  isEditMode,
  instrumentDetail,
  errors
}) => {
  const classes = useStyles();
  const steps = getSteps();

  const handleStep = (step) => () => {
    if (isEditMode && Object.keys(errors).length <= 0) {
      if (step === 4) {
        step =
          instrumentDetail?.equipmentCategory?.value === "Analyzer" ? 4 : 5;
      }
      setActiveStep(step);
    }
  };

  return (
    <StepperElementStyled data-testid="add-equipment-stepper-element">
      <div className={classes.root}>
        <Stepper
          data-testid="booking-calendar-stepper-element-box"
          classes={{
            root: classes.stepper
          }}
          activeStep={activeStep}
          alternativeLabel
          connector={<StepConnector />}
        >
          {steps.map((label, index) => (
            <Step
              data-testid={`booking-calendar-stepper-element-step`}
              key={label}
              classes={{
                root: classes.step
              }}
            >
              <StepLabel
                data-testid={`booking-calendar-stepper-element-step-label`}
                classes={{
                  active: classes.stepActiveLabel,
                  label: classes.stepLabel,
                  completed: classes.stepCompletedLabel
                }}
                StepIconComponent={StepIcon}
                onClick={handleStep(index)}
              >
                {label}
              </StepLabel>
            </Step>
          ))}
        </Stepper>
      </div>
    </StepperElementStyled>
  );
};

const mapStateToProps = (state) => ({
  instrumentDetail: state.instruments?.instrumentDetail
});
export default compose(
  connect(mapStateToProps, {
    updateInstrumentDetail: updateInstrumentDetailAction,
    loadInstruments: loadInstrumentsAction
  }),
  withApollo
)(StepperElement);
