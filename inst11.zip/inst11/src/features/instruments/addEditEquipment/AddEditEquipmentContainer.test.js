 import React from "react";
 import { render, cleanup, waitFor, fireEvent } from "@testing-library/react";
 import { ThemeProvider, theme } from "@material-ui/core/styles";
 import { Provider } from "react-redux";
 import AddInstrumentContainer from "./AddEditEquipmentContainer";
 import { Formik } from "formik";
 import { emptyDigitalLabInfo } from "../../../constants";
 import { store } from "../../../store";
 import { ApolloProvider } from "react-apollo";
 import { appSyncClient } from "./../../../appSyncClient";
 import {
  AddContainer,
  Highlighter,
  NavReactangleBar,
  AddContainerHeader,
  AddContainerBody,
  AddContainerFooter,
  PreviousButtonStyled,
  CustomTypography
} from "./AddEquipmentStyle";

 
 afterEach(cleanup);
//const errors;
 const TestComponent = (isEditMode, activeStep ) => {
  const props =
   {isEditMode: isEditMode,
   activeStep: activeStep,
     };
    const onSubmit = jest.fn();
     const setActiveStep = jest.fn();
     return (<ApolloProvider client={appSyncClient}> 
      <Provider store={store}> 
      <Formik
       initialValues={{
          ...emptyDigitalLabInfo }} 
            onSubmit={onSubmit} >
           <ThemeProvider theme={theme}> 
           <AddInstrumentContainer {...props} 
             setActiveStep={setActiveStep} /> 
           </ThemeProvider>
            </Formik>
      </Provider> 
      </ApolloProvider>);};
           
  describe("AddInstrumentContainer", () =>  { 
    it("should render AddInstrumentContainer successfully - base", async () => 
         { const { getByTestId } = render(
           <TestComponent isEditMode={false} />);
           await waitFor(() =>
           expect(getByTestId("add-edit-equipment-container")).toBeInTheDocument()
           ); 
     });
     it("should render success fully - base", async () => {
          const { getByTestId } = render(
                <TestComponent isEditMode={true} activeStep={0} />
          );
        //  expect(getByTestId("add-instrument-next-step-butt")).toBeInTheDocument();
          expect(getByTestId("add-instrument-next-step-button")).toBeInTheDocument();
     });
     it("should render success fully step button", async () => {
      const { getByTestId } = render(
            <TestComponent  variant="contained" />
      );
      expect(getByTestId("add-instrument-prev-step-button")).toBeInTheDocument();
     });

     it("should render success next conteiner", async () => {
      const { getByTestId } = render(
            <TestComponent isEditMode={true}/>
      );
      expect(getByTestId("add-instrument-next-button")).toBeInTheDocument();
     });
     it("should render success next conteiner", async () => {
      const { getByTestId } = render(
            <TestComponent setActiveStep={true}/>
      );
      expect(getByTestId("add-instrument-next-button")).toBeInTheDocument();
     });
     it("should render success edit mode", async () => {
      const { getByTestId } = render(
            <TestComponent isEditMode={false}/>
      );
      expect(getByTestId("add-instrument-next-button")).toBeInTheDocument();
     });
     it("should render success step false", async () => {
      const { getByTestId } = render(
            <TestComponent setActiveStep={false}/>
      );
      expect(getByTestId("add-instrument-next-button")).toBeInTheDocument();
     });

     test("should create prev page", async () => {
      const { getByTestId } = render(
        <TestComponent setActiveStep={true}/>
        );
         expect(getByTestId("add-instrument-prev-step-button")).toBeDefined()
     });

     test("should create prevpage", async () => {
      const { getByTestId } = render(
                // <AddContainerBody>
                    <AddContainerFooter/>
              //  </AddContainerBody>
        );
        await waitFor(() => {
         expect(getByTestId("add-instrument-footer")).toBeCalledWith();//.toBeInTheDocument()
        })
     });
  });


 