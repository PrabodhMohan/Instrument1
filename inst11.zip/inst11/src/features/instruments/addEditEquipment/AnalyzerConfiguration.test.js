import React from "react";
import { render, cleanup, waitFor, fireEvent } from "@testing-library/react";
import { ThemeProvider, theme } from "@material-ui/core/styles";
import { Provider } from "react-redux";
import { Formik } from "formik";
import AnalyzerConfiguration from "./AnalyzerConfiguration";
import {
  getInitialValue,
  getValidationSchema
} from "../instrument-form/validation-schemas-step";
import { store } from "../../../store";

afterEach(cleanup);

const TestComponent = () => {
  const onSubmit = jest.fn();
  const setFieldValue = jest.fn();
  return (
    <form data-testid="test-form">
      <Provider store={store}>
        <Formik
          initialValues={getInitialValue(4)}
          validationSchema={getValidationSchema(4)}
          onSubmit={onSubmit}
          isInitialValid={false}
          setFieldValue={setFieldValue}
        >
          <ThemeProvider theme={theme}>
            <AnalyzerConfiguration />
          </ThemeProvider>
        </Formik>
      </Provider>
    </form>
  );
};

describe("AnalyzerConfiguration", () => {
  it("should render successfully - base", async () => {
    const { getByTestId } = render(<TestComponent />);

    await waitFor(() =>
      expect(getByTestId("text-field-softwareVersion")).toBeInTheDocument()
    );
    await waitFor(() =>
      expect(
        getByTestId("text-field-configurationbaseLine")
      ).toBeInTheDocument()
    );
    await waitFor(() =>
      expect(getByTestId("text-field-installed-test")).toBeInTheDocument()
    );
    await waitFor(() =>
      expect(getByTestId("text-field-linked-documents")).toBeInTheDocument()
    );
    fireEvent.click(getByTestId("text-field-softwareVersion"));
    fireEvent.click(getByTestId("text-field-configurationbaseLine"));
    fireEvent.click(getByTestId("text-field-installed-test"));
    fireEvent.click(getByTestId("text-field-linked-documents"));
  });

  it("pop up should be visible => installedTest", () => {
    const { getByTestId } = render(<TestComponent />);
    const showPopUp = getByTestId(`show-popup-installedTest`);
    const spy = jest.spyOn(showPopUp, "click");

    showPopUp.click("installedTest");
    spy.mockRestore();
  });

  it("pop up should be visible => linkedDoc", () => {
    const { getByTestId } = render(<TestComponent />);
    const showPopUp = getByTestId(`show-popup-linkedDoc`);
    const spy = jest.spyOn(showPopUp, "click");

    showPopUp.click("linkedDoc");
    spy.mockRestore();
  });

  it("pop up should be closed => close", () => {
    const { getByTestId } = render(<TestComponent />);
    const closePopUp = getByTestId(`close-popup-close-installedTest`);
    const spy = jest.spyOn(closePopUp, "click");

    closePopUp.click();
    spy.mockRestore();
  });

  it("pop up should be closed => close button", () => {
    const { getByTestId } = render(<TestComponent />);
    const closePopUp = getByTestId(`close-popup-close-linkedDoc`);
    const spy = jest.spyOn(closePopUp, "click");

    closePopUp.click();
    spy.mockRestore();
  });

  it.skip("getTestValue statement", async () => {
    const getTestValue = (selected) => {
      if (typeof selected != "undefined") {
        if (selected.length === 0) {
          return "";
        }
        if (selected.length === 1) {
          return `${selected[0]?.name}, ${selected[0]?.version}`;
        }
        if (selected.length > 1) {
          return `${selected[0]?.name}, ${selected[0]?.version} +${
            selected.length - 1
          }`;
        }
      } else {
        return "";
      }
    };
    const formik = {
      values: {
        installedTests: [
          { name: "test1", version: "version1", __typename: "InstalledTest" },
          { name: "test2", version: "version2", __typename: "InstalledTest" },
          { name: "test3", version: "version3", __typename: "InstalledTest" }
        ]
      }
    };
    jest
      .spyOn(
        getTestValue,
        `[{ name: "test1", version: "version1", __typename: "InstalledTest" }]`
      )
      .mockReturnValue(
        `[{ name: "test1", version: "version1", __typename: "InstalledTest" }]`
      );

    const { getByTestId } = render(<TestComponent />);
    const DraftEditor = getByTestId("text-field-installed-test");
    DraftEditor.value = getTestValue(formik.values?.installedTests);
    fireEvent.change(DraftEditor);
    expect(getTestValue()).toBeCalled();
  });
});
test("to be visible", async () => {
  const { getByTestId, getByLabelText } = render(<TestComponent />);

  fireEvent.submit(getByTestId("test-form"));

  await waitFor(() => {
    expect(getByTestId("text-field-softwareVersion")).toBeVisible();
    expect(getByTestId("text-field-configurationbaseLine")).toBeVisible();
    expect(getByTestId("text-field-installed-test")).toBeVisible();
    expect(getByTestId("text-field-linked-documents")).toBeVisible();
  });
});

test("to have text content", async () => {
  const { getByTestId, getByLabelText } = render(<TestComponent />);
  fireEvent.submit(getByTestId("test-form"));
  await waitFor(() => {
    expect(getByTestId("text-field-softwareVersion")).toHaveTextContent(
      "Software"
    );
    expect(getByTestId("text-field-configurationbaseLine")).toHaveTextContent(
      "Configuration"
    );
    expect(getByTestId("text-field-installed-test")).toHaveTextContent(
      "Installed"
    );
    expect(getByTestId("text-field-linked-documents")).toHaveTextContent(
      "Linked"
    );
  });
});
