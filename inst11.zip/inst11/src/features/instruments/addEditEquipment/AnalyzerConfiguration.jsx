import React, { useState } from "react";
import { RocheTextField } from "@one/react-kit";
import styled from "styled-components";
import AssaysDataForm from "../AssaysDataForm";
import { Button } from "@material-ui/core";
import { RocheInputAdornment } from "@one/react-kit/inputAdornment";
import { useFormikContext } from "formik";
import DocumentsDataForm from "../DocumentsDataForm";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import { commonPropsForInputsWithoutValue } from "../helpers";
import { useFormStyles } from "./../instrument-form/FormStyles";
import TextField from "@one/react-kit/textField";
import { withStyles } from "@material-ui/styles";

const testStyle = {
  color: "#0066cc",
  position: "absolute",
  right: "50px",
  top: "21px"
};
const OutlineIcon = styled.div`
  border: 1px solid #737373;
  justify-content: center;
  align-items: center;
  padding-top: 5px;
  padding-left: 5px;
  padding-right: 5px;
  border-radius: 5px;
  cursor: pointer;
`;

const InstallDocumentContainer = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  & > .selectBoxLarge {
    margin: 0 20px 20px 0px;
    width: 320px;
    max-width: 320px;
  }
`;
const InstallContainer = styled.div`
  position: absolute;
  top: 40px;
  left: -10px;
  width: 520px;
  background: #ffffff;
  box-shadow: 0px 10px 10px rgba(0, 0, 0, 0.5);
  z-index: 10;
  border-radius: 4px;
`;

const DocumentContainer = styled.div`
  position: absolute;
  top: 40px;
  left: -150px;
  width: 520px;
  background: #ffffff;
  box-shadow: 0px 10px 10px rgba(0, 0, 0, 0.5);
  z-index: 10;
  border-radius: 4px;
`;

const AddCancelButton = styled.div`
  display: flex;
  justify-content: end;
  margin-bottom: 1rem;
  margin-right: 1rem;
`;

const IdentificationForm = styled.div`
  display: flex;
  flex-direction: row;
  & > .selectBox {
    margin: 0 20px 20px 0px;
    width: 100%;
    max-width: 220px;
  }
  & > .textInputBox {
    margin: 0 20px 20px 0px;
    width: 100%;
    max-width: 220px;
  }
`;
const CustomTextField = withStyles((theme) => ({
  root: {
    "& .MuiFilledInput-input": {
      maxWidth: "100%",
      overflow: "hidden",
      textOverflow: "ellipsis",
      WebkiLineClamp: 1,
      display: "-webkit-box",
      WebkitBoxOrient: "vertical",
      wordBreak: "break-all"
    }
  }
}))(TextField);

const AnalyzerConfiguration = () => {
  const [showInstalledTestPopUp, setShowInstalledTestPopUp] = useState(false);
  const [showLiknedDocumentsPopUp, setShowLinkedDocumentsPopUp] =
    useState(false);
  const formik = useFormikContext();
  const classes = useFormStyles();
  const handleClosePopup = () => {
    if (showInstalledTestPopUp || showLiknedDocumentsPopUp) {
      setShowInstalledTestPopUp(false);
      setShowLinkedDocumentsPopUp(false);
    }
  };

  const handleShowPopup = (value) => {
    if (value === "installedTest") {
      setShowInstalledTestPopUp(!showInstalledTestPopUp);
      setShowLinkedDocumentsPopUp(false);
    } else if (value === "linkedDoc") {
      setShowInstalledTestPopUp(false);
      setShowLinkedDocumentsPopUp(!showLiknedDocumentsPopUp);
    }
  };

  const getTestValue = (selected) => {
    if (selected !== null) {
      if (selected.length === 0) {
        return "";
      } else if (selected.length > 0) {
        return `${selected[0]?.name}, ${selected[0]?.version}`;
      }
    } else {
      return "";
    }
  };

  const getInstalledDocValue = (selected) => {
    if (typeof selected != "undefined") {
      if (selected.length === 0) {
        return "";
      }
      if (selected.length > 0) {
        return `${selected[0]?.name}, ${selected[0]?.documentId}`;
      }
    } else {
      return "";
    }
  };
  return (
    <IdentificationForm>
      <RocheTextField
        data-testid={`text-field-softwareVersion`}
        className="textInputBox"
        label="Software version"
        name="softwareVersion"
        onChange={formik.handleChange}
        value={formik.values?.softwareVersion}
        onBlur={formik.handleBlur}
        onFocus={handleClosePopup}
        {...commonPropsForInputsWithoutValue(
          classes,
          formik,
          "softwareVersion",
          "softwareVersion",
          "text-field"
        )}
        variant="filled"
        color="primary"
      />
      <RocheTextField
        data-testid={`text-field-configurationbaseLine`}
        className="textInputBox"
        label="Configuration baseline"
        name="configurationBaseline"
        onChange={formik.handleChange}
        value={formik.values?.configurationBaseline}
        onBlur={formik.handleBlur}
        onFocus={handleClosePopup}
        {...commonPropsForInputsWithoutValue(
          classes,
          formik,
          "configurationBaseline",
          "configurationBaseline",
          "text-field"
        )}
        variant="filled"
        color="primary"
      />

      <InstallDocumentContainer>
        <CustomTextField
          className="selectBoxLarge"
          data-testid={`text-field-installed-test`}
          label="Installed tests"
          name="installedTests"
          size="medium"
          autoComplete="off"
          onClick={() => {
            handleShowPopup("installedTest");
          }}
          value={getTestValue(formik.values?.installedTests)}
          InputProps={{
            readOnly: true,
            endAdornment: (
              <RocheInputAdornment position="end">
                {formik.values?.installedTests !== null &&
                formik.values?.installedTests.length > 1 ? (
                  <div style={testStyle}>
                    {" "}
                    +{formik.values?.installedTests.length - 1}
                  </div>
                ) : (
                  ""
                )}
                <OutlineIcon
                  onClick={() => {
                    handleShowPopup("installedTest");
                  }}
                  data-testid={`show-popup-installedTest`}
                >
                  <AddCircleOutlineIcon />
                </OutlineIcon>
              </RocheInputAdornment>
            )
          }}
        />

        <InstallContainer
          style={{ display: showInstalledTestPopUp ? "block" : "none" }}
        >
          {showInstalledTestPopUp ? <AssaysDataForm formik={formik} /> : ""}
          <AddCancelButton>
            <Button
              color="primary"
              variant="contained"
              style={{ textTransform: "none" }}
              onClick={handleClosePopup}
              data-testid={`close-popup-close-installedTest`}
            >
              Close
            </Button>
          </AddCancelButton>
        </InstallContainer>
      </InstallDocumentContainer>
      <InstallDocumentContainer>
        <CustomTextField
          className="selectBoxLarge"
          data-testid={`text-field-linked-documents`}
          label="Linked documents"
          name="qualificationDocuments"
          size="medium"
          autoComplete="off"
          onClick={() => {
            handleShowPopup("linkedDoc");
          }}
          value={getInstalledDocValue(
            formik.values?.qualificationDocuments?.value
          )}
          InputProps={{
            readOnly: true,
            endAdornment: (
              <RocheInputAdornment position="end">
                {formik.values?.qualificationDocuments?.value?.length > 1 ? (
                  <div style={testStyle}>
                    +{formik.values?.qualificationDocuments?.value?.length - 1}
                  </div>
                ) : (
                  ""
                )}
                <OutlineIcon
                  data-testid={`show-popup-linkedDoc`}
                  onClick={() => {
                    handleShowPopup("linkedDoc");
                  }}
                >
                  <AddCircleOutlineIcon />
                </OutlineIcon>
              </RocheInputAdornment>
            )
          }}
        />
        <DocumentContainer
          style={{ display: showLiknedDocumentsPopUp ? "block" : "none" }}
        >
          {showLiknedDocumentsPopUp ? (
            <DocumentsDataForm formik={formik} />
          ) : (
            ""
          )}
          <AddCancelButton>
            <Button
              color="primary"
              variant="contained"
              style={{ textTransform: "none" }}
              data-testid={`close-popup-close-linkedDoc`}
              onClick={handleClosePopup}
            >
              Close
            </Button>
          </AddCancelButton>
        </DocumentContainer>
      </InstallDocumentContainer>
    </IdentificationForm>
  );
};

export default AnalyzerConfiguration;
