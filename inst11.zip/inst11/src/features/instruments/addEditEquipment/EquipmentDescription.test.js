import React from "react";
import EquipmentDescription from "./EquipmentDescription";
import { render, cleanup, waitFor } from "@testing-library/react";
import { ThemeProvider, theme } from "@material-ui/core/styles";
import { store } from "../../../store";
import { Provider } from "react-redux";
import { emptyEquipmentDescription } from "./../../../constants";
import { Formik } from "formik";
import { descriptionValidationSchema } from "../instrument-form/descriptionValidationSchema";

afterEach(cleanup);

describe("EquipmentDescription", () => {
  it("should render successfully - base", async () => {
    const onSubmit = jest.fn();
    const { getByTestId } = render(
      <Provider store={store}>
        <Formik
          initialValues={{
            ...emptyEquipmentDescription
          }}
          validationSchema={descriptionValidationSchema}
          onSubmit={onSubmit}
          isInitialValid={false}
        >
          <ThemeProvider theme={theme}>
            <EquipmentDescription activeStep={1} />
          </ThemeProvider>
        </Formik>
      </Provider>
    );

    await waitFor(() =>
      expect(getByTestId("text-field-Instrument-name")).toBeInTheDocument()
    );
  });
});
