import React, { useCallback, useState } from "react";
import { debounce } from "lodash";
import { RocheInputAdornment, RocheTextField } from "@one/react-kit";
import IconButton from "@material-ui/core/IconButton";
import { Search as SearchIcon } from "@material-ui/icons";

const Search = ({ setQuery, label, testid = "search" }) => {
  const [searchQuery, setSearchQuery] = useState("");
  /* eslint-disable react-hooks/exhaustive-deps */
  const delayedQuery = useCallback(
    debounce((q) => setQuery(q), 500),
    [setQuery]
  );
  const onChange = (e) => {
    setSearchQuery(e.target.value);
    delayedQuery(e.target.value);
  };
  const onClear = () => {
    setQuery("");
    setSearchQuery("");
  };
  return (
    <RocheTextField
      data-testid={testid}
      label={label}
      id="searchInstrument"
      color="primary"
      variant="filled"
      size="medium"
      value={searchQuery}
      onChange={onChange}
      InputProps={{
        startAdornment: (
          <RocheInputAdornment position="start">
            <SearchIcon />
          </RocheInputAdornment>
        ),
        endAdornment: searchQuery && (
          <RocheInputAdornment position="end">
            <IconButton
              data-testid="clear-search-button"
              edge="end"
              onClick={() => onClear()}
            >
              <i className="one-icons">clear</i>
            </IconButton>
          </RocheInputAdornment>
        )
      }}
    />
  );
};

export default Search;
