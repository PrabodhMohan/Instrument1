import { render, cleanup, fireEvent } from "../../test-utils";
import TabsForModalEditInstrument from "./TabsForModalEditInstrument";

afterEach(cleanup);

test("should create tabs for modal edit instrument", () => {
  const choosenTab = "assays";
  const setChoosenTab = jest.fn();
  const { getByTestId } = render(
    <TabsForModalEditInstrument
      choosenTab={choosenTab}
      setChoosenTab={setChoosenTab}
    />
  );
  const assaysTab = getByTestId("tabs-for-modal-edit-tab-installed-tests");
  expect(assaysTab.getAttribute("aria-selected")).toBe("true");
  const basicDataTab = getByTestId("tabs-for-modal-edit-tab-basic-data");
  fireEvent.click(basicDataTab);
  expect(setChoosenTab).toHaveBeenCalledWith("basicData");
});
