import { render, cleanup, fireEvent } from "../../test-utils";
import { emptyInstruments } from "./InstrumentsModal";
import { data } from "../../utils/test/data-test";
import { waitFor } from "@testing-library/dom";
import { useFormik } from "formik";
import DocumentsDataForm from "./DocumentsDataForm";

afterEach(cleanup);

const TestComponent = () => {
  const formik = useFormik({
    initialValues: {
      ...emptyInstruments
    }
  });

  return <DocumentsDataForm formik={formik} />;
};

test.skip("should create", async () => {
  const { getByTestId } = render(<TestComponent />);

  await waitFor(() => expect(getByTestId("documents-data-form")).toBeDefined());
});

test.skip("should add document then edit then delete", async () => {
  const { getByTestId, getByLabelText, queryByTestId } = render(
    <TestComponent />
  );

  fireEvent.change(getByLabelText(/document name/i), {
    target: {
      value: "test"
    }
  });
  fireEvent.change(getByLabelText(/Document id/i), {
    target: {
      value: "123"
    }
  });

  fireEvent.click(
    getByTestId("documents-data-form-document-button-adding-new")
  );

  await waitFor(() => {
    expect(
      getByTestId(
        "documents-data-form-document-list-info-row-name"
      ).textContent.trim()
    ).toBe("test");
    expect(
      getByTestId(
        "documents-data-form-document-list-info-row-documentId"
      ).textContent.trim()
    ).toBe("123");
  });

  fireEvent.click(
    getByTestId("documents-data-form-document-list-edit-iconbutton")
  );

  fireEvent.change(getByLabelText(/document name/i), {
    target: {
      value: "test edit"
    }
  });
  fireEvent.change(getByLabelText(/document id/i), {
    target: {
      value: "123/edit"
    }
  });

  fireEvent.click(getByTestId("documents-data-form-document-button-edit"));

  await waitFor(() => {
    expect(
      getByTestId(
        "documents-data-form-document-list-info-row-name"
      ).textContent.trim()
    ).toBe("test edit");
    expect(
      getByTestId(
        "documents-data-form-document-list-info-row-documentId"
      ).textContent.trim()
    ).toBe("123/edit");
  });

  fireEvent.click(
    getByTestId("documents-data-form-document-list-delete-iconbutton")
  );

  await waitFor(() => {
    expect(
      queryByTestId("documents-data-form-document-list-info-row-name")
    ).toBe(null);
    expect(
      queryByTestId("documents-data-form-document-list-info-row-version")
    ).toBe(null);
  });
});

test.skip("should add test then edit then cancel", async () => {
  const { getByTestId, getByLabelText } = render(<TestComponent />);

  fireEvent.change(getByLabelText(/document name/i), {
    target: {
      value: "test"
    }
  });
  fireEvent.change(getByLabelText(/document id/i), {
    target: {
      value: "123"
    }
  });

  fireEvent.click(
    getByTestId("documents-data-form-document-button-adding-new")
  );

  await waitFor(() => {
    expect(
      getByTestId(
        "documents-data-form-document-list-info-row-name"
      ).textContent.trim()
    ).toBe("test");
    expect(
      getByTestId(
        "documents-data-form-document-list-info-row-documentId"
      ).textContent.trim()
    ).toBe("123");
  });

  fireEvent.click(
    getByTestId("documents-data-form-document-list-edit-iconbutton")
  );

  fireEvent.change(getByLabelText(/document name/i), {
    target: {
      value: "test edit"
    }
  });
  fireEvent.change(getByLabelText(/document id/i), {
    target: {
      value: "123/edit"
    }
  });

  fireEvent.click(getByTestId("documents-data-form-document-button-clear"));

  await waitFor(() => {
    expect(
      getByTestId(
        "documents-data-form-document-list-info-row-name"
      ).textContent.trim()
    ).toBe("test");
    expect(
      getByTestId(
        "documents-data-form-document-list-info-row-documentId"
      ).textContent.trim()
    ).toBe("123");
  });
});

test.skip("should clear inputs", async () => {
  const { getByTestId, getByLabelText } = render(<TestComponent />);

  fireEvent.change(getByLabelText(/document name/i), {
    target: {
      value: "test"
    }
  });
  fireEvent.change(getByLabelText(/document id/i), {
    target: {
      value: "123"
    }
  });

  await waitFor(() => {
    expect(getByLabelText(/document name/i).value.trim()).toBe("test");
    expect(getByLabelText(/document id/i).value.trim()).toBe("123");
  });

  fireEvent.click(
    getByTestId("documents-data-form-document-name-input-clear-button")
  );
  fireEvent.click(
    getByTestId("documents-data-form-document-documentId-input-clear-button")
  );

  await waitFor(() => {
    expect(getByLabelText(/document name/i).value.trim()).toBe("");
    expect(getByLabelText(/document id/i).value.trim()).toBe("");
  });
});

test.skip("should validate", async () => {
  const { getByTestId, getByLabelText } = render(<TestComponent />);

  fireEvent.click(
    getByTestId("documents-data-form-document-button-adding-new")
  );

  await waitFor(() => {
    expect(
      getByTestId(
        "documents-data-form-document-name-input-helper-text"
      ).textContent.trim()
    ).toBe("Enter name");
    expect(
      getByTestId(
        "documents-data-form-document-documentId-input-helper-text"
      ).textContent.trim()
    ).toBe("Enter document id");
  });

  fireEvent.change(getByLabelText(/document id/i), {
    target: {
      value: ""
    }
  });
  await waitFor(() => {
    expect(
      getByTestId(
        "documents-data-form-document-documentId-input-helper-text"
      ).textContent.trim()
    ).toBe("Enter document id");
  });
});
