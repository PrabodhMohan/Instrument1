import React, { useState, useEffect } from "react";
import styled from "styled-components";
import CustomSelect from "../../components/shared/CustomSelect";
import { connect } from "react-redux";
import { compose } from "react-apollo";
import { updateInstrumentFilter as updateInstrumentFilterAction } from "./redux/actions";
import { render, cleanup, waitFor } from "@testing-library/react";
import FilterAction from "./FilterAction";
import FilterForm from "./FilterForm";
import { ThemeProvider, theme } from "@material-ui/core/styles";
 
 export const MainRow = styled.div`
 margin-bottom: 1.25rem;
`;
export const TitleHeader = styled.h2`
 display: flex;
 justify-content: space-between;
`;
export const TitleRow = styled.h2`
 font-weight: 500;
 font-size: 1.125rem;
 line-height: 1.4375rem;
 color: #333333;
 margin-bottom: 0.75rem;
 padding: 0 16px;
`;
export const RowInputsContainer = styled.div`
 display: flex;
 padding: 1.25rem 1rem;
`;
export const RowInputs = styled.div`
 & > .customSelect {
   width: 220px;
   display: flex;
   flex-direction: column;
   margin-bottom: 1.25rem;
 }
`;

//   FilterForm = ({
//  groupList,
//  categoryList,
//  manufacturerList,
//  responsiblePersonList,
//  siteList,
//  filters,
//  updateInstrumentFilter
// }) => {
//  const [filterObj, setFilterObj] = useState(filters);
//  const [isManual, setIsManual] = useState(false);

//  const handleChange = (event) => {
//    setIsManual(true);
//    const name = event.target.name;
//    const manualFilters = {
//      ...filterObj,
//      [name]: event.target.value
//    };
//    setFilterObj(manualFilters);
//    updateInstrumentFilter(manualFilters);
//  };

//  FilterForm = ({
//     groupList,
//     categoryList,
//     manufacturerList,
//     responsiblePersonList,
//     siteList,
//     filters,
//     updateInstrumentFilter
//   }) => {
//     const [filterObj, setFilterObj] = useState(filters);
//     const [isManual, setIsManual] = useState(false);
//   }
var filters ;
 
  

const mapStateToProps = (state) => ({
 groupList: state.instruments?.groupList,
 manufacturerList: state.instruments?.manufacturerList,
 categoryList: state.instruments?.categoryList,
 responsiblePersonList: state.instruments?.responsiblePersonList,
 siteList: state.user?.sites ?? [],
 filters: state.instruments?.filters,
 user: state.user
});

afterEach(cleanup);
describe("EquipmentDescription", () => {

// useEffect(() => {
//   isManual ? setFilterObj(filterObj) : setFilterObj(filters);
//   setIsManual(false);

//   // eslint-disable-next-line react-hooks/exhaustive-deps
// }, [filters]);

  test("should create filter form table inst", () => {
      const { queryByTestId } = render( 
          // <Provider>
              <CustomSelect/> 
          // </Provider>
      );
      expect(queryByTestId("basic-data-custom-select")).toBeDefined();
  }); 
});