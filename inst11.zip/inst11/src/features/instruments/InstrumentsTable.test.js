import React from "react";
import { render, cleanup, fireEvent } from "../../test-utils";
import InstrumentsTable from "./InstrumentsTable";
import { data } from "../../utils/test/data-test";
import { filterByQuery } from "../../utils/helpers/text";
import { instrumentsMock } from "./InstrumentsModal";
import { IconButton, Tooltip } from "@material-ui/core";

import {
  CREATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
  DELETE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
  UPDATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY
} from "../../gql/landingapi/mutations";
import omitDeep from "omit-deep-lodash";
import { waitFor } from "@testing-library/react";
import { setQueryMock } from "./TopBar";
import InstrumentsModal from "./InstrumentsModal";
import styled from "styled-components";

import {
  Highlighter,
  NavReactangleBar,
  CustomTypography,
  TestCover,
  CoverMenuItem
} from "../instruments/addEditEquipment/AddEquipmentStyle";

afterEach(cleanup);


export const DescriptionForm = styled.div`
  & > .button-box-equipment {
    padding: 6px 22px;
    font-size: 16px;
  }
`;

const SettingIconcover = styled.div`
  padding-left: 20px;
`;

const ActionStyled = styled.div`
  display: flex;
  justify-content: flex-end;
`;
const ActionsCell = styled.div`
  display: flex;
  align-items: center;
  justify-content: flex-end;
`;

const IconStyle = styled.div`
  display: flex;
  padding-right: 10px;
`;

const TopBarButtons = styled.div`
  display: flex;
  margin-left: auto;
`;

const InstrumentsTableMeta = {
  rowId: ["materialNumber", "serialNumber"],
  fields: {}
};
jest.mock("../../components/shared/ConfirmDialog");
jest.mock("./InstrumentsModal");
jest.mock("../importFile/ImportFile");
jest.mock("aws-amplify");
jest.mock("./TopBar");
jest.mock("../../utils/helpers/checkRoleInstrumentRepo");

const filterItem = (instrument, other) =>
  instrument.materialNumber === other.materialNumber &&
  instrument.serialNumber === other.serialNumber;

test.skip("should find the table", async () => {
  const { getByTestId } = render(<InstrumentsTable />);

  expect(getByTestId("custom-table")).toBeInTheDocument();
  expect(getByTestId("table-head-serialNumber")).toBeInTheDocument();
});

test.skip("should save instrument", async () => {
  const allInstruments = filterByQuery(data.instruments.instruments, "");
  const updatedInstrument = {
    ...allInstruments[0],
    instrumentName: {
      value: "test",
      isSynchronized: false
    }
  };
  const { store, getAllByTestId, getByTestId } = render(<InstrumentsTable />, {
    initialState: data,
    mocksForApollo: [
      {
        request: {
          query: UPDATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
          variables: {
            ...omitDeep(updatedInstrument, "__typename")
          }
        },
        result: {
          data: {}
        }
      }
    ]
  });
  const firstItemEditButton = getAllByTestId("instrument-table-edit-button")[0];
  fireEvent.click(firstItemEditButton);
  instrumentsMock.mockReturnValue(updatedInstrument);

  fireEvent.click(getByTestId("instruments-modal-save-button"));

  await waitFor(() =>
    expect(
      getByTestId(
        `item-row-${updatedInstrument.materialNumber}${updatedInstrument.serialNumber}-instrumentName`
      ).textContent.trim()
    ).toBe("test")
  );

  expect(
    store
      .getState()
      .instruments.instruments.find((instrument) =>
        filterItem(instrument, updatedInstrument)
      ).instrumentName.value
  ).toBe("test");
});
test.skip("should create instrument", async () => {
  const allInstruments = filterByQuery(data.instruments.instruments, "");
  const creatInstrument = {
    ...allInstruments[0],
    materialNumber: "materialTest",
    serialNumber: "serialTest",
    instrumentName: {
      value: "test name",
      isSynchronized: false
    }
  };
  const { store, getByTestId } = render(<InstrumentsTable />, {
    initialState: data,
    mocksForApollo: [
      {
        request: {
          query: CREATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
          variables: {
            ...omitDeep(creatInstrument, "__typename")
          }
        },
        result: {
          data: {}
        }
      }
    ]
  });

  fireEvent.click(getByTestId("add-instrument-dialog-open-button"));
  instrumentsMock.mockReturnValue(creatInstrument);

  fireEvent.click(getByTestId("instruments-modal-save-button"));

  await waitFor(() =>
    expect(
      getByTestId(
        `item-row-${creatInstrument.materialNumber}${creatInstrument.serialNumber}-instrumentName`
      ).textContent.trim()
    ).toBe("test name")
  );

  expect(
    store
      .getState()
      .instruments.instruments.find((instrument) =>
        filterItem(instrument, creatInstrument)
      ).instrumentName.value
  ).toBe("test name");
});
test.skip("should delete instrument", async () => {
  const allInstruments = filterByQuery(data.instruments.instruments, "");
  const deleteInstrument = allInstruments[0];

  const { store, getAllByTestId, getByTestId, queryByTestId } = render(
    <InstrumentsTable />,
    {
      initialState: data,
      mocksForApollo: [
        {
          request: {
            query: DELETE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
            variables: {
              materialNumber: deleteInstrument.materialNumber,
              serialNumber: deleteInstrument.serialNumber
            }
          },
          result: {
            data: {}
          }
        }
      ]
    }
  );
  const firstItemEditButton = getAllByTestId(
    "instrument-table-delete-button"
  )[0];
  fireEvent.click(firstItemEditButton);

  fireEvent.click(getByTestId("app-confirm-dialog-approve"));

  await waitFor(() =>
    expect(
      queryByTestId(
        `item-row-${deleteInstrument.materialNumber}${deleteInstrument.serialNumber}-instrumentName`
      )
    ).toBe(null)
  );

  expect(
    store
      .getState()
      .instruments.instruments.find((instrument) =>
        filterItem(instrument, deleteInstrument)
      )
  ).toBeUndefined();
});
test("should click to delete instrument and cancel to delete a", async () => {
  const allInstruments = filterByQuery(data.instruments.instruments, "");
  const deleteInstrument = allInstruments[0];

  const { store, getAllByTestId, getByTestId, queryByTestId } = render(
    <InstrumentsTable />,
    {
      initialState: data
    }
  );
  const firstItemEditButton = getAllByTestId(
    "instrument-table-delete-button"
  )[0];
  fireEvent.click(firstItemEditButton);

  fireEvent.click(getByTestId("app-confirm-dialog-cancel"));

    waitFor(() =>
    expect(
      queryByTestId(
        `item-row-${deleteInstrument.materialNumber}${deleteInstrument.serialNumber}-instrumentName`
      ).textContent.trim()
    ).toBe(deleteInstrument.instrumentName.value)
  );

  expect(
    store
      .getState()
      .instruments.instruments.find((instrument) =>
        filterItem(instrument, deleteInstrument)
      ).instrumentName.value
  ).toBe(deleteInstrument.instrumentName.value);
});
test.skip("should click create instrument and cancel to create", async () => {
  const allInstruments = filterByQuery(data.instruments.instruments, "");
  const creatInstrument = {
    ...allInstruments[0],
    materialNumber: "rudiTest",
    instrumentName: {
      value: "test name",
      isSynchronized: false
    }
  };
  const { store, getByTestId, queryByTestId } = render(<InstrumentsTable />, {
    initialState: data
  });

  fireEvent.click(getByTestId("add-instrument-dialog-open-button"));
  instrumentsMock.mockReturnValue(creatInstrument);

  fireEvent.click(getByTestId("instruments-modal-cancel-button"));

  await waitFor(() =>
    expect(
      queryByTestId(
        `item-row-${creatInstrument.materialNumber}${creatInstrument.serialNumber}-instrumentName`
      )
    ).toBe(null)
  );

  expect(
    store
      .getState()
      .instruments.instruments.find((instrument) =>
        filterItem(instrument, creatInstrument)
      )
  ).toBeUndefined();
});

test.skip("should filter a table", () => {
  const allInstruments = filterByQuery(data.instruments.instruments, "");
  const { container, getByTestId } = render(<InstrumentsTable />, {
    initialState: data
  });

  setQueryMock.mockReturnValue("sting.5");

  fireEvent.click(getByTestId("instruments-top-bar-set-query"));
  const items = Array.from(
    container.querySelectorAll(
      "[data-testid^=item-row-][data-testid$=-instrumentName]"
    )
  );
  expect(items.map((item) => item.textContent.trim())).toEqual(
    allInstruments
      .slice(0, 2)
      .map((instrument) => instrument.instrumentName.value)
  );
});

test.skip("should sort a table", async () => {
  const allInstruments = filterByQuery(data.instruments.instruments, "");
  const { container, getByTestId } = render(<InstrumentsTable />, {
    initialState: data
  });

  fireEvent.click(getByTestId("table-head-instrumentName"));
  const items = Array.from(
    container.querySelectorAll(
      "[data-testid^=item-row-][data-testid$=-instrumentName]"
    )
  );
  await waitFor(() =>
    expect(items.map((item) => item.textContent.trim())).toEqual(
      [
        allInstruments[3],
        allInstruments[2],
        allInstruments[1],
        allInstruments[0]
      ].map((instrument) => instrument.instrumentName.value)
    )
  );
  fireEvent.click(getByTestId("table-head-materialNumber"));
  await waitFor(() => {
    const newItems = Array.from(
      container.querySelectorAll(
        "[data-testid^=item-row-][data-testid$=-materialNumber]"
      )
    );
    expect(newItems.map((item) => item.textContent.trim())).toEqual(
      [
        allInstruments[0],
        allInstruments[3],
        allInstruments[1],
        allInstruments[2]
      ].map((instrument) => instrument.materialNumber)
    );
  });
});

test.skip("should show instrument name", async () => {
  const allInstruments = [data.instruments.instruments[0]];
  const { getByTestId } = render(<InstrumentsTable />, {
    initialState: {
      instruments: {
        instruments: [
          {
            ...allInstruments[0],
            buildingLocation: null,
            floorAndRoomLocation: null
          }
        ]
      }
    }
  });

  const item = getByTestId(
    `item-row-${allInstruments[0].materialNumber}${allInstruments[0].serialNumber}-instrumentName`
  );
  await waitFor(() => expect(item.textContent.trim()).toEqual("STING.5"));
});


test("should create model", () => {
  const { queryByTestId } = render( 
     < InstrumentsModal/> 
   );
  expect(queryByTestId("instrument-model")).toBeDefined();
});

test("should create edit button", () => {
  const { queryByTestId } = render( 
     < ActionStyled> 
      
    </ActionStyled> 
   );
  expect(queryByTestId("instrument-edit-button-tooltip")).toBeDefined();
});

test("should create inst table", () => {
  const { queryByTestId } = render( 
      <Tooltip/>
    );
  expect(queryByTestId("instrument-edit-button-tooltip")).toBeDefined();
});

test("should create inst table", () => {
  const { queryByTestId } = render( 
      <Tooltip/>
    );
  expect(queryByTestId("instrument-edit-button-tool")).toBeDefined();
});

test("should create edit button", () => {
  const { queryByTestId } = render( 
      <IconButton/>
    );
  expect(queryByTestId("instrument-table-edit-button")).toBeDefined();
});
