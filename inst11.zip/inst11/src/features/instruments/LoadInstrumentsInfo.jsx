import React, { useEffect, useState } from "react";
import get from "lodash/get";
import { isEqual, pick } from "underscore";
import { connect } from "react-redux";
import { compose } from "redux";
import { withApollo } from "react-apollo";
import { Auth } from "aws-amplify";
import { Button, Typography } from "@material-ui/core";
import { RocheCircularProgress } from "@one/react-kit";
import {
  loadUserInfo as loadUserInfoAction,
  loadLastFilter
} from "../user/redux/actions";
import {
  loadInstruments as loadInstrumentsAction,
  updateInstrumentFilter as updateInstrumentFilterAction,
  loadStepFormList as loadStepFormListAction,
  updateNextToken as updateNextTokenAction,
  updatePageTokenArray as updatePageTokenArrayAction,
  updateLoading as updateLoadingAction
} from "./redux/actions";
import styled from "styled-components";
import ErrorIcon from "@material-ui/icons/Error";
import ExitToAppIcon from "@material-ui/icons/ExitToApp";
import { signOut } from "../../utils/signout";
import {
  INSTRUMENT_REPOSITORY_ADMIN,
  GROUPS_TOKEN_PATH,
  DEFAULT_SITE_NAME,
  DEFAULT_SITE_TIMEZONE,
  ACCESS_TOKEN_PATH,
  SYNC_PROFILE_FIELDS,
  INSTRUMENT_REPO_VIEW_USER,
  emptyFilter,
  emptyTableColumn,
  emptyHideTableColumn
} from "../../constants";
import {
  LIST_SITES,
  USER_BY_EMAIL,
  LIST_COMBINED_RESULT
} from "../../gql/landingapi/queries";
import { getAllData } from "../../utils/helpers/fetching";
import {
  CREATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE,
  UPDATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE_PERSONAL_FIELDS
} from "../../gql/landingapi/mutations";
import Notify from "../notifications/Notify";
import omitDeep from "omit-deep-lodash";

export const FullScreenCentered = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  margin: 0;
  width: 100vw;
  height: 100vh;, ...syncFields
`;

class SiteError extends Error {
  constructor(message) {
    super(message);
    this.name = "SiteError";
  }
}

const checkRoleAndGetUserEmail = async (
  required_admin_group = INSTRUMENT_REPOSITORY_ADMIN,
  required_view_group = INSTRUMENT_REPO_VIEW_USER
) => {
  const currentAuthenticatedUser = await Auth.currentAuthenticatedUser();
  const access_groups = get(currentAuthenticatedUser, GROUPS_TOKEN_PATH);
  if (Array.isArray(access_groups)) {
    if (
      access_groups.includes(required_admin_group) ||
      access_groups.includes(required_view_group)
    ) {
      const syncFields = pick(
        get(currentAuthenticatedUser, ACCESS_TOKEN_PATH),
        Object.values(SYNC_PROFILE_FIELDS)
      );
      const email = get(currentAuthenticatedUser, ["attributes", "email"]);
      return { email, ...syncFields };
    } else {
      throw new Error("You do not have permission to access.");
    }
  } else {
    throw new Error("You do not have permission to access.");
  }
};

export const updateProfileFields = async ({
  client,
  email,
  user,
  ...syncFields
}) => {
  const syncKeys = Object.keys(SYNC_PROFILE_FIELDS);
  const profileObj = syncKeys.reduce(
    (acc, currKey) => ({
      ...acc,
      [currKey]: syncFields?.[SYNC_PROFILE_FIELDS?.[currKey]] ?? ""
    }),
    {}
  );
  if (!user) {
    return profileObj;
  }
  const shouldUpdate = !isEqual(pick(user, syncKeys), {
    ...profileObj,
    site: profileObj?.site || user.site
  });
  if (!shouldUpdate) return user;
  const {
    data: { updateDigitalLabInstrumentRepositoryUserProfile: updatedUser }
  } = await client.mutate({
    mutation: UPDATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE_PERSONAL_FIELDS,
    fetchPolicy: "no-cache",
    variables: {
      id: user?.id,
      email,
      lastFilter: user?.lastFilter,
      ...profileObj,
      site: profileObj?.site || user?.site
    }
  });
  return updatedUser;
};

export const getUserDetails = async ({
  client,
  email,
  updateInstrumentFilter,
  loadfilter,
  ...syncFields
}) => {
  const result = await client.query({
    query: USER_BY_EMAIL,
    fetchPolicy: "no-cache",
    variables: {
      email
    }
  });
  const user = get(result, "data.userByEmail.items[0]");
  if (!syncFields?.[SYNC_PROFILE_FIELDS.site] && !user?.site) {
    throw new SiteError(
      "You do not have site location assigned. Go to the Landing Page to configure this."
    );
  }
  if (!syncFields?.[SYNC_PROFILE_FIELDS.site]) {
    Notify({
      type: "warning",
      icon: "caution",
      appName: "",
      text: "Your location has been changed. Please check your settings at the Landing Page."
    });
  }

  if (user && user.lastFilter) {
    try {
      user.lastFilter = JSON.parse(user.lastFilter);
    } catch (error) {}

    if (user.lastFilter?.selectedFilters) {
      const fetchFitlers = user.lastFilter?.selectedFilters ?? emptyFilter;
      updateInstrumentFilter(fetchFitlers);
    }
  }
  const profileFieldsOrUpdatedUser = await updateProfileFields({
    client,
    user,
    email,
    ...syncFields
  });
  if (profileFieldsOrUpdatedUser?.id) {
    return { user: profileFieldsOrUpdatedUser };
  }
  const {
    data: { createDigitalLabInstrumentRepositoryUserProfile }
  } = await client.mutate({
    mutation: CREATE_DIGITAL_LAB_INSTRUMENT_USER_PROFILE,
    fetchPolicy: "no-cache",
    variables: {
      email,
      lastFilter: "",
      ...profileFieldsOrUpdatedUser
    }
  });

  return {
    user: createDigitalLabInstrumentRepositoryUserProfile
  };
};

export const getData = async ({
  client,
  query,
  dataPath = ["data", "listDigitalLabInstrumentRepositoryEntrys", "items"]
}) => {
  const data = await client.query({
    query,
    fetchPolicy: "no-cache"
  });

  return get(data, dataPath) ?? [];
};

const LoadInstrumentInfo = ({
  children,
  client,
  loadUserInfo,
  loadInstruments,
  loadStepFormList,
  updateInstrumentFilter,
  updateNextToken,
  updatePageTokenArray,
  loadfilter,
  updateLoading
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      setError(null);
      try {
        updateLoading(true);
        const { email, ...syncFields } = await checkRoleAndGetUserEmail();
        const { user } = await getUserDetails({
          client,
          email,
          updateInstrumentFilter,
          loadfilter,
          ...syncFields
        });

        let { items: sites } = await getAllData({
          client,
          query: LIST_SITES,
          dataPath: ["data", "listSites"]
        });
        sites =
          sites?.length === 0
            ? [
                {
                  siteName: DEFAULT_SITE_NAME,
                  siteTimezone: DEFAULT_SITE_TIMEZONE
                }
              ]
            : sites;
        if (user.lastFilter?.showColumns === undefined) {
          loadfilter({
            showColumns: emptyTableColumn,
            hideColumns: emptyHideTableColumn
          });
          user.lastFilter = {
            ...user.lastFilter,
            showColumns: emptyTableColumn,
            hideColumns: emptyHideTableColumn
          };
        }
        loadUserInfo({
          email,
          sites,
          ...user
        });
      } catch (err) {
        console.warn(err);
        setError(err);
      } finally {
        setLoading(false);
      }
      updateLoading(false);
    };
    loadData();
    const loadAllList = async () => {
      try {
        const allDropDownList = await client.query({
          query: LIST_COMBINED_RESULT,
          fetchPolicy: "no-cache",
          variables: {
            limit: 1000,
            nextToken: null,
            siteName: DEFAULT_SITE_NAME
          }
        });
        loadStepFormList(omitDeep(allDropDownList.data, "__typename"));
      } catch (err) {
        console.warn(err);
        setError(err);
      } finally {
        setLoading(false);
      }
    };
    loadAllList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    loadUserInfo,
    loadInstruments,
    loadStepFormList,
    client,
    updateInstrumentFilter,
    retry,
    loadfilter
  ]);
  if (loading)
    return (
      <FullScreenCentered data-testid="test">
        <RocheCircularProgress data-testid="loading" size={80} />
      </FullScreenCentered>
    );
  if (error !== null)
    return (
      <FullScreenCentered>
        <>
          <Typography variant="h6" data-testid="message-error" gutterBottom>
            {error?.message ? error?.message : "Unexpected error has occurred"}
          </Typography>
          {error?.name !== "SiteError" && (
            <Button
              variant="contained"
              onClick={() => setRetry(retry + 1)}
              color="secondary"
              startIcon={<ErrorIcon />}
              data-testid="try-again-button"
            >
              Try again
            </Button>
          )}
          <Button
            data-testid="signout-button"
            variant="contained"
            style={{ marginTop: ".7rem" }}
            onClick={() => signOut()}
            startIcon={<ExitToAppIcon />}
          >
            Sign out
          </Button>
        </>
      </FullScreenCentered>
    );
  return children;
};

export default compose(
  connect(null, {
    loadUserInfo: loadUserInfoAction,
    loadInstruments: loadInstrumentsAction,
    loadStepFormList: loadStepFormListAction,
    updateInstrumentFilter: updateInstrumentFilterAction,
    updateNextToken: updateNextTokenAction,
    updatePageTokenArray: updatePageTokenArrayAction,
    loadfilter: loadLastFilter,
    updateLoading: updateLoadingAction
  }),
  withApollo
)(LoadInstrumentInfo);
