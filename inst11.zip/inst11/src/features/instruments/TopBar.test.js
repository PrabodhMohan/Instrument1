import React from "react";
import { render } from "@testing-library/react";
import Search from "./Search";
import TopBar from "./TopBar";

jest.mock("./Search", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});

const FakeSearch = ({ "data-testid": dataTestId, label }) => (
  <div data-testid={dataTestId}>{label}</div>
);

test("should create", () => {
  Search.mockImplementation(FakeSearch);
  const { getByTestId } = render(
    <TopBar label="label" data-testid="search">
      <div data-testid="childern-div-test">children</div>
    </TopBar>
  );
  expect(getByTestId("search")).toBeDefined();
  expect(getByTestId("search").textContent).toBe("label");
  expect(getByTestId("childern-div-test")).toBeDefined();
  expect(getByTestId("childern-div-test").textContent).toBe("children");
});
