import { render, cleanup, fireEvent } from "../../test-utils";
import { emptyInstruments } from "./InstrumentsModal";
import { waitFor } from "@testing-library/dom";
import { useFormik } from "formik";
import AssaysDataForm from "./AssaysDataForm";

afterEach(cleanup);

const TestComponent = () => {
  const formik = useFormik({
    initialValues: {
      ...emptyInstruments
    }
  });

  return <AssaysDataForm formik={formik} />;
};

test.skip("should create", async () => {
  const { getByTestId } = render(<TestComponent />);

  await waitFor(() => expect(getByTestId("assays-data-form")).toBeDefined());
});

test.skip("should add test then edit then delete", async () => {
  const { getByTestId, getByLabelText, queryByTestId } = render(
    <TestComponent />
  );

  fireEvent.change(getByLabelText(/test name/i), {
    target: {
      value: "test"
    }
  });
  fireEvent.change(getByLabelText(/version/i), {
    target: {
      value: "test"
    }
  });

  fireEvent.click(getByTestId("assays-data-form-test-button-adding-new"));

  await waitFor(() => {
    expect(
      getByTestId("assays-data-form-test-list-info-row-name").textContent.trim()
    ).toBe("test");
    expect(
      getByTestId(
        "assays-data-form-test-list-info-row-version"
      ).textContent.trim()
    ).toBe("test");
  });

  fireEvent.click(getByTestId("assays-data-form-test-list-edit-iconbutton"));

  fireEvent.change(getByLabelText(/test name/i), {
    target: {
      value: "test edit"
    }
  });
  fireEvent.change(getByLabelText(/version/i), {
    target: {
      value: "test edit"
    }
  });

  fireEvent.click(getByTestId("assays-data-form-test-button-edit"));

  await waitFor(() => {
    expect(
      getByTestId("assays-data-form-test-list-info-row-name").textContent.trim()
    ).toBe("test edit");
    expect(
      getByTestId(
        "assays-data-form-test-list-info-row-version"
      ).textContent.trim()
    ).toBe("test edit");
  });

  fireEvent.click(getByTestId("assays-data-form-test-list-delete-iconbutton"));

  await waitFor(() => {
    expect(queryByTestId("assays-data-form-test-list-info-row-name")).toBe(
      null
    );
    expect(queryByTestId("assays-data-form-test-list-info-row-version")).toBe(
      null
    );
  });
});

test.skip("should add test then edit then cancel", async () => {
  const { getByTestId, getByLabelText } = render(<TestComponent />);

  fireEvent.change(getByLabelText(/test name/i), {
    target: {
      value: "test"
    }
  });
  fireEvent.change(getByLabelText(/version/i), {
    target: {
      value: "test"
    }
  });

  fireEvent.click(getByTestId("assays-data-form-test-button-adding-new"));

  await waitFor(() => {
    expect(
      getByTestId("assays-data-form-test-list-info-row-name").textContent.trim()
    ).toBe("test");
    expect(
      getByTestId(
        "assays-data-form-test-list-info-row-version"
      ).textContent.trim()
    ).toBe("test");
  });

  fireEvent.click(getByTestId("assays-data-form-test-list-edit-iconbutton"));

  fireEvent.change(getByLabelText(/test name/i), {
    target: {
      value: "test edit"
    }
  });
  fireEvent.change(getByLabelText(/version/i), {
    target: {
      value: "test edit"
    }
  });

  fireEvent.click(getByTestId("assays-data-form-test-button-clear"));

  await waitFor(() => {
    expect(
      getByTestId("assays-data-form-test-list-info-row-name").textContent.trim()
    ).toBe("test");
    expect(
      getByTestId(
        "assays-data-form-test-list-info-row-version"
      ).textContent.trim()
    ).toBe("test");
  });
});

test.skip("should clear inputs", async () => {
  const { getByTestId, getByLabelText } = render(<TestComponent />);

  fireEvent.change(getByLabelText(/test name/i), {
    target: {
      value: "test"
    }
  });
  fireEvent.change(getByLabelText(/version/i), {
    target: {
      value: "test"
    }
  });

  await waitFor(() => {
    expect(getByLabelText(/test name/i).value.trim()).toBe("test");
    expect(getByLabelText(/version/i).value.trim()).toBe("test");
  });

  fireEvent.click(getByTestId("assays-data-form-test-name-input-clear-button"));
  fireEvent.click(
    getByTestId("assays-data-form-test-version-input-clear-button")
  );

  await waitFor(() => {
    expect(getByLabelText(/test name/i).value.trim()).toBe("");
    expect(getByLabelText(/version/i).value.trim()).toBe("");
  });
});

test.skip("should validate", async () => {
  const { getByTestId } = render(<TestComponent />);

  fireEvent.click(getByTestId("assays-data-form-test-button-adding-new"));

  await waitFor(() => {
    expect(
      getByTestId(
        "assays-data-form-test-version-input-helper-text"
      ).textContent.trim()
    ).toBe("Enter your test version");
    expect(
      getByTestId(
        "assays-data-form-test-name-input-helper-text"
      ).textContent.trim()
    ).toBe("Enter your test name");
  });
});
