import React, { useState } from "react";
import Grid from "@material-ui/core/Grid";
import InstrumentsTable from "./InstrumentsTable";
import styled from "styled-components";
import AddInstrumentContainer from "./addEditEquipment/AddEditEquipmentContainer";
import { Formik } from "formik";
import {
  getValidationSchema,
  getInitialValue
} from "./instrument-form/validation-schemas-step";
const MainContainer = styled.div`
  margin: 1rem;
  margin-top: 0.25rem;
`;

const InstrumentsMainPage = () => {
  const [addInstrumentContainer, setaddInstrumentContainer] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [activeStep, setActiveStep] = useState(0);

  const addInstrumentClicked = (state, isEditMode, item) => {
    setaddInstrumentContainer(state);
    setIsEditMode(isEditMode);
    if (item) {
      setSelectedItem(item);
    }
  };
  const cancelStep = () => {
    setActiveStep(0);
    setaddInstrumentContainer(false);
  };
  
  return (
    <MainContainer>
      <Grid container spacing={3}>
        <Grid item md={12}>
          {!addInstrumentContainer ? (
            <InstrumentsTable addInstrumentClicked={addInstrumentClicked}/>
          ) : (
            <>
              <Formik
                validationSchema={getValidationSchema(activeStep)}
                initialValues={getInitialValue(activeStep)}
                isInitialValid={true}
                validateOnMount={true}
              >
                <AddInstrumentContainer
                  cancelStep={cancelStep}
                  isEditMode={isEditMode}
                  setIsEditMode={setIsEditMode}
                  activeStep={activeStep}
                  setActiveStep={setActiveStep}
                  selectedItem={selectedItem}
                  setSelectedItem={setSelectedItem}
                ></AddInstrumentContainer>
              </Formik>
            </>
          )}
        </Grid>
      </Grid>
    </MainContainer>
  );
};

export default InstrumentsMainPage;
