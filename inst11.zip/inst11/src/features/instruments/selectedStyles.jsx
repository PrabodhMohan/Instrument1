export const selectedStyles = {
  background: "#E0ECF9",
  color: "#0066CC",
  fontWeight: "normal",
  textTransform: "none",
  fontSize: 16,
  lineHeight: "19px",
  paddingTop: 13,
  paddingBottom: 13,
  border: "1px solid #D3D3D3",
  "&:hover": {
    background: "#BFD9F2",
    borderColor: "#D3D3D3"
  }
};
