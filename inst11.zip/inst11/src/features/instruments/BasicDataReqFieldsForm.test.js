import { render, cleanup, fireEvent } from "../../test-utils";
import { emptyInstruments } from "./InstrumentsModal";
import { waitFor } from "@testing-library/dom";
import { useFormik } from "formik";
import BasicDataReqFieldsForm from "./BasicDataReqFieldsForm";
import * as yup from "yup";
import { DEFAULT_SITE_NAME, DEFAULT_SITE_TIMEZONE } from "../../constants";

afterEach(cleanup);

const testValidationSchema = yup.object({
  serialNumber: yup
    .string("Enter serial number")
    .required("Serial number is required"),
  materialNumber: yup
    .string("Enter material number")
    .required("Material number is required"),
  siteTimezone: yup.string("Enter timezone").required("Timezone is required"),
  siteName: yup.string("Enter site").required("Site is required"),
  instrumentRUDI: yup
    .string("Enter RUDI number")
    .required("RUDI number is required"),
  buildingLocation: yup.object({
    value: yup.string("Enter building location"),
    isSynchronized: yup.bool()
  }),
  instrumentGTIN: yup.object({
    value: yup
      .string("Enter instrument GTIN")
      .required("instrument GTIN is required"),
    isSynchronized: yup.bool()
  }),
  instrumentName: yup.object({
    value: yup
      .string("Enter instrument name")
      .required("Instrument name is required"),
    isSynchronized: yup.bool()
  }),
  instrumentType: yup.object({
    value: yup
      .string("Enter instrument type")
      .required("Instrument type is required"),
    isSynchronized: yup.bool()
  }),
  isBookable: yup.bool(),
  isVisualized: yup.bool(),
  floorAndRoomLocation: yup.object({
    value: yup.string("Enter instrument location"),
    isSynchronized: yup.bool()
  }),
  responsiblePerson: yup.object({
    value: yup.string("Enter responsible person"),
    isSynchronized: yup.bool()
  }),
  softwareVersion: yup.string("Enter software version"),

  configurationBaseline: yup.string("Enter configuration baseline"),
  systemStatus: yup.object({
    value: yup.string("Enter system status"),
    isSynchronized: yup.bool()
  }),
  instrumentGxPStatus: yup.object({
    value: yup.string("Enter ABC indicator"),
    isSynchronized: yup.bool()
  }),
  belongingToGroup: yup.string("Enter belonging to group"),
  dateOfLastMaintanance: yup.object({
    value: yup.date().typeError("invalid date").nullable(),
    isSynchronized: yup.bool()
  }),
  dateOfNextMaintanance: yup.object({
    value: yup.date().typeError("invalid date").nullable(),
    isSynchronized: yup.bool()
  }),
  installedTests: yup.array(),
  qualificationDocuments: yup.object({
    value: yup.array(),
    isSynchronized: yup.bool()
  })
});

const TestComponent = ({ submit }) => {
  const formik = useFormik({
    initialValues: {
      ...emptyInstruments
    },
    validationSchema: testValidationSchema,
    onSubmit: (values) => {
      if (submit) {
        submit(values);
      }
    }
  });

  return (
    <form data-testid="test-form" onSubmit={formik.handleSubmit}>
      <BasicDataReqFieldsForm formik={formik} />
    </form>
  );
};

test("should create", async () => {
  const { getByTestId } = render(<TestComponent />);

  await waitFor(() => expect(getByTestId("basic-data-req-form")).toBeDefined());
});
test.skip("should update form, clear all inputs and display error messages", async () => {
  const { getByTestId, getByLabelText } = render(<TestComponent />, {
    initialState: {
      user: {
        sites: [
          {
            siteName: "siteName",
            siteTimezone: "siteTimezone"
          },
          {
            siteName: "siteName 2",
            siteTimezone: "siteTimezone 2"
          }
        ]
      }
    }
  });

  fireEvent.change(getByLabelText(/material number/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/serial number/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/instrument name/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/instrument type/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/gtin number/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/rudi number/i), {
    target: { value: "test" }
  });

  const siteNameInput = getByTestId(
    "basic-data-req-fields-instrument-siteName"
  ).querySelector("input");
  fireEvent.change(siteNameInput, {
    target: { value: "siteName 2" }
  });

  await waitFor(() => {
    expect(getByLabelText(/material number/i)).toHaveValue("test");
    expect(getByLabelText(/serial number/i)).toHaveValue("test");
    expect(getByLabelText(/instrument name/i)).toHaveValue("test");
    expect(getByLabelText(/instrument type/i)).toHaveValue("test");
    expect(getByLabelText(/gtin number/i)).toHaveValue("test");
    expect(getByLabelText(/rudi number/i)).toHaveValue("test");
    expect(
      getByTestId("basic-data-req-fields-instrument-siteName").querySelector(
        "input"
      )
    ).toHaveValue("siteName 2");
  });

  fireEvent.click(
    getByTestId(
      "basic-data-req-fields-instrument-clear-button-material-number-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-req-fields-instrument-clear-button-serial-number-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-req-fields-instrument-clear-button-instrument-name-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-req-fields-instrument-clear-button-instrument-type-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-req-fields-instrument-clear-button-instrument-GTIN-input"
    )
  );
  fireEvent.click(
    getByTestId(
      "basic-data-req-fields-instrument-clear-button-instrument-RUDI-input"
    )
  );

  fireEvent.submit(getByTestId("test-form"));

  await waitFor(() => {
    expect(getByLabelText(/material number/i)).toHaveValue("");
    expect(getByLabelText(/serial number/i)).toHaveValue("");
    expect(getByLabelText(/instrument name/i)).toHaveValue("");
    expect(getByLabelText(/instrument type/i)).toHaveValue("");
    expect(getByLabelText(/gtin number/i)).toHaveValue("");
    expect(getByLabelText(/rudi number/i)).toHaveValue("");

    expect(
      getByTestId(
        "basic-data-req-fields-instrument-helper-text-material-number-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-req-fields-instrument-helper-text-serial-number-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-req-fields-instrument-helper-text-instrument-name-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-req-fields-instrument-helper-text-instrument-type-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-req-fields-instrument-helper-text-instrument-GTIN-input"
      )
    ).toHaveTextContent(/required/i);
    expect(
      getByTestId(
        "basic-data-req-fields-instrument-helper-text-instrument-RUDI-input"
      )
    ).toHaveTextContent(/required/i);
  });
});

test.skip("should update form with checkboxes and send", async () => {
  const submit = jest.fn();
  const { getByTestId, getByLabelText } = render(
    <TestComponent submit={submit} />,
    {
      initialState: {
        user: {
          sites: [
            {
              siteName: "siteName",
              siteTimezone: "siteTimezone"
            },
            {
              siteName: "siteName 2",
              siteTimezone: "siteTimezone 2"
            }
          ]
        }
      }
    }
  );

  fireEvent.change(getByLabelText(/material number/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/serial number/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/instrument name/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/instrument type/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/gtin number/i), {
    target: { value: "test" }
  });
  fireEvent.change(getByLabelText(/rudi number/i), {
    target: { value: "test" }
  });

  fireEvent.click(
    getByTestId(
      "basic-data-req-fields-instrument-instrument-name-checkbox"
    ).querySelector("input")
  );
  fireEvent.click(
    getByTestId(
      "basic-data-req-fields-instrument-instrument-type-checkbox"
    ).querySelector("input")
  );
  fireEvent.click(
    getByTestId(
      "basic-data-req-fields-instrument-instrument-GTIN-checkbox"
    ).querySelector("input")
  );

  const siteNameInput = getByTestId(
    "basic-data-req-fields-instrument-siteName"
  ).querySelector("input");
  fireEvent.change(siteNameInput, {
    target: { value: "siteName 2" }
  });

  await waitFor(() => {
    expect(getByLabelText(/material number/i)).toHaveValue("test");
    expect(getByLabelText(/serial number/i)).toHaveValue("test");
    expect(getByLabelText(/instrument name/i)).toHaveValue("test");
    expect(getByLabelText(/instrument type/i)).toHaveValue("test");
    expect(getByLabelText(/gtin number/i)).toHaveValue("test");
    expect(getByLabelText(/rudi number/i)).toHaveValue("test");

    expect(
      getByTestId(
        "basic-data-req-fields-instrument-instrument-name-checkbox-label"
      )
    ).toHaveTextContent(/will update/i);
    expect(
      getByTestId(
        "basic-data-req-fields-instrument-instrument-type-checkbox-label"
      )
    ).toHaveTextContent(/will update/i);
    expect(
      getByTestId(
        "basic-data-req-fields-instrument-instrument-GTIN-checkbox-label"
      )
    ).toHaveTextContent(/will update/i);

    expect(
      getByTestId("basic-data-req-fields-instrument-siteName").querySelector(
        "input"
      )
    ).toHaveValue("siteName 2");
  });

  fireEvent.submit(getByTestId("test-form"));

  await waitFor(() =>
    expect(submit).toHaveBeenCalledWith(
      expect.objectContaining({
        materialNumber: "test",
        serialNumber: "test",
        siteName: "siteName 2",
        siteTimezone: "siteTimezone 2",
        instrumentName: expect.objectContaining({
          value: "test",
          isSynchronized: true
        }),
        instrumentType: expect.objectContaining({
          value: "test",
          isSynchronized: true
        }),
        instrumentGTIN: expect.objectContaining({
          value: "test",
          isSynchronized: true
        }),
        instrumentRUDI: "test"
      })
    )
  );
});
