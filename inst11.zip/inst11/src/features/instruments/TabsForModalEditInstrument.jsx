import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Paper, Tab, Tabs } from "@material-ui/core";

const useStyles = makeStyles({
  root: {
    flexGrow: 1
  },
  tab: {
    textTransform: "none",
    fontStyle: "normal",
    fontWeight: "500",
    fontSize: "1rem",
    lineHeight: "22px",
    color: "#737373"
  }
});

const TabsForModalEditInstrument = ({ choosenTab, setChoosenTab }) => {
  const classes = useStyles();
  const handleChange = (event, newValue) => {
    setChoosenTab(newValue);
  };
  return (
    <Paper className={classes.root}>
      <Tabs
        variant="fullWidth"
        value={choosenTab}
        onChange={handleChange}
        indicatorColor="primary"
        textColor="primary"
        centered
        data-testid="tabs-for-modal-edit-instrument"
      >
        <Tab
          classes={{
            root: classes.tab
          }}
          value="basicData"
          label="Basic data"
          data-testid="tabs-for-modal-edit-tab-basic-data"
        />
        <Tab
          classes={{
            root: classes.tab
          }}
          label="Installed tests"
          value="assays"
          data-testid="tabs-for-modal-edit-tab-installed-tests"
        />
        <Tab
          classes={{
            root: classes.tab
          }}
          label="Documents"
          value="documents"
          data-testid="tabs-for-modal-edit-tab-documents"
        />
      </Tabs>
    </Paper>
  );
};
export default TabsForModalEditInstrument;
