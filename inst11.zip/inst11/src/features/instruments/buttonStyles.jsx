export const buttonStyles = {
  background: "#FAFAFA",
  color: "#737373",
  fontWeight: "normal",
  textTransform: "none",
  fontSize: 16,
  lineHeight: "19px",
  paddingTop: 13,
  paddingBottom: 13,
  border: "1px solid #D3D3D3",
  "&:hover": {
    background: "#EFEFEF",
    borderColor: "#D3D3D3"
  }
};
