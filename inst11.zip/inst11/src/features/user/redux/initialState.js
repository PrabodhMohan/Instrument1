const initialState = {
  email: "",
  sites: [],
  lastFilter: {}
};

export default initialState;
