import * as types from "./actionTypes";
import initialState from "./initialState";

export default function reducer(
  state = initialState,
  action = { type: "", payload: {} }
) {
  if (action?.type === types.LOAD_USER_INFO) {
    return { ...state, ...action?.payload };
  }
  if (action?.type === types.LOAD_LAST_FILTER) {
    return {
      ...state,
      lastFilter: {
        ...action?.payload
      }
    };
  }
  return state;
}
