import * as types from "./actionTypes";

export const loadUserInfo = (userInfo) => ({
  type: types.LOAD_USER_INFO,
  payload: userInfo
});

export const loadLastFilter = (lastFilter) => ({
  type: types.LOAD_LAST_FILTER,
  payload: lastFilter
});
