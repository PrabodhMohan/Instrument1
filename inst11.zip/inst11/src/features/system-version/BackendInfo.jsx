import React from "react";
import { LIST_BACKEND_HEALTH_CHECKS } from "../../gql/landingapi/queries";
import { CircularProgress } from "@material-ui/core";
import { Query } from "react-apollo";
import DescriptionCard from "./DescriptionCard";
import { InfoWithCallback } from "../../components/shared/InfoWithCallback";

const BackendInfo = () => {
  return (
    <Query query={LIST_BACKEND_HEALTH_CHECKS} fetchPolicy="cache-and-network">
      {({ loading, error, data, refetch }) => {
        if (loading)
          return (
            <CircularProgress size={30} color="primary" data-testid="loading" />
          );
        if (error !== undefined) return <InfoWithCallback callback={refetch} />;
        const items = data?.listBackendHealthChecks?.items;
        if (!Array.isArray(items))
          return <p data-testid="invalidData">Invalid data</p>;
        if (items.length === 0) return <p data-testid="noData">No data</p>;

        return (
          <>
            {items?.map((item, id) =>
              item ? (
                <DescriptionCard
                  title={`Backend ${id + 1}`}
                  key={item?.id}
                  {...item}
                />
              ) : null
            )}
          </>
        );
      }}
    </Query>
  );
};

export default BackendInfo;
