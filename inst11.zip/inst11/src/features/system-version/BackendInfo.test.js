import React from "react";
import { render, cleanup, waitFor } from "../../test-utils";
import DescriptionCard from "./DescriptionCard";
import BackendInfo from "./BackendInfo";
import { LIST_BACKEND_HEALTH_CHECKS } from "../../gql/landingapi/queries";
import { InfoWithCallback } from "../../components/shared/InfoWithCallback";

jest.mock("./DescriptionCard", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});

jest.mock("../../components/shared/InfoWithCallback");

afterEach(cleanup);

const backends = [
  {
    ciJobId: "123",
    commitHash: "1313",
    createdAt: "2021-07-26T13:11:07.007Z",
    id: "1",
    moduleName: "app backend",
    moduleVersion: "1.0.0",
    updatedAt: "2021-07-26T13:11:07.007Z",
    __typename: "BackendHealthCheck"
  },
  {
    ciJobId: "123",
    commitHash: "1313",
    createdAt: "2021-07-26T13:11:07.007Z",
    id: "2",
    moduleName: "app backend 2",
    moduleVersion: "1.0.0",
    updatedAt: "2021-07-26T13:11:07.007Z",
    __typename: "BackendHealthCheck"
  }
];

beforeEach(() => {
  DescriptionCard.mockImplementation(({ id, moduleName }) => (
    <div data-testid={`card-${id}`}>{moduleName}</div>
  ));
});
describe("BackendInfo", () => {
  test("should create component and call api", async () => {
    const { getByTestId, container } = render(<BackendInfo />, {
      mocksForApollo: [
        {
          request: {
            query: LIST_BACKEND_HEALTH_CHECKS,
            variables: {}
          },
          result: {
            data: {
              listBackendHealthChecks: {
                items: backends
              }
            }
          }
        }
      ]
    });
    expect(getByTestId("loading")).toBeDefined();
    await waitFor(() => {
      expect(container.querySelectorAll("[data-testid^=card-]").length).toEqual(
        2
      );
    });
  });

  test("should display item only with data", async () => {
    const { getByTestId, container } = render(<BackendInfo />, {
      mocksForApollo: [
        {
          request: {
            query: LIST_BACKEND_HEALTH_CHECKS,
            variables: {}
          },
          result: {
            data: {
              listBackendHealthChecks: {
                items: [backends[0], null]
              }
            }
          }
        }
      ]
    });
    expect(getByTestId("loading")).toBeDefined();
    await waitFor(() => {
      expect(container.querySelectorAll("[data-testid^=card-]").length).toEqual(
        1
      );
    });
  });

  test("should create component and call api and display no data info", async () => {
    const { getByTestId } = render(<BackendInfo />, {
      mocksForApollo: [
        {
          request: {
            query: LIST_BACKEND_HEALTH_CHECKS,
            variables: {}
          },
          result: {
            data: {
              listBackendHealthChecks: {
                items: []
              }
            }
          }
        }
      ]
    });
    expect(getByTestId("loading")).toBeDefined();
    await waitFor(() => {
      expect(getByTestId("noData")).toBeDefined();
    });
  });

  test("should create component and call api and display invalid data info", async () => {
    const { getByTestId } = render(<BackendInfo />, {
      mocksForApollo: [
        {
          request: {
            query: LIST_BACKEND_HEALTH_CHECKS,
            variables: {}
          },
          result: {
            data: {
              listBackendHealthChecks: {
                items: null
              }
            }
          }
        }
      ]
    });
    expect(getByTestId("loading")).toBeDefined();
    await waitFor(() => {
      expect(getByTestId("invalidData")).toBeDefined();
    });
  });

  test("should create component and call api and display error compoennt", async () => {
    InfoWithCallback.mockImplementation(() => (
      <div data-testid="error">Error</div>
    ));
    const { getByTestId } = render(<BackendInfo />, {
      mocksForApollo: [
        {
          request: {
            query: LIST_BACKEND_HEALTH_CHECKS,
            variables: {}
          },
          result: {
            data: {
              listBackendHealthChecks: {
                items: null
              }
            },
            errors: [
              {
                message: "Error"
              }
            ]
          }
        }
      ]
    });
    expect(getByTestId("loading")).toBeDefined();
    await waitFor(() => {
      expect(getByTestId("error")).toBeDefined();
    });
  });
});
