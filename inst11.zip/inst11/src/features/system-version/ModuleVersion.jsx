import React from "react";
import styled from "styled-components";
import Button from "@material-ui/core/Button";
import { useHistory } from "react-router";
import DescriptionCard from "./DescriptionCard";
import { ArrowBack } from "@material-ui/icons";
import BackendInfo from "./BackendInfo";
import useAuthenticatedUser from "../../utils/hooks/useAuthenticatedUser";

export const ModuleVersionStyled = styled.div`
  width: 100%;
  font-family: "Roboto", sans-serif;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: #888;
  padding: 10px 0;
  overflow-y: auto;
`;

export const InfoHeaderStyled = styled.div`
  display: flex;
  padding: 15px 0;
  justify-content: flex-start;
  width: 80%;
  max-width: 800px;
`;

const ModuleVersion = ({ redirectPath = "/" }) => {
  const history = useHistory();
  const user = useAuthenticatedUser();
  return (
    <ModuleVersionStyled data-testid="info-page">
      <InfoHeaderStyled>
        {user && (
          <Button
            data-testid="info-page-action-button-go-back"
            variant="outlined"
            color="primary"
            startIcon={<ArrowBack />}
            onClick={() => {
              history?.goBack();
            }}
          >
            Go back
          </Button>
        )}
      </InfoHeaderStyled>
      <DescriptionCard title="Frontend information" />
      {user && <BackendInfo />}
      <Button
        data-testid="info-page-action-button-module-version"
        variant="contained"
        color="primary"
        onClick={() => {
          history?.replace(redirectPath);
        }}
      >
        Go home
      </Button>
    </ModuleVersionStyled>
  );
};

export default ModuleVersion;
