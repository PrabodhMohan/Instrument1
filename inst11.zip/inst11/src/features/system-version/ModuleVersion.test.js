import React from "react";
import { render, cleanup, fireEvent } from "@testing-library/react";
import ModuleVersion from "./ModuleVersion";
import useAuthenticatedUser from "../../utils/hooks/useAuthenticatedUser";
import { useHistory } from "react-router";
import DescriptionCard from "./DescriptionCard";
import BackendInfo from "./BackendInfo";

jest.mock("react-router");
jest.mock("../../utils/hooks/useAuthenticatedUser", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});
jest.mock("./DescriptionCard", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});
jest.mock("./BackendInfo", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});

afterEach(cleanup);

beforeEach(() => {
  DescriptionCard.mockImplementation(({ id, moduleName }) => (
    <div data-testid={`card-${id}`}>{moduleName}</div>
  ));
  BackendInfo.mockImplementation(() => (
    <div data-testid={`backendInfo`}>BackendInfo</div>
  ));
});
describe("ModuleVersion", () => {
  test("should create component", () => {
    useAuthenticatedUser.mockReturnValue({ id: 1 });
    const { getByTestId } = render(<ModuleVersion />);
    const moduleVersionPage = getByTestId("info-page");
    expect(moduleVersionPage).toBeDefined();
  });
  test("should go to home with default path and goBack if user is logged in", () => {
    const replace = jest.fn();
    const goBack = jest.fn();

    useHistory.mockReturnValue({
      replace,
      goBack
    });
    useAuthenticatedUser.mockReturnValue({ id: 1 });
    const { getByTestId } = render(<ModuleVersion />);
    const redirectButton = getByTestId(
      "info-page-action-button-module-version"
    );
    fireEvent.click(redirectButton);
    expect(replace).toHaveBeenCalled();
    fireEvent.click(getByTestId("info-page-action-button-go-back"));
    expect(goBack).toHaveBeenCalled();
    expect(getByTestId("backendInfo")).toBeDefined();
  });
  test("should go to home with not provided path", () => {
    const replace = jest.fn();
    useHistory.mockReturnValue({
      replace
    });
    const { getByTestId } = render(<ModuleVersion redirectPath={"/test"} />);
    const redirectButton = getByTestId(
      "info-page-action-button-module-version"
    );
    fireEvent.click(redirectButton);
    expect(replace).toHaveBeenCalledWith("/test");
  });
});
