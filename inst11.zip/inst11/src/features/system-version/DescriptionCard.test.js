import React from "react";
import { render, cleanup } from "@testing-library/react";
import DescriptionCard from "./DescriptionCard";
import { useMobile } from "../../utils/hooks/useMobile";
import { useHistory } from "react-router";

jest.mock("react-router");
jest.mock("../../utils/hooks/useMobile");
afterEach(cleanup);

process.env.REACT_APP_MODULE_VERSION = "2.1.2";
process.env.REACT_APP_MODULE_NAME = "APP 1 NAME";
process.env.REACT_APP_CI_JOB_ID = "1025448";
process.env.REACT_APP_COMMIT_HASH = "e7ae380e4698cea7d9e3b9e404866d14c7f1f9ad";
process.env.REACT_APP_UPDATED_AT = "2021-07-26T07:07:46Z";

describe("DescriptionCard", () => {
  test("should create for not mobile", () => {
    const { getByTestId } = render(<DescriptionCard />);
    const descriptionCardPage = getByTestId("info-page-module-version-text");
    expect(descriptionCardPage).toBeDefined();
  });
  test("should create for mobile", () => {
    useMobile.mockReturnValue(true);
    const { container } = render(<DescriptionCard />);
    expect(
      window
        .getComputedStyle(
          container.querySelector("[data-testid='info-page-container']")
        )
        .getPropertyValue("font-size")
    ).toBe("13px");
  });
  test("should go to home with default path", () => {
    const replace = jest.fn();
    useHistory.mockReturnValue({
      replace
    });
    const { getByTestId } = render(<DescriptionCard />);
    expect(getByTestId("info-page-module-version-text").textContent).toEqual(
      "2.1.2"
    );
    expect(getByTestId("info-page-app-name-text").textContent).toEqual(
      "APP 1 NAME"
    );
    expect(getByTestId("info-page-ci-job-text").textContent).toEqual("1025448");
    expect(getByTestId("info-page-commit-hash-text").textContent).toEqual(
      "e7ae380e4698cea7d9e3b9e404866d14c7f1f9ad"
    );
    expect(getByTestId("info-page-update-at-text").textContent).not.toEqual(
      "UPDATED AT"
    );
  });
  test("should go to home with not provided path", () => {
    const replace = jest.fn();
    useHistory.mockReturnValue({
      replace
    });
    const { getByTestId } = render(
      <DescriptionCard
        redirectPath={"/test"}
        moduleVersion={null}
        moduleName={null}
        ciJobId={null}
        commitHash={null}
        updatedAt={null}
      />
    );
    expect(getByTestId("info-page-module-version-text").textContent).toEqual(
      "MODULE VERSION"
    );
    expect(getByTestId("info-page-app-name-text").textContent).toEqual(
      "APP NAME"
    );
    expect(getByTestId("info-page-ci-job-text").textContent).toEqual(
      "CI ID JOB"
    );
    expect(getByTestId("info-page-commit-hash-text").textContent).toEqual(
      "COMMIT HASH"
    );
    expect(getByTestId("info-page-update-at-text").textContent).toEqual(
      "UPDATED AT"
    );
  });
});
