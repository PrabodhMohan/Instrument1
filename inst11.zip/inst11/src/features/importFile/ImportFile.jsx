import React from "react";
import FileContextWapper from "./FileContext";
import ImportComponent from "./components/ImportComponent";
import UploadInstruments from "./UploadInstruments";

export const ImportFile = () => {
  return (
    <FileContextWapper>
      <ImportComponent />
      <UploadInstruments />
    </FileContextWapper>
  );
};
