import React, { useContext } from "react";
import { render, cleanup, fireEvent } from "../../test-utils";
import FileContextWrapper, { FileContext } from "./FileContext";
import { requiredInstrumentProperties } from "./utils/structure";

afterEach(cleanup);

const initalStore = {
  instruments: {
    instruments: [
      {
        softwareVersion: "oiiio",
        belongingToGroup: "tftf",
        buildingLocation: {
          isSynchronized: true,
          value: "90",
          __typename: "StringAttribute"
        },
        configurationBaseline: "oioioi",
        dateOfLastMaintanance: {
          isSynchronized: true,
          value: "2021-06-20",
          __typename: "AWSDateAttribute"
        },
        dateOfNextMaintanance: {
          isSynchronized: true,
          value: "2021-06-16",
          __typename: "AWSDateAttribute"
        },
        floorAndRoomLocation: {
          isSynchronized: true,
          value: "70.70-3",
          __typename: "StringAttribute"
        },
        installedTests: [],
        instrumentGTIN: {
          isSynchronized: false,
          value: "gtt",
          __typename: "StringAttribute"
        },
        instrumentGxPStatus: {
          isSynchronized: true,
          value: "tffttf",
          __typename: "StringAttribute"
        },
        instrumentName: {
          isSynchronized: true,
          value: "ujujuju",
          __typename: "StringAttribute"
        },
        instrumentRUDI: "jujjuju",
        instrumentType: {
          isSynchronized: false,
          value: "jujuju",
          __typename: "StringAttribute"
        },
        isBookable: true,
        isVisualized: true,
        materialNumber: "ggggguuu",
        qualificationDocuments: {
          isSynchronized: false,
          value: [],
          __typename: "QualificationDocumentAttribute"
        },
        responsiblePerson: {
          isSynchronized: false,
          value: "ioi",
          __typename: "StringAttribute"
        },
        serialNumber: "jujujuju",
        systemStatus: {
          isSynchronized: true,
          value: "yggygyy",
          __typename: "StringAttribute"
        },
        __typename: "DigitalLabInstrumentRepositoryEntry"
      },
      {
        softwareVersion: "v3.0.2",
        belongingToGroup: "Example group2",
        buildingLocation: {
          isSynchronized: false,
          value: "R06",
          __typename: "StringAttribute"
        },
        configurationBaseline: "BA329523",
        dateOfLastMaintanance: null,
        dateOfNextMaintanance: null,
        floorAndRoomLocation: {
          isSynchronized: false,
          value: "05.43-03",
          __typename: "StringAttribute"
        },
        installedTests: null,
        instrumentGTIN: {
          isSynchronized: false,
          value: "gtn1",
          __typename: "StringAttribute"
        },
        instrumentGxPStatus: {
          isSynchronized: false,
          value: "Example string2",
          __typename: "StringAttribute"
        },
        instrumentName: {
          isSynchronized: true,
          value: "STING.5",
          __typename: "StringAttribute"
        },
        instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342",
        instrumentType: {
          isSynchronized: false,
          value: "Cobas 6400",
          __typename: "StringAttribute"
        },
        isBookable: false,
        isVisualized: false,
        materialNumber: "542568153454",
        qualificationDocuments: {
          isSynchronized: false,
          value: [],
          __typename: "QualificationDocumentAttribute"
        },
        responsiblePerson: {
          isSynchronized: false,
          value: "Kathryn Murphy",
          __typename: "StringAttribute"
        },
        serialNumber: "SD9212969",
        systemStatus: {
          isSynchronized: false,
          value: "Example status2",
          __typename: "StringAttribute"
        },
        __typename: "DigitalLabInstrumentRepositoryEntry"
      },
      {
        softwareVersion: "",
        belongingToGroup: "",
        buildingLocation: {
          isSynchronized: false,
          value: "R06.",
          __typename: "StringAttribute"
        },
        configurationBaseline: "",
        dateOfLastMaintanance: {
          isSynchronized: false,
          value: "2021-05-31",
          __typename: "AWSDateAttribute"
        },
        dateOfNextMaintanance: {
          isSynchronized: false,
          value: "2021-05-25",
          __typename: "AWSDateAttribute"
        },
        floorAndRoomLocation: {
          isSynchronized: false,
          value: "60.07-70",
          __typename: "StringAttribute"
        }
      }
    ]
  }
};

const importData = [
  {
    instrumentGTIN: {
      isSynchronized: false,
      value: "gtt"
    },
    instrumentRUDI: "jujjuju",
    instrumentName: {
      isSynchronized: true,
      value: "ujujuju"
    },
    instrumentType: {
      isSynchronized: false,
      value: "jujuju"
    },
    isBookable: true,
    materialNumber: "ggggguuu",
    serialNumber: "jujujuju",
    siteName: "site1",
    siteTimezone: "sitetimezone"
  },
  {
    instrumentGTIN: {
      isSynchronized: false,
      value: "gtn1"
    },
    instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342",
    instrumentName: {
      isSynchronized: true,
      value: "STING.5"
    },
    instrumentType: {
      isSynchronized: false,
      value: "Cobas 6400"
    },
    isBookable: false,
    materialNumber: "542568153454",
    serialNumber: "SD9212969",
    siteName: "site1",
    siteTimezone: "sitetimezone"
  }
];

const ImportData = () => {
  const { setImportData, onAllPickedProps, file, setFile } =
    useContext(FileContext);
  return (
    <>
      <span data-testid="file">{file ? "file" : "empty"}</span>
      <button
        data-testid="setImportData"
        onClick={() => {
          setFile("file");
          setImportData(importData);
        }}
      />
      <button
        data-testid="setNull"
        onClick={() => {
          setFile(null);
          onAllPickedProps();
        }}
      />
    </>
  );
};

const ExistingRecordsIds = () => {
  const { existingRecordsIds } = useContext(FileContext);
  return (
    <div data-testid="existingRecordsIds">
      {JSON.stringify(existingRecordsIds)}
    </div>
  );
};

const SkipExisingRecords = () => {
  const { skipExisingRecords, onSkipExisingRecords } = useContext(FileContext);
  return (
    <button data-testid="skipExisingRecords" onClick={onSkipExisingRecords}>
      {skipExisingRecords ? "Skip" : "All"}
    </button>
  );
};

const PickedProps = () => {
  const {
    pickedProps,
    onPickedProps,
    isPropChecked,
    isAllPropChecked,
    onAllPickedProps
  } = useContext(FileContext);
  return (
    <div>
      <span data-testid="requiredProps">{pickedProps?.length}</span>
      <button
        data-testid="pickedProps"
        onClick={() => onPickedProps({ target: { value: "instrumentRUDI" } })}
      >
        {JSON.stringify(pickedProps)}
      </button>
      <span data-testid="isPropChecked">
        {isPropChecked("instrumentRUDI") ? "checked" : "unchecked"}
      </span>
      <span data-testid="isAllPropChecked">
        {isAllPropChecked() ? "all checked" : "not all checked"}
      </span>
      <button data-testid="onAllPropChecked" onClick={() => onAllPickedProps()}>
        All check
      </button>
    </div>
  );
};

describe("FileContext tests", () => {
  test("should render FileContext successfully", async () => {
    const { getByTestId } = render(
      <FileContextWrapper>
        <ImportData />
        <ExistingRecordsIds />
        <SkipExisingRecords />
        <PickedProps />
      </FileContextWrapper>,
      {
        initialState: initalStore
      }
    );
    fireEvent.click(getByTestId("setImportData"));

    expect(getByTestId("existingRecordsIds").textContent).toContain(
      JSON.stringify([
        {
          materialNumber: "ggggguuu",
          serialNumber: "jujujuju"
        },
        {
          materialNumber: "542568153454",
          serialNumber: "SD9212969"
        }
      ])
    );
    const skipExisiting = getByTestId("skipExisingRecords");
    expect(skipExisiting.textContent).toEqual("Skip");
    fireEvent.click(skipExisiting, { target: { checked: "true" } });

    expect(skipExisiting.textContent).toEqual("Skip");

    const pickedProps = getByTestId("pickedProps");
    const isPropChecked = getByTestId("isPropChecked");
    const isAllPropChecked = getByTestId("isAllPropChecked");
    const onAllPropChecked = getByTestId("onAllPropChecked");
    const file = getByTestId("file");

    expect(pickedProps.textContent).toContain(
      JSON.stringify(requiredInstrumentProperties)
    );
    expect(isPropChecked.textContent).toEqual("unchecked");
    expect(isAllPropChecked.textContent).toEqual("not all checked");
    expect(file.textContent).toContain("file");

    fireEvent.click(pickedProps);
    expect(pickedProps.textContent).toContain("instrumentRUDI");
    expect(isPropChecked.textContent).toEqual("checked");
    expect(isAllPropChecked.textContent).toEqual("not all checked");
    fireEvent.click(pickedProps);
    fireEvent.click(onAllPropChecked);
    expect(isAllPropChecked.textContent).toEqual("all checked");

    expect(getByTestId("requiredProps").textContent).toEqual("9");

    fireEvent.click(getByTestId("setNull"));
    expect(getByTestId("requiredProps").textContent).toEqual(
      "" + requiredInstrumentProperties.length
    );
    expect(pickedProps.textContent).toContain("serialNumber");
    expect(file.textContent).toContain("empty");
  });
});
