import * as CSV from "csv-string";
import {
  requiredInstrumentProperties,
  hasRequiredInstrumentProperties,
  getParsedInstruments,
  curriedMapItemInstrument,
  validateInstrumentValues,
  getHeaders
} from "./structure";

export const readFileAsBinaryString = async (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener("load", () => {
      if (reader.result) {
        resolve(reader.result);
      } else {
        reject(null);
      }
    });
    reader.readAsBinaryString(file);
  });

export const checkFileStructure = (data, checkHeader, minFieldLength = 1) => {
  if (typeof data !== "string" && !data) throw new Error("No data provided");
  const delimiter = CSV.detect(data);
  let header = null;
  const dataCSV = [];
  CSV.forEach(data, delimiter, function (row, index) {
    if (index === 0 && row?.filter((x) => x)?.length) header = [...row];
    if (index !== 0 && Array.isArray(row) && row.length >= minFieldLength)
      dataCSV.push(row);
  });
  if (!header) throw new Error("Header not found");
  const checkHeaderResult = checkHeader(header);
  if (!checkHeaderResult.valid)
    throw new Error(
      `Required ${checkHeaderResult?.data?.length === 1
        ? "property was"
        : "properties were"
      } not found${": " + checkHeaderResult?.data?.join(", ")}`
    );
  return {
    header,
    content: dataCSV
  };
};


export const getObjectsFromFileCSV = async (file) => {
  const stringData = await readFileAsBinaryString(file);
  const result = checkFileStructure(
    stringData,
    hasRequiredInstrumentProperties,
    requiredInstrumentProperties.length
  );
  const parsedValues = getParsedInstruments(result.header, result.content);
  const instrumentsValues = parsedValues?.map(curriedMapItemInstrument);
  await validateInstrumentValues(instrumentsValues);
  return { headers: getHeaders(result.header), data: instrumentsValues };
};
