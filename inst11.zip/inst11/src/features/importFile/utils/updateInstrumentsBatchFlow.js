import { updateInstrumentsBatch, updateInstrumentsStore } from "./actions";
export const updateInstrumentsBatchFlow = async (
  client,
  importData,
  loadInstruments
) => {
  const results = await updateInstrumentsBatch(client, importData);
  await updateInstrumentsStore(client, loadInstruments);
  return results;
};
