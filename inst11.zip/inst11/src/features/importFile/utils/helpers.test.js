import {
  getObjectsFromFileCSV,
  checkFileStructure,
  readFileAsBinaryString
} from "./helpers";
import { hasRequiredInstrumentProperties } from "./structure";
import { TextEncoder, TextDecoder } from "util";
global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;

describe("helpers function tests", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });
  test.skip("getObjectsFromFileCSV should return objects", async () => {
    const stringData = `instrumentRUDI,materialNumber,serialNumber,instrumentType.value,instrumentType.isSynchronized,instrumentName.value,instrumentName.isSynchronized,isBookable,instrumentGTIN.value,instrumentGTIN.isSynchronized,siteName,siteTimezone,manufacturer.value,manufacturer.isSynchronized,equipmentId.value,equipmentId.isSynchronized
    jujjuju,ggggguuu,jujujuju,jujuju,false,ujujuju,true,true,gtt,false,siteName,timezone,man1,true,eq1,false
    ^^^^^^DMD^5800^0.0.0.0342,542568153454,SD9212969,Cobas 6400,false,STING.5,true,false,gtn1,false,siteName 2,timezone 2,man2,false,eq2,true`;
    const file = new File([new TextEncoder().encode(stringData)], "file.csv");

    const instrumentsValuesExpected = [
      {
        instrumentGTIN: {
          isSynchronized: false,
          value: "gtt"
        },
        instrumentRUDI: "jujjuju",
        instrumentName: {
          isSynchronized: true,
          value: "ujujuju"
        },
        instrumentType: {
          isSynchronized: false,
          value: "jujuju"
        },
        manufacturer: {
          isSynchronized: true,
          value: "man1"
        },
        equipmentId: {
          isSynchronized: false,
          value: "eq1"
        },
        isBookable: true,
        materialNumber: "ggggguuu",
        serialNumber: "jujujuju",
        siteName: "siteName",
        siteTimezone: "timezone"
      },
      {
        siteName: "siteName 2",
        siteTimezone: "timezone 2",
        instrumentGTIN: {
          isSynchronized: false,
          value: "gtn1"
        },
        instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342",
        instrumentName: {
          isSynchronized: true,
          value: "STING.5"
        },
        manufacturer: {
          isSynchronized: false,
          value: "man2"
        },
        equipmentId: {
          isSynchronized: true,
          value: "eq2"
        },
        instrumentType: {
          isSynchronized: false,
          value: "Cobas 6400"
        },
        isBookable: false,
        materialNumber: "542568153454",
        serialNumber: "SD9212969"
      }
    ];
    expect(await getObjectsFromFileCSV(file)).toEqual({
      data: instrumentsValuesExpected,
      headers: [
        "instrumentRUDI",
        "materialNumber",
        "serialNumber",
        "instrumentType",
        "instrumentName",
        "isBookable",
        "instrumentGTIN",
        "siteName",
        "siteTimezone",
        "manufacturer",
        "equipmentId"
      ]
    });
  });

  test("checkFileStructure should throws different errors", async () => {
    expect(() => checkFileStructure(undefined)).toThrow("No data provided");
    expect(() =>
      checkFileStructure(" ", hasRequiredInstrumentProperties)
    ).toThrow("Header not found");
    expect(() =>
      checkFileStructure("a,b", hasRequiredInstrumentProperties)
    ).toThrow(
      "Required properties were not found: materialNumber, serialNumber, siteName, siteTimezone, equipmentId.value, equipmentId.isSynchronized"
    );
    expect(() =>
      checkFileStructure(
        "serialNumber,siteName,siteTimezone,equipmentId.value,equipmentId.isSynchronized",
        hasRequiredInstrumentProperties
      )
    ).toThrow("Required property was not found: materialNumber");
  });

  test("readFileAsBinaryString should reject file", async () => {
    const file = new File([new ArrayBuffer()], "file.csv");

    await expect(readFileAsBinaryString(file)).rejects.toEqual(null);
  });
});
