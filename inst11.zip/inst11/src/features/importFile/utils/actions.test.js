import { updateInstrumentsBatch, updateInstrumentsStore } from "./actions";
import { emptyInstruments } from "../../instruments/InstrumentsModal";

describe("structure function tests", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  test.skip("updateInstrumentsBatch should batch update instruments", async () => {
    const client = {
      mutate: jest.fn(({ variables }) => Promise.resolve(variables))
    };
    const arrayOfInstruments = [
      { isNew: true, ...emptyInstruments, name: "inst 1" },
      { isNew: false, ...emptyInstruments, name: "inst 2" },
      { ...emptyInstruments, name: "inst 3" }
    ];
    await expect(
      updateInstrumentsBatch(client, arrayOfInstruments)
    ).resolves.toEqual([
      {
        status: "fulfilled",
        value: {
          ...emptyInstruments,
          name: "inst 1"
        }
      },
      {
        status: "fulfilled",
        value: {
          ...emptyInstruments,
          name: "inst 2"
        }
      },
      {
        status: "fulfilled",
        value: {
          ...emptyInstruments,
          name: "inst 3"
        }
      }
    ]);
  });

  test("updateInstrumentsStore should call function updating store", async () => {
    const client = {
      query: jest.fn(({ variables }) => Promise.resolve(variables))
    };
    const loadInstruments = jest.fn();
    const fetchInstruments = jest.fn(() => Promise.resolve({ items: [] }));
    await updateInstrumentsStore(client, loadInstruments, fetchInstruments);
    expect(fetchInstruments).toBeCalledTimes(1);
    expect(loadInstruments).toBeCalledTimes(1);
    expect(loadInstruments).toBeCalledWith({
      instruments: []
    });
    const fetchInstruments2 = jest.fn(() => Promise.reject("err"));
    await expect(
      updateInstrumentsStore(client, loadInstruments, fetchInstruments2)
    ).rejects.toEqual("err");
  });
});
