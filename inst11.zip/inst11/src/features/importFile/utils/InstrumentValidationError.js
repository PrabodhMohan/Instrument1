export class InstrumentValidationError extends Error {
  constructor(errors = {}, ...params) {
    super(...params);
    Error?.captureStackTrace(this, InstrumentValidationError);
    this.errors = errors;
    this.date = new Date();
  }
}
