import {
  getAllAvailableKeys,
  hasAllRequiredProperties,
  getObjectTypesByKey,
  filterDataToImport,
  validateValuesCurried,
  getParsedInstruments,
  curriedMapItem
} from "./structure";
import { InstrumentValidationSchema } from "./schema";
import { InstrumentValidationError } from "./InstrumentValidationError";

const importData = [
  {
    instrumentGTIN: {
      isSynchronized: false,
      value: "gtt"
    },
    siteName: "siteName",
    siteTimezone: "timezone",
    instrumentRUDI: "jujjuju",
    instrumentName: {
      isSynchronized: true,
      value: "ujujuju"
    },
    instrumentType: {
      isSynchronized: false,
      value: "jujuju"
    },
    equipmentId: {
      isSynchronized: false,
      value: "eqid"
    },
    isBookable: true,
    materialNumber: "ggggguuu",
    serialNumber: "jujujuju"
  },
  {
    siteName: "siteName",
    siteTimezone: "timezone",
    instrumentGTIN: {
      isSynchronized: false,
      value: "gtn1"
    },
    instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342",
    instrumentName: {
      isSynchronized: true,
      value: "STING.5"
    },
    instrumentType: {
      isSynchronized: false,
      value: "Cobas 6400"
    },
    equipmentId: {
      isSynchronized: false,
      value: "eqid"
    },
    isBookable: false,
    materialNumber: "542568153454",
    serialNumber: "SD9212969"
  }
];

describe("structure function tests", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });
  test("should getAllAvailableKeys omit defined keys", () => {
    expect(getAllAvailableKeys({ a: 1, b: 2 }, ["b"])).toEqual(["a"]);
  });
  test("hasAllRequiredProperties should check required properties", () => {
    expect(hasAllRequiredProperties(null)).toEqual({ valid: false });
    expect(hasAllRequiredProperties([1, 3], null)).toEqual({ valid: false });
    expect(hasAllRequiredProperties(null, [1, 2])).toEqual({ valid: false });
    expect(hasAllRequiredProperties([1, 3], [1, 3])).toEqual({
      valid: true,
      data: []
    });
  });

  test("getObjectTypesByKey should return types by key", () => {
    expect(getObjectTypesByKey(null)).toEqual({});
    expect(getObjectTypesByKey([])).toEqual({});
    expect(getObjectTypesByKey({ a: true, b: 1, c: "text" })).toEqual({
      a: "boolean",
      b: "number",
      c: "string"
    });
    expect(getObjectTypesByKey()).toEqual({});
  });

  test("curriedMapItem should return", () => {
    const types = {
      belongingToGroup: "string",
      floorAndRoomLocation: "object",
      instrumentGTIN: "object",
      buildingLocation: "object",
      instrumentGxPStatus: "object",
      instrumentRUDI: "string",
      instrumentName: "object",
      instrumentType: "object",
      isBookable: "boolean",
      isVisualized: "boolean",
      materialNumber: "string",
      responsiblePerson: "object",
      softwareVersion: "string",
      systemStatus: "object",
      serialNumber: "string",
      configurationBaseline: "string",
      dateOfLastMaintanance: "object",
      dateOfNextMaintanance: "object",
      qualificationDocuments: "object",
      installedTests: "object"
    };

    const item = {
      "instrumentGTIN.isSynchronized": "false",
      "instrumentGTIN.value": "gtn1",
      instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342",
      "instrumentName.isSynchronized": "true",
      "instrumentName.value": "STING.5",
      "instrumentType.isSynchronized": "false",
      "instrumentType.value": "Cobas 6400",
      isBookable: "false",
      materialNumber: "542568153454",
      serialNumber: "SD9212969"
    };

    const expectedResult = {
      instrumentGTIN: {
        isSynchronized: false,
        value: "gtn1"
      },
      instrumentName: {
        isSynchronized: true,
        value: "STING.5"
      },
      instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342",
      instrumentType: {
        isSynchronized: false,
        value: "Cobas 6400"
      },
      isBookable: false,
      materialNumber: "542568153454",
      serialNumber: "SD9212969"
    };

    expect(curriedMapItem(types, item)).toEqual(expectedResult);
  });

  test.skip("getParsedInstruments should flatten object", () => {
    const header = [
        "instrumentRUDI",
        "materialNumber",
        "serialNumber",
        "instrumentType.value",
        "instrumentType.isSynchronized",
        "instrumentName.value",
        "instrumentName.isSynchronized",
        "isBookable",
        "instrumentGTIN.value",
        "instrumentGTIN.isSynchronized"
      ],
      content = [
        [
          "jujjuju",
          "ggggguuu",
          "jujujuju",
          "jujuju",
          "false",
          "ujujuju",
          "true",
          "true",
          "gtt",
          "false"
        ],
        [
          "^^^^^^DMD^5800^0.0.0.0342",
          "542568153454",
          "SD9212969",
          "Cobas 6400",
          "false",
          "STING.5",
          "true",
          "false",
          "gtn1",
          "false"
        ]
      ],
      availableProperties = [
        "instrumentRUDI",
        "materialNumber",
        "serialNumber",
        "instrumentType.value",
        "instrumentType.isSynchronized",
        "instrumentName.value",
        "instrumentName.isSynchronized",
        "isBookable",
        "instrumentGTIN.value",
        "instrumentGTIN.isSynchronized"
      ];

    const expectedResults = [
      {
        "instrumentGTIN.isSynchronized": "false",
        "instrumentGTIN.value": "gtt",
        "instrumentName.isSynchronized": "true",
        "instrumentName.value": "ujujuju",
        instrumentRUDI: "jujjuju",
        "instrumentType.isSynchronized": "false",
        "instrumentType.value": "jujuju",
        isBookable: "true",
        materialNumber: "ggggguuu",
        serialNumber: "jujujuju"
      },
      {
        "instrumentGTIN.isSynchronized": "false",
        "instrumentGTIN.value": "gtn1",
        "instrumentName.isSynchronized": "true",
        "instrumentName.value": "STING.5",
        instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342",
        "instrumentType.isSynchronized": "false",
        "instrumentType.value": "Cobas 6400",
        isBookable: "false",
        materialNumber: "542568153454",
        serialNumber: "SD9212969"
      }
    ];

    expect(getParsedInstruments(header, content, availableProperties)).toEqual(
      expectedResults
    );

    expect(getParsedInstruments(header, content)).toEqual(expectedResults);
  });

  test.skip("validateValuesCurried should validate data based on schema", async () => {
    const notValid = {
      instrumentGTIN: {
        isSynchronized: false,
        value: "gtt"
      },
      instrumentName: {
        isSynchronized: true,
        value: "ujujuju"
      },
      instrumentType: {
        isSynchronized: false,
        value: "jujuju"
      },
      isBookable: true,
      serialNumber: "jujujuju"
    };

    await expect(
      validateValuesCurried(InstrumentValidationSchema, importData)
    ).resolves.toEqual(true);

    await expect(
      validateValuesCurried(InstrumentValidationSchema, [
        ...importData,
        notValid,
        {}
      ])
    ).rejects.toThrowError(InstrumentValidationError);
  });

  test("filterDataToImport should filter data do import", () => {
    const existingIds = [
      {
        instrumentRUDI: "jujjuju"
      },
      {
        instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342"
      }
    ];
    const pickedProps = [
      "instrumentGTIN",
      "instrumentRUDI",
      "instrumentName",
      "instrumentType",
      "isBookable",
      "materialNumber",
      "serialNumber"
    ];
    const skipExising = false;
    const compareProps = ["instrumentRUDI"];

    const expectedResults = [
      {
        instrumentGTIN: {
          isSynchronized: false,
          value: "gtt"
        },
        instrumentName: {
          isSynchronized: true,
          value: "ujujuju"
        },
        instrumentRUDI: "jujjuju",
        instrumentType: {
          isSynchronized: false,
          value: "jujuju"
        },
        isBookable: true,
        isNew: false,
        materialNumber: "ggggguuu",
        serialNumber: "jujujuju"
      },
      {
        instrumentGTIN: {
          isSynchronized: false,
          value: "gtn1"
        },
        instrumentName: {
          isSynchronized: true,
          value: "STING.5"
        },
        instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342",
        instrumentType: {
          isSynchronized: false,
          value: "Cobas 6400"
        },
        isBookable: false,
        isNew: false,
        materialNumber: "542568153454",
        serialNumber: "SD9212969"
      }
    ];

    expect(
      filterDataToImport(
        importData,
        existingIds,
        pickedProps,
        skipExising,
        compareProps
      )
    ).toEqual(expectedResults);

    // skip existing
    expect(
      filterDataToImport(
        importData,
        existingIds,
        pickedProps,
        true,
        compareProps
      )
    ).toEqual([]);
  });
});
