import * as yup from "yup";
export const InstrumentValidationSchema = yup.object({
  serialNumber: yup
    .string("Enter serial number")
    .required("Serial number is required"),
  siteName: yup.string("Enter site name").required("Site name is required"),
  siteTimezone: yup
    .string("Enter site timezone")
    .required("Site timezone is required"),
  materialNumber: yup
    .string("Enter material number")
    .required("Material number is required"),
  instrumentRUDI: yup.string("Enter RUIDI number").nullable(),
  buildingLocation: yup.object({
    value: yup.string("Enter building location"),
    key: yup.string("Enter key  building location"),
  }),
  instrumentGTIN: yup.object({
    value: yup
      .string("Enter instrument GTIN")
      .required("instrument GTIN is required"),
    isSynchronized: yup.bool()
  }),
  instrumentName: yup.object({
    value: yup
      .string("Enter instrument name")
      .required("Instrument name is required"),
    isSynchronized: yup.bool()
  }),
  instrumentType: yup.string("Enter instrument type").required("Instrument type is required"),
  isBookable: yup.bool(),
  isVisualized: yup.bool(),
  floorAndRoomLocation: yup.object({
    value: yup.string("Enter instrument location"),
    isSynchronized: yup.bool()
  }),
  responsiblePerson: yup.object({
    value: yup.string("Enter responsible person"),
    isSynchronized: yup.bool()
  }),
  softwareVersion: yup.string("Enter software version"),
  configurationBaseline: yup.string("Enter configuration baseline"),
  systemStatus: yup.object({
    value: yup.string("Enter system status"),
    isSynchronized: yup.bool()
  }),
  instrumentGxPStatus:yup.string("Enter instrument GxP Status"),
  belongingToGroup: yup.string("Enter belonging to group"),
  dateOfLastMaintanance: yup.object({
    value: yup.date().typeError("invalid date").nullable(),
    isSynchronized: yup.bool()
  }),
  dateOfNextMaintanance: yup.object({
    value: yup.date().typeError("invalid date").nullable(),
    isSynchronized: yup.bool()
  }),
  equipmentId: yup
    .object({
      value: yup
        .string("Enter equipment ID")
        .required("Equipment ID is required"),
      isSynchronized: yup.bool()
    })
    .required("Equipment ID is required"),
  manufacturer: yup
    .object({
      value: yup.string("Enter manufacturer value"),
      key: yup.string("Enter manufacturer key"),
    })
    .nullable(),
  secondResponsiblePerson: yup
    .object({
      value: yup.string("Enter second responsible person"),
      isSynchronized: yup.bool()
    })
    .nullable(),
  systemOwner: yup.string("Enter system owner").nullable(),
  technicalPlace: yup.string("Enter technical place").nullable(),
  remark:yup.string("Enter remark").nullable(),
  instrumentDescription:yup
    .object({
      value: yup.string("Enter instrument description value"),
      key: yup.string("Enter instrument description key"),
    })
    .nullable(),
  module:yup
    .object({
      value: yup.string("Enter module  value"),
      key: yup.string("Enter module  key"),
    })
    .nullable(),
  sop:yup
    .object({
      value: yup.string("Enter sop  value"),
      key: yup.string("Enter sop  key"),
    })
    .nullable(),
  csv:yup.string("Enter csv").nullable(),
  electronicRecord:yup.string("Enter electronic record").nullable(),
  electronicSignatures:yup.string("Enter electronic signatures").nullable(),
  dateOfNextPeriodicReview:yup.string("Enter date Of NextPeriodicReview").nullable(),
  maintenancePlan:yup.string("Enter maintenance plan").nullable(),
  gxpRelevant:yup.string("Enter gxpRelevant").nullable(),
  testEquipment:yup.string("Enter test equipment").nullable(),
  sourceSystem:yup.string("Enter source system").nullable(),
  location:yup.string("Enter location").nullable(),
  equipmentCategory:yup
  .object({
    value: yup.string("Enter equipment  category"),
    key: yup.string("Enter equipment  category"),
  })
  .nullable(),
});
