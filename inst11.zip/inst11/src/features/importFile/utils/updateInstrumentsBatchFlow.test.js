import { updateInstrumentsBatch, updateInstrumentsStore } from "./actions";
import { updateInstrumentsBatchFlow } from "./updateInstrumentsBatchFlow";
import { cleanup } from "@testing-library/react";

jest.mock("./actions");
afterEach(cleanup);

describe("updateInstrumentsBatchFlow function tests", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  test("updateInstrumentsBatchFlow should call update flow", async () => {
    const client = {};
    const importData = [];
    const loadInstruments = jest.fn();
    updateInstrumentsStore.mockReturnValue(Promise.resolve("ok"));
    updateInstrumentsBatch.mockReturnValue(Promise.resolve("ok"));
    await expect(
      updateInstrumentsBatchFlow(client, importData, loadInstruments)
    ).resolves.toEqual("ok");
  });
});
