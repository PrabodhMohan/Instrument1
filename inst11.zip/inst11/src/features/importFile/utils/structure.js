import { intersection, pick, set, omit, difference } from "lodash";
import * as R from "ramda";
import flatten, { unflatten } from "flat";
import { InstrumentValidationSchema } from "./schema";
import { emptyInstruments } from "../../instruments/InstrumentsModal";
import { InstrumentValidationError } from "./InstrumentValidationError";

export const omittedCSVKeys = ["qualificationDocuments", "installedTests"];

export const getAllAvailableKeys = (obj, omittedKeys) =>
  Object.keys(flatten(omit(obj, omittedKeys)));

export const requiredInstrumentProperties = [
  "materialNumber",
  "serialNumber",
  "siteName",
  "siteTimezone",
  "equipmentId.value",
  "equipmentId.isSynchronized",
];

export const requiredProps = [
  "materialNumber",
  "serialNumber",
  "siteName",
  "siteTimezone",
  "equipmentId.value",
  "equipmentId.isSynchronized",
];

export const keysSynchronized = [
  "buildingLocation",
  "dateOfLastMaintanance",
  "dateOfNextMaintanance",
  "floorAndRoomLocation",
  "instrumentGTIN",
  "instrumentName",
  "qualificationDocuments",
  "responsiblePerson",
  "systemStatus",
  "secondResponsiblePerson",
  "manufacturer",
  "equipmentId",
  "equipmentCategory"
];

export const instrumentIdentifiers = ["materialNumber", "serialNumber"];

export const headersTranslationMap = {
  softwareVersion: "Software version",
  belongingToGroup: "Belonging to group",
  buildingLocation: "Building location",
  configurationBaseline: "Configuration baseline",
  dateOfLastMaintanance: "Date of last maintanance",
  dateOfNextMaintanance: "Date of next maintanance",
  floorAndRoomLocation: "Floor and room location",
  installedTests: "Installed tests",
  instrumentGTIN: "Instrument GTIN",
  instrumentGxPStatus: "Instrument GxP status",
  instrumentName: "Instrument name",
  instrumentRUDI: "Instrument RUDI",
  instrumentType: "Instrument type",
  isBookable: "Bookable",
  isVisualized: "Visualized",
  materialNumber: "Material number",
  qualificationDocuments: "Qualification documents",
  responsiblePerson: "Responsible person",
  serialNumber: "Serial number",
  systemStatus: "System status",
  siteName: "Site name",
  siteTimezone: "Site timezone",
  equipmentId: "Equipment id",
  manufacturer: "Manufacturer",
  secondResponsiblePerson: "Second responsible person",
  systemOwner:"System owner",
  equipmentCategory:"Equipment category",
  technicalPlace:"Technical place",
  remark:"Remark",
  instrumentDescription:"Instrument description",
  module:"Module",
  sop:"SOP",
  csv:"Csv",
  electronicRecord:"Electronic Record",
  electronicSignatures:"Electronic Signatures",
  dateOfNextPeriodicReview:"Date Of Next Periodic Review",
  maintenancePlan:"Maintenance Plan",
  gxpRelevant:"Gxp Relevant",
  sourceSystem:"Source System",
  location:"Location",
  testEquipment:"Test equipment"
};

export const getHeaders = arr => {
  const availableHeaders = Object.keys(headersTranslationMap);
  return [
    ...new Set(
      arr?.map(x => {
        const dot = x?.indexOf(".");
        return dot !== -1 ? x?.slice(0, dot) : x;
      })
    ),
  ].filter(header => availableHeaders?.includes(header));
};

export const getObjectTypesByKey = (Obj = {}) => {
  if (typeof Obj !== "object" || Obj === null) return {};
  return Object.keys(Obj)?.reduce(
    (acc, k) => ({ ...acc, [k]: typeof Obj[k] }),
    {}
  );
};

export const hasAllRequiredProperties = (requiredData, data) => {
  if (!Array.isArray(data)) return { valid: false };
  if (!Array.isArray(requiredData)) return { valid: false };
  const reqProps = intersection(data, requiredData);
  return {
    valid: reqProps.length === requiredData.length,
    data: difference(requiredData, reqProps)
  };
};

const curriedHasAllRequiredProperties = R.curry(hasAllRequiredProperties);

export const hasRequiredInstrumentProperties = curriedHasAllRequiredProperties(
  requiredInstrumentProperties
);

export const mapRow = R.curry(
  (header, availableProperties, defaultObject, row) =>
    pick(
      header?.reduce(
        (acc, k, idx) => ({
          ...acc,
          [k]: row[idx]?.trim() ? row[idx]?.trim() : defaultObject[idx],
        }),
        {}
      ) ?? {},
      availableProperties
    )
);

export const curriedMapItem = R.curry((types, item) => {
  const _newObj = unflatten(item);
  Object.keys(item)?.forEach(key => {
    if (key.endsWith("isSynchronized") || types[key] === "boolean") {
      set(_newObj, key, item[key]?.trim()?.toLowerCase() === "true");
    } else {
      set(_newObj, key, item[key]);
    }
  });
  return _newObj;
});

export const curriedMapItemInstrument = curriedMapItem(
  getObjectTypesByKey(emptyInstruments)
);

export const getParsedInstruments = (
  header,
  content,
  availableProperties = getAllAvailableKeys(emptyInstruments, omittedCSVKeys)
) => {
  const emptyInstrumentsFlatten = flatten(emptyInstruments);
  const mapRowInstrument = mapRow(
    header,
    availableProperties,
    emptyInstrumentsFlatten
  );
  return content?.reduce((acc, row) => [...acc, mapRowInstrument(row)], []);
};

export const validateValuesCurried = R.curry(
  async (validationSchema, values) => {
    const errors = {};
    for (const item of values) {
      try {
        await validationSchema?.validate(item);
      } catch (err) {
        console.log("@@@@Eeer", err);
        if (err.message in errors) {
          errors[err.message] = ++errors[err.message];
        } else {
          errors[err.message] = 1
        }
      }
    }
    const errorMessages = Object.keys(errors);
    if (errorMessages.length) throw new InstrumentValidationError(errors);
    return true;
  }
);

export const validateInstrumentValues = validateValuesCurried(
  InstrumentValidationSchema
);

export const filterDataToImport = R.curry(
  (importData, existingRecordsIds, pickedProps, skipExising, compareProps) => {
    const containIds = R.flip(R.contains)(
      R.map(R.pick(compareProps))(existingRecordsIds)
    );
    const filterProps = R.map(item => ({
      ...R.pick(pickedProps)(item),
      isNew: !containIds(R.pick(compareProps)(item)),
    }));
    if (skipExising) {
      return R.compose(
        filterProps,
        R.filter(R.compose(R.not, containIds, R.pick(compareProps)))
      )(importData);
    }
    return filterProps(importData);
  }
);
