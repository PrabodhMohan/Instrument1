import { InstrumentValidationError } from "./InstrumentValidationError";
test("should return default error", () => {
  const error = new InstrumentValidationError();
  expect(error.errors).toEqual({});
});
test("should default error", () => {
  const error = new InstrumentValidationError();
  expect(error.errors).toEqual({});
});
