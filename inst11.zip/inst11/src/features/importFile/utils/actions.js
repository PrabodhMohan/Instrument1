import { isNull, omitBy } from "lodash";
import {
  CREATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
  UPDATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY
} from "../../../gql/landingapi/mutations";
import { LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS } from "../../../gql/landingapi/queries";
import { getAllData } from "../../../utils/helpers/fetching";
import { emptyInstruments } from "../../instruments/InstrumentsModal";

export const getInstrumentWithDefaultValues = ({
  instrument,
  defaultInstrument = emptyInstruments,
}) => ({
  ...defaultInstrument,
  ...omitBy(instrument, isNull),
});

export const updateInstrumentsBatch = async (client, arrayOfInstruments) => {
  const arrayOfInstrumentsPromises = arrayOfInstruments?.map((instrument) => {
    const { isNew = false, ...variables } = instrument;
    if (isNew) {
      return client.mutate({
        mutation: CREATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
        variables: {instrument:getInstrumentWithDefaultValues({
          instrument: variables,
        })},
        fetchPolicy: "no-cache",
      });
    } else {
      return client.mutate({
        mutation: UPDATE_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRY,
        variables: {instrument:omitBy(variables, isNull)},
        fetchPolicy: "no-cache",
      });
    }
  });
  return Promise.allSettled([...arrayOfInstrumentsPromises]);
};

export const updateInstrumentsStore = async (
  client,
  loadInstruments,
  fetchInstruments = getAllData
) => {
  const { items: instruments } = await fetchInstruments({
    client,
    query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
    drillData: true,
    variables: {
      limit: 1000,
    },
    dataPath: ["data", "listDigitalLabInstrumentRepositoryEntrys"]
  });
  loadInstruments({
    instruments
  });
};
