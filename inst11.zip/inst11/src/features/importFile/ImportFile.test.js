import React, { useContext, useCallback, useState } from "react";
import { render, cleanup } from "@testing-library/react";
import FileContextWapper from "./FileContext";
import ImportComponent from "./components/ImportComponent";
import UploadInstruments from "./UploadInstruments";
import { ImportFile } from "./ImportFile";

afterEach(cleanup);

afterEach(cleanup);
jest.mock("./FileContext", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});

jest.mock("./components/ImportComponent", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});
jest.mock("./UploadInstruments", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});

describe("ImportFile tests", () => {
  test("should render ImportFile successfully", async () => {
    UploadInstruments.mockImplementation(() => (
      <div data-testid="uploadInstruments"></div>
    ));
    ImportComponent.mockImplementation(() => (
      <div data-testid="importComponent"></div>
    ));
    FileContextWapper.mockImplementation(({ children }) => (
      <div>{children}</div>
    ));
    const { getByTestId } = render(<ImportFile />);
    expect(getByTestId("uploadInstruments")).toBeInTheDocument();
    expect(getByTestId("importComponent")).toBeInTheDocument();
  });
});
