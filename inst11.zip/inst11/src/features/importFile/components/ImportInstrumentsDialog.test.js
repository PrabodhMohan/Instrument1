import React from "react";
import { fireEvent, render, waitFor } from "@testing-library/react";
import ImportInstrumentsDialog from "./ImportInstrumentsDialog";
import SelectionList from "./SelectionList";
import MaterialTheme from "../../../components/MaterialTheme";

jest.mock("./SelectionList");

describe("ImportInstrumentsDialog tests", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });
  test("should render ImportInstrumentsDialog and number of instruments to import", async () => {
    SelectionList.mockImplementation(() => (
      <div data-testid="selection-list"></div>
    ));
    const open = true;
    const instrumentsCount = 8;
    const uploading = false;

    const { getByTestId, container } = render(
      <MaterialTheme>
        <ImportInstrumentsDialog
          open={open}
          instrumentsCount={instrumentsCount}
          uploading={uploading}
        />
      </MaterialTheme>
    );
    await waitFor(() => {
      expect(getByTestId("import-file-dialog")).toBeInTheDocument();
      expect(
        getByTestId("ImportInstrumentsDialogTitle-title").textContent
      ).toEqual("Import instruments");
      expect(
        getByTestId("ImportInstrumentsDialogTitle-count").textContent
      ).toEqual("(8 instruments to import)");
      expect(
        container.querySelector("[data-testid='file-upload-backdrop']")
      ).toEqual(null);
    });
  });

  test("should call onUploadInstruments on approveClick and onCancel on cancle button", async () => {
    SelectionList.mockImplementation(() => (
      <div data-testid="selection-list"></div>
    ));
    const open = true;
    const instrumentsCount = 8;
    const onCancel = jest.fn();
    const onUploadInstruments = jest.fn();
    const uploading = false;

    const { getByTestId, rerender } = render(
      <MaterialTheme>
        <ImportInstrumentsDialog
          open={open}
          instrumentsCount={instrumentsCount}
          uploading={uploading}
          onUploadInstruments={onUploadInstruments}
          onCancel={onCancel}
        />
      </MaterialTheme>
    );
    expect(getByTestId("import-file-dialog")).toBeInTheDocument();
    fireEvent.click(getByTestId("confirm-dialog-actions-button-approve"));
    await waitFor(() => {
      expect(onUploadInstruments).toBeCalledTimes(1);
    });

    rerender(
      <MaterialTheme>
        <ImportInstrumentsDialog
          open={open}
          instrumentsCount={0}
          uploading={uploading}
          onUploadInstruments={onUploadInstruments}
          onCancel={onCancel}
        />
      </MaterialTheme>
    );

    fireEvent.click(getByTestId("confirm-dialog-actions-button-cancel"));
    await waitFor(() => {
      expect(
        getByTestId("confirm-dialog-actions-button-approve")
      ).toBeDisabled();
      expect(onCancel).toBeCalledTimes(1);
    });
  });
});
