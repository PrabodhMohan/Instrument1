import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Backdrop, CircularProgress } from "@material-ui/core";
import { ConfirmDialog, ActionbuttonStyled } from "../../../components/shared";
import FileLoader from "./FileLoader";
import SelectionList from "./SelectionList";
import { ImportInstrumentsTextStyled } from "./styles";

const useStyles = makeStyles(() => ({
  dialog: {
    width: 550
  },
  backdrop: {
    zIndex: 2000,
    position: "absolute"
  }
}));

const ImportInstrumentsDialog = ({
  open,
  instrumentsCount,
  onCancel,
  onUploadInstruments,
  uploading
}) => {
  const classes = useStyles();
  return (
    <ConfirmDialog
      open={open}
      close={onCancel}
      approveText="Import selected data"
      approveColor="primary"
      approveVariant="contained"
      cancelText="Cancel"
      cancelVariant="outlined"
      cancelColor="primary"
      onCancel={onCancel}
      isDivider
      testid={"import-file-dialog"}
      title={
        <ImportInstrumentsTextStyled>
          <span data-testid="ImportInstrumentsDialogTitle-title">
            Import instruments
          </span>
          <span data-testid="ImportInstrumentsDialogTitle-count">{`(${instrumentsCount} instruments to import)`}</span>
        </ImportInstrumentsTextStyled>
      }
      renderActions={({
        cancelColor,
        cancelVariant,
        approveColor,
        approveVariant,
        cancelText,
        approveText
      }) => (
        <>
          <ActionbuttonStyled
            data-testid="confirm-dialog-actions-button-cancel"
            onClick={onCancel}
            color={cancelColor && "secondary"}
            variant={cancelVariant}
          >
            {cancelText}
          </ActionbuttonStyled>
          <ActionbuttonStyled
            data-testid="confirm-dialog-actions-button-approve"
            onClick={onUploadInstruments}
            color={approveColor && "primary"}
            variant={approveVariant}
            disabled={instrumentsCount === 0}
          >
            {approveText}
          </ActionbuttonStyled>
        </>
      )}
    >
      <FileLoader>
        <Backdrop
          data-testid="file-upload-backdrop"
          classes={{ root: classes.backdrop }}
          open={uploading}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
        <SelectionList />
      </FileLoader>
    </ConfirmDialog>
  );
};

export default ImportInstrumentsDialog;
