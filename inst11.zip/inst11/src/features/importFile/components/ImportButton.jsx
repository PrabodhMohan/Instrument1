import React from "react";
import styled from "styled-components";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import { Button } from "@material-ui/core";
import Notify from "../../notifications/Notify";
import { makeStyles } from "@material-ui/core";

const ImportButtonStyled = styled.div`
  && {
    text-transform: none;
    background-color: #ffffff;
    color: #0066cc;
    font-weight: 500;
    border: 1px solid #d3d3d3;
  }
`;
const IconStyle = styled(Button)`
  && {
    text-transform: none;
    padding: 0px;
    font-family: "Roboto";
    font-style: normal;
    font-weight: 400;
    font-size: 16px;
    line-height: 19px;
  }
`;

const useStyles = makeStyles((theme) => ({
  root: {
    "&:hover": {
      color: "#0066cc",
      background: "none"
    }
  }
}));

const ImportButton = () => {
  const classes = useStyles();
  return (
    <IconStyle
      data-testid="import-instrument-file-select"
      className={classes.root}
    >
      Import CSV
    </IconStyle>
  );
};

export const ImportExampleDownload = ({ status }) => {
  const classes = useStyles();
  return (
    <IconStyle
      className={classes.root}
      data-testid="import-example-instrument"
      component="a"
      href={"/files/example_instrument.csv"}
      download="example_instrument.csv"
      onClick={() =>
        Notify({
          type: "success",
          icon: "yes",
          appName: "",
          text: `Download template Successfully.`
        })
      }
    >
      Download Template
    </IconStyle>
  );
};

export const DisableImportButton = () => {
  return (
    <ImportButtonStyled
      variant="contained"
      startIcon={<AddCircleOutlineIcon />}
      data-testid="disable-import-instrument-file-select"
      disabled={true}
    >
      Import CSV
    </ImportButtonStyled>
  );
};

export default ImportButton;
