import React, { useState, useEffect, useContext } from "react";
import { CircularProgress } from "@material-ui/core";
import { getObjectsFromFileCSV } from "../utils/helpers";
import { FileContext } from "../FileContext";
import Notify from "../../notifications/Notify";
import { InstrumentValidationError } from "../utils/InstrumentValidationError";

const handleNotificationError = err => {
  if (err instanceof InstrumentValidationError) {
    Object.keys(err?.errors).forEach(error =>
      Notify({
        type: "warning",
        icon: "caution",
        appName: "",
        text: `${error}(${err?.errors[error]} ${
          err?.errors[error] > 1 ? "occurrences" : "occurrence"
        })`
      })
    );
  } else {
    Notify({
      type: "warning",
      icon: "caution",
      appName: "",
      text: err?.message || err
    });
  }
};

const FileLoader = ({ children }) => {
  const [loading, setLoading] = useState(true);
  const { file, setFile, setImportData, setHeaders } = useContext(FileContext);
  useEffect(() => {
    const loadFile = async () => {
      setLoading(true);
      try {
        const { headers, data } = await getObjectsFromFileCSV(file);
        setImportData(data);
        setHeaders(headers);
        setLoading(false);
      } catch (err) {
        console.log("@@@@", { err });
        setFile(null);
        handleNotificationError(err);
      }
    };
    if (file) loadFile();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [file, setImportData, setFile]);
  if (loading)
    return (
      <CircularProgress data-testid="FileLoader-loading" color="inherit" />
    );
  return children;
};

export default FileLoader;
