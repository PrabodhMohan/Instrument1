import React, { useRef } from "react";
import { fireEvent, render, waitFor } from "@testing-library/react";
import FileSelect from "./FileSelect";

jest.mock("react", () => {
  const originReact = jest.requireActual("react");
  const mUseRef = jest.fn();
  return {
    ...originReact,
    useRef: mUseRef
  };
});

describe("FileSelect tests", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });
  test("should render FileSelect and select file", async () => {
    const fileValidate = jest.fn(() => Promise.resolve());

    const file = new File([new ArrayBuffer(1)], "file.csv");
    const onFileSelect = jest.fn();
    const onFailedRequirements = jest.fn();
    const RenderContent = () => <div data-testid="custom-content"></div>;
    const RenderClear = () => <div data-testid="custom-clear"></div>;
    const click = jest.fn();
    const useRefSpy = jest
      .spyOn(React, "useRef")
      .mockReturnValueOnce({ current: { value: "file", click } });

    const { getByTestId } = render(
      <FileSelect
        onFileSelect={onFileSelect}
        onFailedRequirements={onFailedRequirements}
        renderContent={RenderContent}
        renderClear={RenderClear}
        fileValidate={fileValidate}
      />
    );

    expect(getByTestId("file-uploader")).toBeInTheDocument();
    const fileInput = getByTestId("file-input");
    expect(fileInput).toBeInTheDocument();
    const customContent = getByTestId("custom-content");
    expect(customContent).toBeInTheDocument();
    const customClear = getByTestId("custom-clear");
    expect(customClear).toBeInTheDocument();

    // clear call
    fireEvent.click(customContent);
    await waitFor(() => {
      expect(useRefSpy).toBeCalledTimes(1);
    });

    // call onFileSelect callback
    fireEvent.change(fileInput, { target: { files: [file] } });
    await waitFor(() => {
      expect(onFileSelect).toBeCalledTimes(1);
      expect(onFailedRequirements).toBeCalledTimes(0);
    });
  });

  test("should render FileSelect and reject file", async () => {
    const fileValidate = jest.fn(() => Promise.reject());

    const file = new File([new ArrayBuffer(1)], "file.csv");
    const onFileSelect = jest.fn();
    const onFailedRequirements = jest.fn();
    const RenderContent = () => <div data-testid="custom-content"></div>;
    const RenderClear = () => <div data-testid="custom-clear"></div>;

    const { getByTestId, rerender } = render(
      <FileSelect
        onFileSelect={onFileSelect}
        onFailedRequirements={onFailedRequirements}
        renderContent={RenderContent}
        renderClear={RenderClear}
        fileValidate={fileValidate}
      />
    );

    expect(getByTestId("file-uploader")).toBeInTheDocument();
    const fileInput = getByTestId("file-input");
    expect(fileInput).toBeInTheDocument();

    // call onFileSelect callback
    fireEvent.change(fileInput, { target: { files: [file] } });
    await waitFor(() => {
      expect(onFileSelect).toBeCalledTimes(0);
      expect(onFailedRequirements).toBeCalledTimes(1);
    });

    const onFailedRequirementsNotFunction = undefined;
    rerender(
      <FileSelect
        onFileSelect={onFileSelect}
        onFailedRequirements={onFailedRequirementsNotFunction}
        renderContent={RenderContent}
        renderClear={RenderClear}
        fileValidate={fileValidate}
      />
    );
    fireEvent.change(fileInput, { target: { files: [file] } });
    await waitFor(() => {
      expect(onFileSelect).toBeCalledTimes(0);
    });
  });

  test("should clear file input", async () => {
    const file = new File([new ArrayBuffer(1)], "file.jpg");
    const onFileSelect = jest.fn();
    const RenderContent = () => <div data-testid="custom-content"></div>;
    const RenderClear = () => <div data-testid="custom-clear"></div>;
    const fakeClick = jest.fn();
    const mRef = { current: { value: "file", click: fakeClick } };
    const useRefSpy = jest.spyOn(React, "useRef").mockReturnValueOnce(mRef);
    useRef.mockReturnValue(mRef);

    const { getByTestId, rerender } = render(
      <FileSelect
        onFileSelect={onFileSelect}
        renderIcon={RenderContent}
        renderClear={RenderClear}
      />
    );
    const fileInput = getByTestId("file-input");

    // file does not meet requirements and no callback is registered
    fireEvent.change(fileInput, { target: { files: [file] } });

    rerender(
      <FileSelect
        onFileSelect={onFileSelect}
        renderIcon={RenderContent}
        renderClear={RenderClear}
        shouldClear={true}
      />
    );
    await waitFor(() => {
      expect(useRefSpy).toHaveBeenCalled();
    });
  });
});
