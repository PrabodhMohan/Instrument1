import React, { useContext } from "react";
import { Checkbox, FormControlLabel, makeStyles } from "@material-ui/core";
import { FileContext } from "../FileContext";
import { requiredProps, headersTranslationMap } from "../utils/structure";
import { ImportInstrumentsTextStyled } from "./styles";
import styled from "styled-components";

const SelectionListStyled = styled.div`
  max-height: 260px;
  overflow-y: auto;
  box-sizing: border-box;
  margin: 0;
  padding: 0;
`;

export const useStyles = makeStyles(() => ({
  checkbox: {
    color: "#737373",
    marginRight: "3px"
  }
}));

const SelectionList = () => {
  const {
    onSkipExisingRecords,
    skipExisingRecords,
    onPickedProps,
    isPropChecked,
    onAllPickedProps,
    isAllPropChecked,
    existingRecordsIds,
    headers
  } = useContext(FileContext);
  const classes = useStyles();
  return (
    <>
      <ImportInstrumentsTextStyled>
        <h3>Which data should be imported?</h3>
        <FormControlLabel
          control={
            <Checkbox
              color="primary"
              classes={{
                root: classes.checkbox
              }}
              value={skipExisingRecords}
              checked={skipExisingRecords}
              onChange={onSkipExisingRecords}
              disabled={!existingRecordsIds.length}
              data-testid="import-overwrite-option"
            />
          }
          label="Skip existing records"
        />
      </ImportInstrumentsTextStyled>
      <FormControlLabel
        style={{ width: "100%", margin: "0 auto" }}
        control={
          <Checkbox
            color="primary"
            classes={{
              root: classes.checkbox
            }}
            checked={isAllPropChecked()}
            onChange={onAllPickedProps}
            data-testid={`import-select-all-props`}
          />
        }
        label={"All"}
      />
      <SelectionListStyled>
        {headers?.map((x) => (
          <FormControlLabel
            key={x}
            style={{
              width: "100%",
              margin: "0 auto",
              borderTop: "1px solid #eee"
            }}
            data-testid={`import-control-prop-${x}`}
            control={
              <Checkbox
                color="primary"
                classes={{
                  root: classes.checkbox
                }}
                value={x}
                checked={isPropChecked(x)}
                onChange={onPickedProps}
                disabled={requiredProps.includes(x)}
                data-testid={`import-select-prop-${x}`}
              />
            }
            label={headersTranslationMap?.[x] ?? "-"}
          />
        ))}
      </SelectionListStyled>
    </>
  );
};

export default SelectionList;
