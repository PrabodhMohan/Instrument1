import React from "react";
import { render, cleanup, waitFor } from "@testing-library/react";
import FileLoader from "./FileLoader";
import { getObjectsFromFileCSV } from "../utils/helpers";
import { FileContext } from "../FileContext";
import Notify from "../../notifications/Notify";
import { InstrumentValidationError } from "../utils/InstrumentValidationError";

jest.mock("../utils/helpers");
jest.mock("../../notifications/Notify");

afterEach(cleanup);

describe("FileLoader tests", () => {
  test("should load file successfully", async () => {
    const RenderContent = () => <div data-testid="content"></div>;
    const file = {};
    const setImportData = jest.fn();
    const setFile = jest.fn();
    const setHeaders = jest.fn();
    getObjectsFromFileCSV.mockReturnValueOnce({ headers: [], data: [] });
    const { getByTestId } = render(
      <FileContext.Provider value={{ file, setImportData, setFile, setHeaders }}>
        <FileLoader>
          <RenderContent />
        </FileLoader>
      </FileContext.Provider>
    );
    const loadingFile = getByTestId("FileLoader-loading");
    expect(loadingFile).toBeDefined();
    await waitFor(() => {
      expect(getByTestId("content")).toBeDefined();
      expect(setImportData).toBeCalledTimes(1);
      expect(setFile).toBeCalledTimes(0);
    });
  });

  test("should failed load file and notify error with csv", async () => {
    const file = {};
    const setImportData = jest.fn();
    const setFile = jest.fn();
    const notifyMock = jest.fn();
    Notify.mockImplementation(notifyMock);
    getObjectsFromFileCSV.mockReturnValueOnce(Promise.reject("not csv"));
    const { getByTestId } = render(
      <FileContext.Provider value={{ file, setImportData, setFile }}>
        <FileLoader />
      </FileContext.Provider>
    );
    const loadingFile = getByTestId("FileLoader-loading");
    expect(loadingFile).toBeDefined();
    await waitFor(() => {
      expect(setImportData).toBeCalledTimes(0);
      expect(setFile).toBeCalledTimes(1);
      expect(notifyMock).toBeCalledWith({
        type: "warning",
        icon: "caution",
        appName: "",
        text: "not csv"
      });
    });
  });

  test("should failed load file and notify errors with validation", async () => {
    const file = {};
    const setImportData = jest.fn();
    const setFile = jest.fn();
    const notifyMock = jest.fn();
    Notify.mockImplementation(notifyMock);
    getObjectsFromFileCSV.mockReturnValueOnce(
      Promise.reject(
        new InstrumentValidationError({
          "Required event id": 1,
          "Required RUDI": 2
        })
      )
    );
    const { getByTestId } = render(
      <FileContext.Provider value={{ file, setImportData, setFile }}>
        <FileLoader />
      </FileContext.Provider>
    );
    const loadingFile = getByTestId("FileLoader-loading");
    expect(loadingFile).toBeDefined();
    await waitFor(() => {
      expect(setImportData).toBeCalledTimes(0);
      expect(setFile).toBeCalledTimes(1);
      expect(notifyMock).toBeCalledTimes(2);
      expect(notifyMock).toBeCalledWith({
        type: "warning",
        icon: "caution",
        appName: "",
        text: "Required event id(1 occurrence)"
      });
      expect(notifyMock).toBeCalledWith({
        type: "warning",
        icon: "caution",
        appName: "",
        text: "Required RUDI(2 occurrences)"
      });
    });
  });

  test("should not call loadFile", async () => {
    const file = null;
    const setImportData = jest.fn();
    const setFile = jest.fn();
    const notifyMock = jest.fn();
    Notify.mockImplementation(notifyMock);
    const { getByTestId } = render(
      <FileContext.Provider value={{ file, setImportData, setFile }}>
        <FileLoader />
      </FileContext.Provider>
    );
    const loadingFile = getByTestId("FileLoader-loading");
    expect(loadingFile).toBeDefined();
    await waitFor(() => {
      expect(setImportData).toBeCalledTimes(0);
      expect(setFile).toBeCalledTimes(0);
    });
  });
});
