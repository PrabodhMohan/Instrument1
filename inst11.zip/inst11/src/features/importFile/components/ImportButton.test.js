import React from "react";
import { render } from "@testing-library/react";
import ImportButton, {ImportExampleDownload,DisableImportButton} from "./ImportButton";

test("should render ImportButton", async () => {
  const { getByTestId } = render(<ImportButton />);
  const selectFileButton = getByTestId("import-instrument-file-select");
  expect(selectFileButton).toBeDefined();
});


test("should render ImportExampleDownload", async () => {
  const { getByTestId } = render(<ImportExampleDownload />);
  const selectFileButton = getByTestId("import-example-instrument");
  expect(selectFileButton).toBeDefined();
});

test("should render DisableImportButton", async () => {
  const { getByTestId } = render(<DisableImportButton />);
  const selectFileButton = getByTestId("disable-import-instrument-file-select");
  expect(selectFileButton).toBeDefined();
});
