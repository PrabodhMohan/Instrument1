import React, { useContext, useCallback } from "react";
import Notify from "../../notifications/Notify";
import FileSelector from "./FileSelect";
import ImportButton from "./ImportButton";
import { FileContext } from "../FileContext";

const ImportComponent = () => {
  const { file, setFile } = useContext(FileContext);
  const onFileSelect = useCallback((f) => setFile(f), [setFile]);
  const onFailedRequirements = useCallback((error) => {
    Notify({
      type: "warning",
      icon: "caution",
      appName: "",
      text: error?.message || error
    });
  }, []);
  return (
    <FileSelector
      onFileSelect={onFileSelect}
      renderContent={ImportButton}
      onFailedRequirements={onFailedRequirements}
      shouldClear={file === null}
    />
  );
};

export default ImportComponent;
