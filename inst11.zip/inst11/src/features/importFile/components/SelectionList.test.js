import React from "react";
import { render } from "@testing-library/react";
import { FileContext } from "../FileContext";
import MaterialTheme from "../../../components/MaterialTheme";
import SelectionList from "./SelectionList";
import { getHeaders } from "../utils/structure";

const importData = [
  {
    instrumentGTIN: {
      isSynchronized: false,
      value: "gtt"
    },
    instrumentRUDI: "xxx",
    instrumentName: {
      isSynchronized: true,
      value: "ujujuju"
    },
    instrumentType: {
      isSynchronized: false,
      value: "jujuju"
    },
    isBookable: true,
    materialNumber: "ggggguuu",
    serialNumber: "jujujuju",
    isBookableNotKeyFound: false
  },
  {
    instrumentGTIN: {
      isSynchronized: false,
      value: "gtn1"
    },
    instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342",
    instrumentName: {
      isSynchronized: true,
      value: "STING.5"
    },
    instrumentType: {
      isSynchronized: false,
      value: "Cobas 6400"
    },
    isBookable: false,
    materialNumber: "542568153454",
    serialNumber: "SD9212969"
  }
];

const existingRecordsIds = [
  {
    instrumentRUDI: "jujjuju"
  },
  {
    instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342"
  }
];

describe("SelectionList tests", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });
  test("should render instruments list props to import", async () => {
    const onSkipExisingRecords = jest.fn(),
      skipExisingRecords = false,
      onPickedProps = jest.fn(),
      isPropChecked = jest.fn(() => true),
      onAllPickedProps = jest.fn(),
      isAllPropChecked = jest.fn(() => false);

    const { getByTestId, container } = render(
      <FileContext.Provider
        value={{
          importData,
          onSkipExisingRecords,
          skipExisingRecords,
          onPickedProps,
          isPropChecked,
          onAllPickedProps,
          isAllPropChecked,
          existingRecordsIds,
          headers: getHeaders(Object.keys(importData[0]))
        }}
      >
        <MaterialTheme>
          <SelectionList />
        </MaterialTheme>
      </FileContext.Provider>
    );
    const overwriteOption = getByTestId("import-overwrite-option");
    expect(overwriteOption).toBeInTheDocument();
    expect(
      getByTestId(`import-select-prop-instrumentRUDI`)
    ).toBeInTheDocument();

    expect(
      container.querySelector("[data-testid='import-control-prop-isBookableNotKeyFound']")
    ).toEqual(null);

  });
  test("should not render props to import", async () => {
    const onSkipExisingRecords = jest.fn(),
      skipExisingRecords = false,
      onPickedProps = jest.fn(),
      isPropChecked = jest.fn(() => true),
      onAllPickedProps = jest.fn(),
      isAllPropChecked = jest.fn(() => false);

    const { getByTestId, container } = render(
      <FileContext.Provider
        value={{
          importData: [],
          onSkipExisingRecords,
          skipExisingRecords,
          onPickedProps,
          isPropChecked,
          onAllPickedProps,
          isAllPropChecked,
          existingRecordsIds
        }}
      >
        <MaterialTheme>
          <SelectionList />
        </MaterialTheme>
      </FileContext.Provider>
    );
    const overwriteOption = getByTestId("import-overwrite-option");
    expect(overwriteOption).toBeInTheDocument();
    expect(
      container.querySelector(
        `[data-testid='import-select-prop-instrumentRUDI']`
      )
    ).toBeNull();
  });
});
