import React from "react";
import { render, cleanup, waitFor, fireEvent } from "@testing-library/react";
import ImportComponent from "./ImportComponent";
import Notify from "../../notifications/Notify";
import FileSelector from "./FileSelect";
import { FileContext } from "../FileContext";

jest.mock("../utils/helpers");
jest.mock("../../notifications/Notify");
jest.mock("./FileSelect");

afterEach(cleanup);

describe("ImportComponent tests", () => {
  test("should call file select callback", async () => {
    const setFile = jest.fn();
    const file = {};
    const RenderFileSelector = ({ onFileSelect }) => (
      <div data-testid="file-selector">
        <button
          data-testid="select"
          onClick={() => onFileSelect("csv")}
        ></button>
      </div>
    );
    FileSelector.mockImplementation(RenderFileSelector);
    const notifyMock = jest.fn();
    Notify.mockImplementation(notifyMock);
    const { getByTestId } = render(
      <FileContext.Provider value={{ file, setFile }}>
        <ImportComponent />
      </FileContext.Provider>
    );

    fireEvent.click(getByTestId("select"));
    await waitFor(() => {
      expect(notifyMock).toBeCalledTimes(0);
      expect(setFile).toBeCalledTimes(1);
      expect(setFile).toHaveBeenCalledWith("csv");
    });
  });

  test("should call failed select callback", async () => {
    const setFile = jest.fn();
    const file = {};
    const RenderFileSelector = ({ onFailedRequirements }) => (
      <div data-testid="file-selector">
        <button
          data-testid="fail"
          onClick={() => onFailedRequirements("csv")}
        ></button>
      </div>
    );
    FileSelector.mockImplementation(RenderFileSelector);
    const notifyMock = jest.fn();
    Notify.mockImplementation(notifyMock);
    const { getByTestId } = render(
      <FileContext.Provider value={{ file, setFile }}>
        <ImportComponent />
      </FileContext.Provider>
    );

    fireEvent.click(getByTestId("fail"));
    await waitFor(() => {
      expect(notifyMock).toBeCalledTimes(1);
      expect(notifyMock).toHaveBeenCalledWith({
        type: "warning",
        icon: "caution",
        appName: "",
        text: "csv"
      });
    });
  });
});
