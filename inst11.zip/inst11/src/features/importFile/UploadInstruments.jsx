import React, { useContext, useCallback, useState } from "react";
import { withApollo } from "react-apollo";
import { compose } from "redux";
import { connect } from "react-redux";
import { loadInstruments as loadInstrumentsAction } from "../instruments/redux/actions";
import { updateInstrumentsBatchFlow } from "./utils/updateInstrumentsBatchFlow";
import { FileContext } from "./FileContext";
import ImportInstrumentsDialog from "./components/ImportInstrumentsDialog";
import { filterDataToImport, instrumentIdentifiers } from "./utils/structure";
import Notify from "../notifications/Notify";

export const UploadInstruments = ({ client, loadInstruments }) => {
  const {
    file,
    importData,
    setFile,
    pickedProps,
    skipExisingRecords,
    existingRecordsIds
  } = useContext(FileContext);
  const [uploading, setUpload] = useState(false);
  const onCancel = useCallback(() => {
    setFile(null);
  }, [setFile]);
  const onUploadInstruments = async () => {
    try {
      setUpload(true);
      const filteredDataToImport = filterDataToImport(
        importData,
        existingRecordsIds,
        pickedProps,
        skipExisingRecords,
        instrumentIdentifiers
      );
      const results = await updateInstrumentsBatchFlow(
        client,
        filteredDataToImport,
        loadInstruments
      );
      const successes = results?.filter(
        (r) => r.status === "fulfilled" && !("errors" in r.value)
      );
      const notImportedCount = results?.length - successes?.length;
      if (successes?.length) {
        Notify({
          type: "success",
          icon: "yes",
          appName: "",
          text: `Instruments have been successfully imported(count: ${successes?.length})!`
        });
      }
      if (notImportedCount) {
        Notify({
          type: "warning",
          icon: "caution",
          appName: "",
          text: `Instruments not have been imported(count: ${notImportedCount})!`
        });
      }
    } catch (err) {
      Notify({
        type: "warning",
        icon: "caution",
        appName: "",
        text: err?.message || "Error"
      });
    } finally {
      setUpload(false);
      setFile(null);
    }
  };
  const recordsToImport = skipExisingRecords
    ? importData?.length - existingRecordsIds?.length
    : importData?.length;
  return (
    <ImportInstrumentsDialog
      open={!!file}
      instrumentsCount={Number.isInteger(recordsToImport) ? recordsToImport : ""}
      onCancel={onCancel}
      onUploadInstruments={onUploadInstruments}
      uploading={uploading}
    />
  );
};

export default compose(
  connect(null, { loadInstruments: loadInstrumentsAction }),
  withApollo
)(UploadInstruments);
