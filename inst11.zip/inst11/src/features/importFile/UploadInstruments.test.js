import React, { useContext } from "react";
import { FileContext, FileContextWapper } from "./FileContext";
import ImportInstrumentsDialog from "./components/ImportInstrumentsDialog";
import { fireEvent, render, cleanup, waitFor } from "@testing-library/react";
import { UploadInstruments } from "./UploadInstruments";
import Notify from "../notifications/Notify";
import { updateInstrumentsBatchFlow } from "./utils/updateInstrumentsBatchFlow";
import { filterDataToImport } from "./utils/structure";

afterEach(cleanup);
jest.mock("../instruments/redux/actions");
jest.mock("./utils/updateInstrumentsBatchFlow");
jest.mock("./components/ImportInstrumentsDialog", () => {
  return {
    __esModule: true,
    default: jest.fn()
  };
});
jest.mock("./utils/structure");
jest.mock("../notifications/Notify");

const ImportInstrumentsDialogTest = ({
  onCancel,
  onUploadInstruments,
  uploading,
  instrumentsCount
}) => {
  const { file, setFile, onSkipExisingRecords, setImportData } =
    useContext(FileContext);
  return (
    <div data-testid="dialog">
      <button
        data-testid="skipExisingRecords"
        onClick={() => {
          setImportData([{}]);
          onSkipExisingRecords({
            target: {
              checked: true
            }
          });
        }}
      >
        {instrumentsCount}
      </button>
      <div data-testid="uploading">
        {uploading ? "uploading" : "not uploading"}
      </div>
      <button data-testid="cancel" onClick={onCancel}>
        {file ? "File" : "Empty"}
      </button>
      <button data-testid="setFile" onClick={() => setFile("file")}>
        setFile
      </button>
      <button
        data-testid="onUploadInstruments"
        onClick={() => onUploadInstruments()}
      >
        onUploadInstruments
      </button>
    </div>
  );
};

describe("UploadInstruments tests", () => {
  test("should call cancel callback", async () => {
    ImportInstrumentsDialog.mockImplementation(ImportInstrumentsDialogTest);
    const { getByTestId } = render(
      <FileContextWapper instruments={[]}>
        <UploadInstruments />
      </FileContextWapper>
    );
    const cancelBtn = getByTestId("cancel");
    const setFile = getByTestId("setFile");

    expect(getByTestId("dialog")).toBeInTheDocument();

    expect(cancelBtn.textContent).toEqual("Empty");
    fireEvent.click(cancelBtn);
    fireEvent.click(setFile);
    expect(cancelBtn.textContent).toEqual("File");
  });
  test("should call update successfully and show notification", async () => {
    ImportInstrumentsDialog.mockImplementation(ImportInstrumentsDialogTest);
    const mockNotify = jest.fn();
    Notify.mockImplementation(mockNotify);
    filterDataToImport.mockReturnValue([{}, {}]);
    updateInstrumentsBatchFlow.mockReturnValue(
      Promise.resolve([
        {
          status: "fulfilled",
          value: {}
        }
      ])
    );

    const { getByTestId } = render(
      <FileContextWapper instruments={[]}>
        <UploadInstruments />
      </FileContextWapper>
    );
    const onUploadInstruments = getByTestId("onUploadInstruments");
    const uploading = getByTestId("uploading");

    expect(uploading.textContent).toEqual("not uploading");
    fireEvent.click(onUploadInstruments);
    expect(uploading.textContent).toEqual("uploading");
    await waitFor(() => {
      expect(mockNotify).toHaveBeenCalledTimes(1);
      expect(mockNotify).toHaveBeenLastCalledWith({
        type: "success",
        icon: "yes",
        appName: "",
        text: `Instruments have been successfully imported(count: 1)!`
      });
      expect(uploading.textContent).toEqual("not uploading");
    });
  });
  test("should show notification that no notification was invoked", async () => {
    ImportInstrumentsDialog.mockImplementation(ImportInstrumentsDialogTest);
    const mockNotify = jest.fn();
    Notify.mockImplementation(mockNotify);
    filterDataToImport.mockReturnValue([{}, {}]);
    updateInstrumentsBatchFlow.mockReturnValue(
      Promise.resolve([
        {
          status: "fulfilled",
          value: {
            errors: []
          }
        }
      ])
    );

    const { getByTestId } = render(
      <FileContextWapper instruments={[]}>
        <UploadInstruments />
      </FileContextWapper>
    );
    const onUploadInstruments = getByTestId("onUploadInstruments");
    const uploading = getByTestId("uploading");

    expect(uploading.textContent).toEqual("not uploading");
    fireEvent.click(onUploadInstruments);
    expect(uploading.textContent).toEqual("uploading");
    await waitFor(() => {
      expect(mockNotify).toHaveBeenCalledTimes(1);
      expect(mockNotify).toHaveBeenLastCalledWith({
        type: "warning",
        icon: "caution",
        appName: "",
        text: `Instruments not have been imported(count: 1)!`
      });
      expect(uploading.textContent).toEqual("not uploading");
    });
  });

  test("should show notification with error", async () => {
    ImportInstrumentsDialog.mockImplementation(ImportInstrumentsDialogTest);
    const mockNotify = jest.fn();
    Notify.mockImplementation(mockNotify);
    filterDataToImport.mockImplementation(() => {
      throw new Error("Error message");
    });
    updateInstrumentsBatchFlow.mockReturnValue(
      Promise.resolve([
        {
          status: "fulfilled",
          value: {
            errors: []
          }
        }
      ])
    );

    const { getByTestId } = render(
      <FileContextWapper instruments={[]}>
        <UploadInstruments />
      </FileContextWapper>
    );
    const onUploadInstruments = getByTestId("onUploadInstruments");
    const uploading = getByTestId("uploading");

    expect(uploading.textContent).toEqual("not uploading");
    fireEvent.click(onUploadInstruments);
    await waitFor(() => {
      expect(mockNotify).toHaveBeenCalledTimes(1);
      expect(mockNotify).toHaveBeenLastCalledWith({
        type: "warning",
        icon: "caution",
        appName: "",
        text: `Error message`
      });
      expect(uploading.textContent).toEqual("not uploading");
    });

    filterDataToImport.mockImplementation(() => {
      throw new Error("");
    });
    fireEvent.click(onUploadInstruments);
    await waitFor(() => {
      expect(mockNotify).toHaveBeenCalledTimes(2);
      expect(mockNotify).toHaveBeenLastCalledWith({
        type: "warning",
        icon: "caution",
        appName: "",
        text: `Error`
      });
    });
  });

  test("should show skip instrument number", async () => {
    ImportInstrumentsDialog.mockImplementation(ImportInstrumentsDialogTest);
    const mockNotify = jest.fn();
    Notify.mockImplementation(mockNotify);
    filterDataToImport.mockReturnValue([{}]);
    const { getByTestId } = render(
      <FileContextWapper instruments={[]}>
        <UploadInstruments />
      </FileContextWapper>
    );
    const skipExisingRecords = getByTestId("skipExisingRecords");
    const onUploadInstruments = getByTestId("onUploadInstruments");
    const uploading = getByTestId("uploading");

    expect(uploading.textContent).toEqual("not uploading");
    expect(skipExisingRecords.textContent).toEqual("");
    fireEvent.click(onUploadInstruments);
    fireEvent.click(skipExisingRecords);
    expect(skipExisingRecords.textContent).toEqual("1");
  });
});
