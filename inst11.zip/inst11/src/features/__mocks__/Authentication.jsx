import React from "react";

const Authentication = () => <h1 data-testid="main-page-main-route">h1</h1>;

export default Authentication;
