import { waitFor } from "@testing-library/react";
import { Auth } from "aws-amplify";
import React from "react";
import { render, cleanup } from "@testing-library/react";
import Authentication from "./Authentication";

jest.mock("aws-amplify");

afterEach(cleanup);

test("welcome screen is showing", async () => {
  Auth.currentAuthenticatedUser.mockResolvedValueOnce(null);
  const { getByTestId, rerender } = render(<Authentication />);
  const loader = getByTestId("loader");
  expect(loader).toBeInTheDocument();
  await waitFor(() =>
    expect(Auth.currentAuthenticatedUser).toHaveBeenCalledTimes(1)
  );
  rerender(<Authentication />);
  const mainPageWithNoerrorBackend = getByTestId(
    "main-page-not-authenticated-with-no-error-by-backend"
  );
  expect(mainPageWithNoerrorBackend.textContent).toContain(
    "Instrument repository WelcomeYou must login to view instruments"
  );
});
test("show children for authenticated user", async () => {
  Auth.currentAuthenticatedUser.mockResolvedValueOnce({});
  const { getByTestId, rerender } = render(
    <Authentication>
      <div data-testid="it-works">works</div>
    </Authentication>
  );
  const loader = getByTestId("loader");
  expect(loader).toBeInTheDocument();
  await waitFor(() =>
    expect(Auth.currentAuthenticatedUser).toHaveBeenCalledTimes(1)
  );
  rerender(
    <Authentication>
      <div data-testid="it-works">works</div>
    </Authentication>
  );
  const mainPageWithNoerrorBackend = getByTestId("it-works");
  expect(mainPageWithNoerrorBackend.textContent).toContain("works");
});

test("catch for checking authenticated user", async () => {
  Auth.currentAuthenticatedUser.mockRejectedValueOnce(null);
  const { getByTestId, rerender } = render(<Authentication />);
  const loader = getByTestId("loader");
  expect(loader).toBeInTheDocument();
  await waitFor(() =>
    expect(Auth.currentAuthenticatedUser).toHaveBeenCalledTimes(1)
  );
  rerender(<Authentication />);
  const mainPageWithNoerrorBackend = getByTestId(
    "main-page-not-authenticated-with-no-error-by-backend"
  );
  expect(mainPageWithNoerrorBackend.textContent).toContain(
    "Instrument repository WelcomeYou must login to view instruments"
  );
});
