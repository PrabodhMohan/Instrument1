import React from "react";
import { RocheTopBar, RocheTypography } from "@one/react-kit";
import Link from "@material-ui/core/Link";
import styled from "styled-components";
import { Button } from "@material-ui/core";
import { Auth } from "aws-amplify";
import { IconWithText } from "../components/shared";
import IconForApp from "../icons/IconForApp";

const AppBarInfo = styled.div`
  display: flex;
  align-items: center;
  margin: 0 16px 0px 0px;
  color: #737373;
`;

const AppbarStyled = styled.div`
  position: relative;
  padding: 0;
  margin: 0;
  z-index: 1201;
`;
const SignInButton = styled(Button)`
  && {
    text-transform: capitalize;
    margin-right: 26px;
    font-weight: 400;
  }
`;
const CustomLink = ({ children, disabled, ...props }) => (
  <Link
    onClick={() => {
      if (disabled !== true) {
        if (
          process.env.REACT_APP_COGNITO_LOGIN_ENABLED?.trim()?.toUpperCase() !==
          "TRUE"
        ) {
          Auth.federatedSignIn({
            provider: process.env.REACT_APP_COGNITO_PROVIDER_ID
          });
        } else {
          Auth.federatedSignIn();
        }
      }
    }}
    style={{
      textDecoration: "none"
    }}
    {...props}
  >
    {children}
  </Link>
);

const AppBarNotAuth = ({ disabled = false }) => {
  return (
    <AppbarStyled data-testid="app-bar-not-auth-main-page">
      <RocheTopBar
        title={
          <IconWithText
            iconComponent={IconForApp}
            iconStyle={{ marginRight: ".6rem" }}
          >
            <RocheTypography variant="button">
              Instrument repository
            </RocheTypography>
          </IconWithText>
        }
        position="relative"
        rightIcons={[
          <CustomLink
            disabled={disabled}
            data-testid="link-to-sign-in-on-button"
          >
            <SignInButton
              data-testid="sign-in-button"
              disabled={disabled}
              color="primary"
              variant="contained"
              style={{ minWidth: "120px" }}
            >
              Sign in
            </SignInButton>
          </CustomLink>,
          <AppBarInfo>
            <i className="one-icons">help</i>
          </AppBarInfo>
        ]}
      />
    </AppbarStyled>
  );
};

export default AppBarNotAuth;
