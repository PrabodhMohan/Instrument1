import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { RocheTopBar, RocheTypography } from "@one/react-kit";
import { withApollo } from "react-apollo";
import { connect } from "react-redux";
import styled, { css } from "styled-components";
import Popover from "@material-ui/core/Popover";
import { compose } from "redux";
import { IconWithText } from "../components/shared";
import { signOut } from "../utils/signout";
import MenuItem from "@material-ui/core/MenuItem";
import { MenuList } from "@material-ui/core";
import IconForApp from "../icons/IconForApp";
import { displayNameSelector } from "../features/user/redux/selectors";

const useStyles = makeStyles((theme) => ({
  toolbar: theme.mixins.toolbar,
  popover: {
    minWidth: 218,
    minHeight: 168,
    borderRadius: 4,
    boxShadow: "0px 8px 8px 0px rgba(0,0,0,0.35)"
  }
}));

const AppBarInfo = styled.div`
  display: flex;
  align-items: center;
  margin: 0;
  margin-right: 16px;
  & > i {
    color: #737373;
  }
`;

const focusStyles = css`
  background: rgba(0, 0, 0, 0.12);
  border-radius: 4px;
`;
const AppBarUserInfo = styled(AppBarInfo)`
  padding: 8px;
  .userNameAppBar {
    margin-right: 12px;
    font-size: 12px;
    font-weight: 400;
    line-height: 14px;
    letter-spacing: 0px;
    color: #333333;
  }

  ${(props) => props.hasFocus && focusStyles}
`;

const UserLogo = styled.div`
  border-radius: 100%;
  background-color: #037b84;
  font-size: 20px;
  font-weight: 400;
  line-height: 23px;
  letter-spacing: 0px;
  width: 40px;
  height: 40px;
  max-width: 40px;
  max-height: 40px;
  min-width: 40px;
  min-height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #ffffff;
  margin-top: 16px;
  margin-bottom: 12px;
`;
const UserName = styled.div`
  font-size: 16px;
  font-weight: 400;
  line-height: 19px;
  letter-spacing: 0px;
  margin-bottom: 4px;
  text-transform: capitalize;
`;
const UserEmail = styled.div`
  font-size: 14px;
  font-weight: 400;
  line-height: 16px;
  letter-spacing: 0px;
  color: #737373;
`;
const UserInfoSection = styled.div`
  height: 119px;
  display: flex;
  flex-direction: column;
  align-items: center;
  border-bottom: 1px solid #d3d3d3;
`;
const LogoutIcon = styled.i`
  color: #737373;
  margin-right: 17px;
`;
const Appbar = ({ client, email, name }) => {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const open = Boolean(anchorEl);
  const id = open ? "simple-popover" : undefined;
  const logoLetter = email?.charAt(0);

  return (
    <>
      <RocheTopBar
        title={
          <IconWithText
            iconComponent={IconForApp}
            iconStyle={{ marginRight: ".6rem" }}
          >
            <RocheTypography variant="button" style={{ textTransform: "none" }}>
              Equipment repository
            </RocheTypography>
          </IconWithText>
        }
        id={"RocheTopBar"}
        rightIcons={[
          <AppBarUserInfo
            data-testid="app-bar-user-info-user"
            button
            hasFocus={anchorEl !== null}
            onClick={handleClick}
          >
            <span className="userNameAppBar" data-cy="app-bar-user-name">
              {name}
            </span>
            <i className="one-icons">user</i>
          </AppBarUserInfo>,
          <AppBarInfo data-testid="App-bar-user-info-help">
            <i className="one-icons">help</i>
          </AppBarInfo>
        ]}
      />
      <Popover
        data-testid="popover-user-menu"
        classes={{
          paper: classes.popover
        }}
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right"
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right"
        }}
      >
        <UserInfoSection data-testid="popover-user-menu-info-section">
          <UserLogo data-testid="popover-user-menu-info-section-logo">
            {logoLetter}
          </UserLogo>
          <UserName data-testid="popover-user-menu-info-section-username">
            {name}
          </UserName>
          <UserEmail data-testid="popover-user-menu-info-section-email">
            {email}
          </UserEmail>
          <hr />
        </UserInfoSection>
        <MenuList data-testid="popover-user-menu-footer-section">
          <MenuItem
            data-testid="popover-user-menu-footer-section-logout"
            onClick={() => {
              handleClose();
              signOut(client);
            }}
          >
            <LogoutIcon className="one-icons">log_off</LogoutIcon> Log out
          </MenuItem>
        </MenuList>
      </Popover>
      <div className={classes.toolbar} />
    </>
  );
};

const mapStateToProps = (store) => ({
  name: displayNameSelector(store),
  email: store.user.email
});

export default compose(connect(mapStateToProps), withApollo)(Appbar);
