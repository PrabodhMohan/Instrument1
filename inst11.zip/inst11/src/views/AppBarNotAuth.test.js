import React from "react";
import { render, cleanup } from "@testing-library/react";
import Appbar from "../views/AppBarNotAuth";
import { Auth } from "aws-amplify";

jest.mock("aws-amplify");

afterEach(cleanup);

test("for not mobile", () => {
  const { getByTestId } = render(<Appbar />);
  const signInButton = getByTestId("sign-in-button");
  expect(signInButton).toBeTruthy();
});
test("not disabled button for deafult parameter for sing in", () => {
  const { getByTestId } = render(<Appbar />);
  const signInButton = getByTestId("sign-in-button");
  expect(signInButton).not.toHaveAttribute("disabled");
});
test("disabled button with true parameter", () => {
  const { getByTestId } = render(<Appbar disabled={true} />);
  const signInButton = getByTestId("sign-in-button");
  expect(signInButton).toHaveAttribute("disabled");
});
test("not disabled button with false parameter", () => {
  const { getByTestId } = render(<Appbar disabled={false} />);
  const signInButton = getByTestId("sign-in-button");
  expect(signInButton).not.toHaveAttribute("disabled");
});
test("click function in link when not disabled", () => {
  const { getByTestId } = render(<Appbar disabled={false} />);
  const LinkSignInOnButton = getByTestId("link-to-sign-in-on-button");
  LinkSignInOnButton.click();
  expect(Auth.federatedSignIn).toHaveBeenCalled();
});
test("can't click function in link when disabled", () => {
  const { getByTestId } = render(<Appbar disabled={true} />);
  const LinkSignInOnButton = getByTestId("link-to-sign-in-on-button");
  LinkSignInOnButton.click();
  expect(Auth.federatedSignIn).not.toHaveBeenCalled();
});
