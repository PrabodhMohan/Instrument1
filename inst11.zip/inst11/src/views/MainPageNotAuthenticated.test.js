import React from "react";
import { render, cleanup, fireEvent } from "@testing-library/react";
import MainPageNotAuthenticated from "./MainPageNotAuthenticated";
import { useOnlineEndpointStatus } from "../utils/hooks";

afterEach(cleanup);
jest.mock("../utils/hooks");

test("should be created with connection", () => {
  useOnlineEndpointStatus.mockReturnValue(true);
  const { getByTestId } = render(<MainPageNotAuthenticated />);
  expect(
    getByTestId("main-page-not-authenticated-with-no-error-by-backend")
  ).toBeDefined();
});
test("should be show errorScreen when is error with backend connection", () => {
  useOnlineEndpointStatus.mockReturnValue(false);
  const { getByTestId } = render(<MainPageNotAuthenticated />);
  expect(
    getByTestId("main-page-not-authenticated-with-error-conection")
  ).toBeDefined();
});
test("should be relod error page after click the relod button", () => {
  delete window.location;
  window.location = {
    reload: jest.fn()
  };
  useOnlineEndpointStatus.mockReturnValue(false);
  const { getByTestId } = render(<MainPageNotAuthenticated />);
  const relodButton = getByTestId("main-page-action-button-error-conection");
  fireEvent.click(relodButton);
  expect(window.location.reload).toHaveBeenCalled();
});
