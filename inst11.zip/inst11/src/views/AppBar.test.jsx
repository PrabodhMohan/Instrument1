import { render, cleanup, fireEvent } from "../test-utils";
import Appbar from "./AppBar";
import { signOut } from "../utils/signout";

jest.mock("../utils/signout");
afterEach(cleanup);

test("appbar toggles user menu", () => {
  const { getByTestId } = render(<Appbar />);
  const userInfo = getByTestId("app-bar-user-info-user");
  fireEvent.click(userInfo);
  const popover = getByTestId("popover-user-menu");
  expect(popover).toBeDefined();
});
test("should call logout function", () => {
  const { getByTestId } = render(<Appbar />);
  const userInfo = getByTestId("app-bar-user-info-user");
  fireEvent.click(userInfo);
  const logoutItem = getByTestId("popover-user-menu-footer-section-logout");
  fireEvent.click(logoutItem);
  expect(signOut).toHaveBeenCalled();
});
