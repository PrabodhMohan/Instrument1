import React from "react";
import { render, cleanup } from "@testing-library/react";

import WelcomeScreen from "./WelcomeScreen";

afterEach(cleanup);

describe("WelcomeScreen", () => {
  test("should create", () => {
    const { getByTestId } = render(<WelcomeScreen />);
    const welcome = getByTestId(
      "main-page-not-authenticated-with-no-error-by-backend"
    );
    expect(welcome).toBeDefined();
  });
});
