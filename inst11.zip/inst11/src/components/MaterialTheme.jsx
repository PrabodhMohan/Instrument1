import React from "react";
import { ThemeProvider, createTheme } from "@material-ui/core/styles";

export const theme = createTheme({
  palette: {
    background: {
      default: "#F2F7FC"
    },
    primary: {
      main: "#0066CC"
    },
    secondary: {
      main: "#f44336"
    },
    error: {
      main: "#CC0033"
    }
  },
  props: {
    MuiWithWidth: {
      initialWidth: "lg"
    }
  },
  overrides: {
    MuiSwitch: {
      switchBase: {
        color: "#E8E8E8"
      },
      colorPrimary: {
        "&$checked": {
          // Controls checked color for the thumb
          color: "#0066CC"
        }
      },
      track: {
        opacity: 0.2,
        backgroundColor: "#fff",
        "$checked$checked + &": {
          // Controls checked color for the track
          opacity: 0.7,
          backgroundColor: "#A5D2FF"
        }
      }
    }
  }
});

const MaterialTheme = ({ children }) => {
  return <ThemeProvider theme={theme}>{children}</ThemeProvider>;
};

export default MaterialTheme;
