import React from "react";
import { render, cleanup, fireEvent } from "@testing-library/react";
import NoConnectionScreen from "./NoConnectionScreen";

afterEach(cleanup);

describe("NoConnectionScreen", () => {
  test("should create", () => {
    const { getByTestId } = render(<NoConnectionScreen />);
    const noConnection = getByTestId(
      "main-page-not-authenticated-with-error-conection"
    );
    expect(noConnection).toBeDefined();
  });

  test("should run callback on retry connection button", () => {
    const repatchTest = jest.fn();
    const { getByTestId } = render(
      <NoConnectionScreen onCallback={repatchTest} />
    );
    const noConnectionButton = getByTestId(
      "main-page-action-button-error-conection"
    );
    fireEvent.click(noConnectionButton);
    expect(repatchTest).toHaveBeenCalled();
  });
});
