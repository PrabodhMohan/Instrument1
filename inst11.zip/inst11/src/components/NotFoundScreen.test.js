import React from "react";
import { render, cleanup, fireEvent } from "@testing-library/react";
import NotFoundScreen from "./NotFoundScreen";
import { useHistory } from "react-router";

jest.mock("react-router");
afterEach(cleanup);

describe("NotFoundScreen", () => {
  test("should create", () => {
    const { getByTestId } = render(<NotFoundScreen />);
    const notFound = getByTestId(
      "main-page-not-authenticated-with-error-not-found"
    );
    expect(notFound).toBeDefined();
  });
  test("should go to home with default path", () => {
    const replace = jest.fn();
    useHistory.mockReturnValue({
      replace
    });
    const { getByTestId } = render(<NotFoundScreen />);
    const notFoundButton = getByTestId("main-page-action-button-not-found");
    fireEvent.click(notFoundButton);

    expect(replace).toHaveBeenCalled();
  });
  test("should go to home with not default path", () => {
    const replace = jest.fn();
    useHistory.mockReturnValue({
      replace
    });
    const { getByTestId } = render(<NotFoundScreen redirectPath={"/test"} />);
    const notFoundButton = getByTestId("main-page-action-button-not-found");
    fireEvent.click(notFoundButton);

    expect(replace).toHaveBeenCalledWith("/test");
  });
});
