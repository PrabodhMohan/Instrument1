import React from "react";
import styled from "styled-components";

const WelcomeScreenStyled = styled.div`
  font-family: Imago, sans-serif;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: calc(80vh - 96px);
  transform: translateY(-40px);
  color: #0066cc;
  & > h2 {
    font-size: 48px;
    font-weight: 500;
    text-align: center;
    line-height: 1.4;
    margin-bottom: 0;
    & > span {
      font-weight: 400;
    }
  }
  & > h5 {
    font-size: 18px;
    color: #333;
  }
`;

const WelcomeScreen = ({ text = "You must login to view instruments" }) => {
  return (
    <WelcomeScreenStyled data-testid="main-page-not-authenticated-with-no-error-by-backend">
      <h2>
        Instrument repository
        <br /> <span>Welcome</span>
      </h2>
      <h5>{text}</h5>
    </WelcomeScreenStyled>
  );
};

export default WelcomeScreen;
