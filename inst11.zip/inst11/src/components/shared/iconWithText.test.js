import React from "react";
import { render, cleanup, fireEvent } from "@testing-library/react";
import { IconWithText } from "./iconWithText";

afterEach(cleanup);

test("should create IconWithText with icon, iconStyle and children and should click", () => {
  const onClick = jest.fn();
  const { getByTestId } = render(
    <IconWithText
      icon="home"
      iconStyle={{ marginRight: ".6rem" }}
      onClick={onClick}
    >
      <div data-testid="test-children">test</div>
    </IconWithText>
  );
  fireEvent.click(getByTestId("app-icon-with-text-icon"));
  expect(getByTestId("app-icon-with-text-icon").textContent).toBe("home");
  expect(getByTestId("test-children").textContent).toBe("test");
  expect(getByTestId("app-icon-with-text-icon").style.marginRight).toBe(
    ".6rem"
  );
  expect(onClick).toHaveBeenCalled();
});
test("should create IconWithText without iconStyle and  onClick method", () => {
  const { getByTestId } = render(
    <IconWithText icon="home">
      <div data-testid="test-children">test</div>
    </IconWithText>
  );
  fireEvent.click(getByTestId("app-icon-with-text-icon"));
  expect(getByTestId("app-icon-with-text-icon").textContent).toBe("home");
  expect(getByTestId("test-children").textContent).toBe("test");
  expect(getByTestId("app-icon-with-text-icon").style._values).toEqual({});
});
test("should create IconWithText with iconComponent, iconStyle and children and should click", () => {
  const onClick = jest.fn();
  const iconComponenttest = ({ ...props }) => (
    <div data-testid="icon-component" {...props}>
      icon component
    </div>
  );
  const { getByTestId } = render(
    <IconWithText
      iconComponent={iconComponenttest}
      iconStyle={{ marginRight: ".6rem" }}
      onClick={onClick}
    >
      <div data-testid="test-children">test</div>
    </IconWithText>
  );
  const iconComponentElement = getByTestId("icon-component");
  expect(iconComponentElement).toBeDefined();
  fireEvent.click(iconComponentElement);
  expect(iconComponentElement.textContent).toBe("icon component");
  expect(getByTestId("test-children").textContent).toBe("test");
  expect(iconComponentElement.style.marginRight).toBe(".6rem");
  expect(onClick).toHaveBeenCalled();
});
test("should create IconWithText without iconComponent or icon and with children", () => {
  const { getByTestId, queryByTestId } = render(
    <IconWithText>
      <div data-testid="test-children">test</div>
    </IconWithText>
  );
  expect(getByTestId("test-children").textContent).toBe("test");
  expect(queryByTestId("app-icon-with-text-icon")).toBe(null);
});
