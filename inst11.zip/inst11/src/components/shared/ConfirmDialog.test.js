import React from "react";
import { render, cleanup, fireEvent } from "@testing-library/react";
import ConfirmDialog from "./ConfirmDialog";

afterEach(cleanup);

test("should create confirm dialog with inputs-  title, content, names of buttons and colors and calls cancel and close function", () => {
  const onCancel = jest.fn();
  const onApprove = jest.fn();
  const close = jest.fn();

  const { getByTestId } = render(
    <ConfirmDialog
      title={"test title"}
      content={"test contet"}
      cancelText={"cancel text"}
      approveText={"approve Text"}
      cancelVariant={"outlined"}
      cancelColor={"primary"}
      approveColor={"error"}
      approveVariant={"contained"}
      onCancel={onCancel}
      onApprove={onApprove}
      close={close}
      open={true}
    />
  );
  expect(getByTestId("confirm-dialog-title").textContent.trim()).toBe(
    "test title"
  );
  expect(getByTestId("confirm-dialog-content-text").textContent.trim()).toBe(
    "test contet"
  );
  const cancelButton = getByTestId("confirm-dialog-actions-button-cancel");
  expect(cancelButton.textContent.trim()).toBe("cancel text");
  expect(
    getByTestId("confirm-dialog-actions-button-approve").textContent.trim()
  ).toBe("approve Text");
  fireEvent.click(cancelButton);
  expect(onCancel).toHaveBeenCalled();
  expect(close).toHaveBeenCalled();
});
test("should create confirm dialog with inputs- names of buttons and colors and calls approve and close function and with default text for it", () => {
  const onCancel = jest.fn();
  const onApprove = jest.fn();
  const close = jest.fn();

  const { getByTestId } = render(
    <ConfirmDialog
      cancelText={"cancel text"}
      approveText={"approve Text"}
      cancelVariant={"outlined"}
      cancelColor={"primary"}
      approveColor={"error"}
      approveVariant={"contained"}
      onCancel={onCancel}
      onApprove={onApprove}
      close={close}
      open={true}
    />
  );
  expect(getByTestId("confirm-dialog-title").textContent.trim()).toBe("");
  expect(getByTestId("confirm-dialog-content-text").textContent.trim()).toBe(
    ""
  );
  const approveButton = getByTestId("confirm-dialog-actions-button-approve");
  expect(
    getByTestId("confirm-dialog-actions-button-cancel").textContent.trim()
  ).toBe("cancel text");
  expect(approveButton.textContent.trim()).toBe("approve Text");
  fireEvent.click(approveButton);
  expect(onApprove).toHaveBeenCalled();
  expect(close).toHaveBeenCalled();
});
test.skip("should create confirm dialog without inputs- names of buttons ", () => {
  const onCancel = jest.fn();
  const onApprove = jest.fn();
  const close = jest.fn();

  const { getByTestId } = render(
    <ConfirmDialog
      cancelVariant={"outlined"}
      cancelColor={"primary"}
      approveColor={"error"}
      approveVariant={"contained"}
      onCancel={onCancel}
      onApprove={onApprove}
      close={close}
      open={true}
    />
  );
  const approveButton = getByTestId("confirm-dialog-actions-button-approve");
  expect(
    getByTestId("confirm-dialog-actions-button-cancel").textContent.trim()
  ).toBe("");
  expect(approveButton.textContent.trim()).toBe("");
  fireEvent.click(approveButton);
  expect(onApprove).toHaveBeenCalled();
  expect(close).toHaveBeenCalled();
});
test.skip("should create confirm dialog without inputs- names of buttons and funcion onApprove", () => {
  const onCancel = jest.fn();
  const close = jest.fn();

  const { getByTestId } = render(
    <ConfirmDialog
      cancelVariant={"outlined"}
      cancelColor={"primary"}
      approveColor={"error"}
      approveVariant={"contained"}
      onCancel={onCancel}
      close={close}
      open={true}
    />
  );
  const approveButton = getByTestId("confirm-dialog-actions-button-approve");
  expect(
    getByTestId("confirm-dialog-actions-button-cancel").textContent.trim()
  ).toBe("");
  expect(approveButton.textContent.trim()).toBe("");
  fireEvent.click(approveButton);
  expect(close).toHaveBeenCalled();
});
test.skip("should create confirm dialog without inputs- names of buttons and funcion onclose", () => {
  const close = jest.fn();

  const { getByTestId } = render(
    <ConfirmDialog
      cancelVariant={"outlined"}
      cancelColor={"primary"}
      approveColor={"error"}
      approveVariant={"contained"}
      close={close}
      open={true}
    />
  );
  const cancelButton = getByTestId("confirm-dialog-actions-button-cancel");
  expect(
    getByTestId("confirm-dialog-actions-button-approve").textContent.trim()
  ).toBe("");
  expect(cancelButton.textContent.trim()).toBe("");
  fireEvent.click(cancelButton);
  expect(close).toHaveBeenCalled();
});

test.skip("should render content as children component", () => {
  const close = jest.fn();
  const ContentComponent = () => (
    <div data-testid="content-component">ContentComponent</div>
  );
  const { getByTestId } = render(
    <ConfirmDialog
      cancelVariant={"outlined"}
      cancelColor={"primary"}
      approveColor={"error"}
      approveVariant={"contained"}
      close={close}
      open={true}
    >
      <ContentComponent />
    </ConfirmDialog>
  );
  expect(getByTestId("content-component")).toBeInTheDocument();
  const cancelButton = getByTestId("confirm-dialog-actions-button-cancel");
  fireEvent.click(cancelButton);
  expect(close).toHaveBeenCalled();
});

test("should render divider and custom actions elements", () => {
  const close = jest.fn();
  const ContentComponent = () => (
    <div data-testid="content-component">ContentComponent</div>
  );
  const ActionsComponent = () => (
    <div data-testid="actions-component">ActionsComponent</div>
  );
  const { getByTestId } = render(
    <ConfirmDialog
      cancelVariant={"outlined"}
      cancelColor={"primary"}
      approveColor={"error"}
      approveVariant={"contained"}
      close={close}
      open={true}
      renderActions={ActionsComponent}
      isDivider={true}
    >
      <ContentComponent />
    </ConfirmDialog>
  );
  expect(getByTestId("content-component")).toBeInTheDocument();
  expect(getByTestId("divider")).toBeInTheDocument();
  expect(getByTestId("actions-component")).toBeInTheDocument();
});
