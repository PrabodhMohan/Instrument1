import { fireEvent } from "@testing-library/react";
import React from "react";
import { render } from "../../test-utils";
import Table from "./Table";

describe("Custom table tests", () => {
  test("should render nothing", () => {
    const { container } = render(<Table />);
    expect(container.children.length).toBe(0);
  });
  test("should render nothing if either fields or data are not provided", () => {
    const { container, rerender } = render(<Table meta={{}} />);
    expect(container.children.length).toBe(0);
    rerender(<Table meta={{ fields: {} }} data={null} />);
    expect(container.children.length).toBe(0);
  });

  test("should render no data information data are not provided", () => {
    const { getByTestId } = render(
      <Table meta={{ fields: { name: { text: "Name" } } }} />
    );
    expect(getByTestId(`table-head-name`)).toBeDefined();
    expect(getByTestId(`custom-table-no-data`).textContent).toEqual("No data");
  });
  test("should render table with primitive data", () => {
    // arrange
    const data = [
      {
        id: 1,
        name: "TEST.456"
      },
      {
        id: 2,
        name: "TEST.454"
      }
    ];
    const meta = {
      fields: {
        id: {
          text: "Id"
        },
        name: {
          text: "name"
        }
      },
      rowId: "id"
    };
    // act
    const { getByTestId } = render(<Table data={data} meta={meta} />);
    const customTable = getByTestId("custom-table");
    // assert
    expect(customTable).toBeDefined();
    expect(getByTestId("2-row")).toBeDefined();
    expect(getByTestId("item-row-2-name")).toBeDefined();
  });
  test("should render table with component as data", () => {
    // arrange
    const data = [
      {
        id: 1,
        bookable: false
      },
      {
        id: 2,
        name: "TEST.456",
        bookable: true
      }
    ];
    const meta = {
      fields: {
        name: {
          text: "name"
        },
        bookable: {
          component: ({ item }) => (
            <span data-testid={`custom-${item?.id}`}>
              {item?.bookable ? "yes" : "no"}
            </span>
          )
        }
      },
      rowId: "id"
    };
    // act
    const { getByTestId, container } = render(
      <Table data={data} meta={meta} />
    );
    const customTable = getByTestId("custom-table");
    // assert
    expect(customTable).toBeDefined();
    expect(getByTestId("1-row")).toBeDefined();
    expect(container.querySelector(`[data-testid="item-row-1-id"]`)).toBe(null);
    expect(
      container.querySelector(`[data-testid="item-row-1-name"]`)
    ).toBeDefined();
    expect(getByTestId("item-row-1-name").textContent).toBe("-");
    expect(getByTestId("custom-1")).toBeDefined();
    expect(getByTestId("custom-1").textContent).toBe("no");
  });
  test("should render table and sort column", () => {
    // arrange
    const onRequestSort = jest.fn();
    const isReverseOrder = true;
    const orderBy = "id";
    const data = [
      {
        id: 1,
        name: "TEST.456"
      },
      {
        id: 2,
        name: "TEST.454"
      }
    ];
    const meta = {
      fields: {
        id: {
          text: "Id",
          sortable: true
        },
        name: {
          text: "name",
          sortable: true
        }
      },
      rowKeyId: "id"
    };
    // act
    const { getByTestId, queryByTestId, rerender } = render(
      <Table
        data={data}
        meta={meta}
        onRequestSort={onRequestSort}
        isReverseOrder={isReverseOrder}
        orderBy={orderBy}
      />
    );
    const headerNameColumn = getByTestId("table-head-name");
    fireEvent.click(headerNameColumn);
    expect(onRequestSort).toHaveBeenCalledWith("name", false);
    const idHeaderNameColumn = getByTestId("table-head-id");
    fireEvent.click(idHeaderNameColumn);
    expect(onRequestSort).toHaveBeenCalledWith("id", !isReverseOrder);
    expect(queryByTestId("arrow-drop-down-up-icon")).not.toBe(null);
    expect(queryByTestId("arrow-drop-down-down-icon")).toBe(null);
    rerender(
      <Table
        data={data}
        meta={meta}
        onRequestSort={onRequestSort}
        isReverseOrder={!isReverseOrder}
        orderBy={orderBy}
      />
    );
    expect(queryByTestId("arrow-drop-down-up-icon")).toBe(null);
    expect(queryByTestId("arrow-drop-down-down-icon")).not.toBe(null);
  });
  test("should render table with headComponent", () => {
    // arrange
    const headComponent = () => (
      <div data-testid="head-component">headcomponent</div>
    );
    const data = [
      {
        id: 1,
        name: "TEST.456"
      },
      {
        id: 2,
        name: "TEST.454"
      }
    ];
    const meta = {
      fields: {
        id: {
          text: "Id"
        },
        name: {
          HeadCellComponent: headComponent
        }
      },
      rowKeyId: "id"
    };
    // act
    const { getByTestId } = render(<Table data={data} meta={meta} />);
    const headerComponent = getByTestId("head-component");
    expect(headerComponent).toBeDefined();
  });
});
