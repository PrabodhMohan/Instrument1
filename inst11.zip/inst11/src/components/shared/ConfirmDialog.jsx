import React, { useMemo } from "react";
import {
  Button,
  createTheme,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Divider,
  ThemeProvider
} from "@material-ui/core";
import styled, { css } from "styled-components";
import Slide from "@material-ui/core/Slide";
import { theme as materialTheme } from "../MaterialTheme";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const outlinedStyles = css`
  background-color: #fafafa;
  border: 1px solid #bababa;
`;

export const ActionbuttonStyled = styled(Button)`
  && {
    margin-right: 16px;
    text-transform: capitalize;
    ${(props) =>
      props.variant && props.variant === "outlined" && outlinedStyles}
  }
`;

export const ConfirmDialog = ({
  testid = "confirm-dialog",
  title = "",
  content = "",
  cancelText,
  approveText,
  cancelVariant,
  cancelColor,
  approveColor,
  approveVariant,
  onCancel,
  onApprove,
  close,
  open,
  children,
  renderActions,
  isDivider = false
}) => {
  const handleCancel = () => {
    close();
    if (onCancel) {
      onCancel();
    }
  };
  const handleApprove = () => {
    close();
    if (onApprove) {
      onApprove();
    }
  };
  const theme = useMemo(
    () =>
      createTheme({
        palette: {
          primary: materialTheme.palette[approveColor],
          secondary: materialTheme.palette[cancelColor]
        }
      }),
    [approveColor, cancelColor]
  );
  return (
    <Dialog
      open={open}
      TransitionComponent={Transition}
      keepMounted
      onClose={handleCancel}
      data-testid={testid}
      fullWidth
    >
      <DialogTitle data-testid="confirm-dialog-title">{title}</DialogTitle>
      {isDivider && <Divider data-testid="divider" />}
      <DialogContent data-testid="confirm-dialog-content">
        {children ? (
          children
        ) : (
          <DialogContentText data-testid="confirm-dialog-content-text">
            {content}
          </DialogContentText>
        )}
      </DialogContent>
      <DialogActions data-testid="confirm-dialog-actions">
        <ThemeProvider theme={theme}>
          {typeof renderActions === "function" ? (
            renderActions({
              cancelColor,
              cancelVariant,
              approveColor,
              approveVariant,
              cancelText,
              approveText,
              close
            })
          ) : (
            <>
              {cancelText && (
                <ActionbuttonStyled
                  data-testid="confirm-dialog-actions-button-cancel"
                  onClick={handleCancel}
                  color={cancelColor && "secondary"}
                  variant={cancelVariant}
                >
                  {cancelText || null}
                </ActionbuttonStyled>
              )}
              {approveText && (
                <ActionbuttonStyled
                  data-testid="confirm-dialog-actions-button-approve"
                  onClick={handleApprove}
                  color={approveColor && "primary"}
                  variant={approveVariant}
                >
                  {approveText || null}
                </ActionbuttonStyled>
              )}
            </>
          )}
        </ThemeProvider>
      </DialogActions>
    </Dialog>
  );
};
export default ConfirmDialog;
