const ConfirmDialog = ({ open, onCancel, onApprove }) => (
  <div data-testid="app-confirm-dialog">
    <div data-testid="app-confirm-dialog-is-open">
      {open ? "open" : "close"}
    </div>
    <button data-testid="app-confirm-dialog-cancel" onClick={onCancel}></button>
    <button
      data-testid="app-confirm-dialog-approve"
      onClick={onApprove}
    ></button>
  </div>
);

export default ConfirmDialog;
