import { render, cleanup, fireEvent } from "@testing-library/react";
import { InfoWithCallback } from "./InfoWithCallback";

afterEach(cleanup);

test("should render InfoWithCallback wwith default props", () => {
  const callback = jest.fn();
  const { getByTestId } = render(<InfoWithCallback callback={callback} />);
  const container = getByTestId("InfoWithCallback-container");
  expect(container).toBeInTheDocument();
  expect(window.getComputedStyle(container).flexDirection).toEqual("column");
  fireEvent.click(getByTestId("InfoWithCallback-button"));
  expect(getByTestId("InfoWithCallback-button").textContent).toEqual("Retry");
  expect(callback).toBeCalled();
  expect(getByTestId("InfoWithCallback-title").textContent).toEqual(
    "Cannot fetch data"
  );
});

test("should render InfoWithCallback with provided props", () => {
  const title = "Title";
  const buttonLabel = "Refetch";
  const callback = jest.fn();
  const containerProps = { style: { flexDirection: "row" } };
  const titleProps = { variant: "h3" };
  const buttonProps = { varinat: "outlined" };
  const { getByTestId } = render(
    <InfoWithCallback
      callback={callback}
      title={title}
      buttonLabel={buttonLabel}
      containerProps={containerProps}
      titleProps={titleProps}
      buttonProps={buttonProps}
    />
  );
  const container = getByTestId("InfoWithCallback-container");
  expect(container).toBeInTheDocument();
  expect(window.getComputedStyle(container).flexDirection).toEqual("row");
  fireEvent.click(getByTestId("InfoWithCallback-button"));
  expect(getByTestId("InfoWithCallback-button").textContent).toEqual("Refetch");
  expect(callback).toBeCalled();
  expect(getByTestId("InfoWithCallback-title").textContent).toEqual("Title");
});
