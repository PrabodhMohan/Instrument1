import React, { useState } from "react";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableContainer from "@material-ui/core/TableContainer";
import TableFooter from "@material-ui/core/TableFooter";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import styled from "styled-components";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import ArrowDropUpIcon from "@material-ui/icons/ArrowDropUp";
import { makeStyles } from "@material-ui/core/styles";
import { pick } from "underscore";
import Collapse from "@material-ui/core/Collapse";
import Box from "@material-ui/core/Box";
import Typography from "@material-ui/core/Typography";
import { Tooltip, withStyles } from "@material-ui/core";
import { map } from "lodash";
import {
  getStringCapitalized,
  changeDateFormat
} from "../../utils/helpers/text/index";
import PaginationActions from "../../features/instruments/instrument-repository-pagination/PaginationActions";
import { CircularProgress } from "@material-ui/core";
import { connect } from "react-redux";

export const CustomTypography = withStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap"
  }
}))(Typography);

const Cell = styled.div`
  display: flex;
  align-items: center;
`;

const CustomCell = styled.div`
  width: 150px;
  align-items: center;
  margin-right: 12px;
  margin-bottom: 12px;
  font-size: 14px;
  font-weight: 400;
  color: #333333;
`;

const CellValue = styled.div`
  font-weight: 500;
  max-width: 140px;
  overflow: hidden;
  text-overflow: ellipsis;
  -webkit-line-clamp: 1;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  word-break: break-all;
`;

const CellKey = styled.div`
  display: flex;
`;

export const CustomTooltip = withStyles((theme) => ({
  tooltip: {
    width: "280",
    minWidth: "auto",
    fontFamily: "Roboto, sans-serif",
    fontWeight: 400,
    lineHeight: "19px",
    padding: 15,
    backgroundColor: "#ffffff",
    color: "#000000",
    fontSize: theme.typography.pxToRem(12),
    boxShadow: "0px 12px 24px rgba(0, 0, 0, 0.301961)",
    wordBreak: "break-word"
  }
}))(Tooltip);

const TableStyled = styled.div`
  margin-top: 1rem;
  padding: 0;
  border-radius: 0.25rem 0.25rem 0 0;
  overflow: hidden;
  border-width: 1px 1px 0 1px;
  border-style: solid;
  border-color: ${(props) => props.theme.table.borderColor};
  & thead {
    background-color: ${(props) => props.theme.table.header.backgroundColor};
  }
  & tfoot {
    display: flex;
    justify-content: flex-end;
    width: 100%;
  }
  & th {
    color: ${(props) => props.theme.table.color};
    font-weight: 400;
    line-height: 1rem;
    padding: 0.75rem 1rem;
    font-size: 0.875rem;
  }
  & tr > td {
    background-color: ${(props) => props.theme.table.cell.backgroundColor};
    color: ${(props) => props.theme.table.color};
    font-weight: 500;
    line-height: 1.125rem;
    padding: 0.5px;
    padding-left: 1rem;
    font-size: 0.875rem;
    text-overflow: ellipsis;
    max-width: 12.5rem;
    overflow: hidden;
    height: auto !important;
  }

  & .nodata {
    display: flex;
    justify-content: center;
    background: #ffffff;
    padding: 10px;
    font-size: 18px;
  }
`;

const useStyles = makeStyles(() => ({
  container: {
    overflow: "auto",
    maxHeight: "50vh"
  }
}));

const RegularCell = styled.div`
  display: flex;
  align-items: center;
`;
const FalseAnswerSpan = styled.span`
  color: #737373;
`;

const getId = (item, keys) => {
  const _keys = Array.isArray(keys) ? keys : [keys];
  const idObj = pick(item, ..._keys);
  return Object.values(idObj).join("");
};

const isObject = (item) => typeof item === "object" && item !== null;

const DisplaySortingArrow = ({ keySort, orderBy, isReverseOrder }) => {
  if (keySort !== orderBy) {
    return <ArrowDropDownIcon />;
  }
  return isReverseOrder ? (
    <ArrowDropUpIcon data-testid="arrow-drop-down-up-icon" color="primary" />
  ) : (
    <ArrowDropDownIcon
      data-testid="arrow-drop-down-down-icon"
      color="primary"
    />
  );
};

const handleSort = ({ onRequestSort, keySort, orderBy, isReverseOrder }) => {
  if (keySort === orderBy) {
    onRequestSort(keySort, !isReverseOrder);
  } else {
    onRequestSort(keySort, false);
  }
};

const CustomTable = ({
  meta,
  data = [],
  fieldArray,
  onRequestSort,
  isReverseOrder,
  orderBy,
  loading
}) => {
  const classes = useStyles();
  if (!isObject(meta)) return null;
  if (!isObject(meta?.fields)) return null;
  if (!Array.isArray(data)) return null;
  return (
    <TableStyled data-testid="custom-table">
      <TableContainer className={classes.container} sx={{ maxHeight: 600 }}>
        <Table
          stickyHeader
          className={classes.header}
          aria-label="simple table"
        >
          <TableHead>
            <TableRow>
              {Object.keys(meta.fields).map((key) => {
                const HeadCellComponent =
                  meta.fields[key]?.HeadCellComponent ?? Cell;
                return meta.fields[key]?.sortable ? (
                  <TableCell
                    style={{ backgroundColor: `#EFEFEF` }}
                    data-testid={`table-head-${key}`}
                    key={key}
                    align={meta?.[key]?.prop?.align ?? "left"}
                    onClick={() =>
                      handleSort({
                        onRequestSort,
                        orderBy,
                        isReverseOrder,
                        keySort: key
                      })
                    }
                  >
                    <HeadCellComponent>
                      {meta?.fields?.[key]?.text}
                      <DisplaySortingArrow
                        keySort={key}
                        orderBy={orderBy}
                        isReverseOrder={isReverseOrder}
                      />
                    </HeadCellComponent>
                  </TableCell>
                ) : (
                  <TableCell
                    style={{ backgroundColor: `#EFEFEF` }}
                    data-testid={`table-head-${key}`}
                    key={key}
                    align={meta?.[key]?.prop?.align ?? "left"}
                  >
                    <HeadCellComponent>
                      {meta?.fields?.[key]?.text}
                    </HeadCellComponent>
                  </TableCell>
                );
              })}
            </TableRow>
          </TableHead>
          <TableBody>
            {data.length === 0 && !loading
              ? ""
              : !loading &&
                data.map((item) => {
                  const _id = getId(item, meta?.rowId);
                  return (
                    <ItemRow
                      item={item}
                      key={_id ?? item?.id}
                      id={_id ?? item?.id}
                      fields={meta?.fields}
                      fieldArray={fieldArray}
                    />
                  );
                })}
          </TableBody>
        </Table>
      </TableContainer>
      <TableFooter style={{ display: "flex", flexDirection: "column" }}>
        <>
          <div>
            {loading ? (
              <div
                className="loading"
                style={{
                  height: 200,
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center"
                }}
              >
                <CircularProgress size={30} />
              </div>
            ) : (
              ""
            )}
          </div>
          <div>
            {data.length === 0 && !loading ? (
              <div className="nodata" data-testid="custom-table-no-data">
                No data
              </div>
            ) : (
              ""
            )}
          </div>
          <PaginationActions />
        </>
      </TableFooter>
    </TableStyled>
  );
};

export const ItemRow = ({ item, fieldArray, fields, id }) => {
  item.isExpanded = false;
  const [collapseOpen, setCollapseOpen] = useState(item.isExpanded);
  const triggerSetCollapse = (val) => {
    setCollapseOpen(val);
  };
  const gxpDropCheck = [
    "csv",
    "electronicSignatures",
    "electronicRecord",
    "gxpRelevant",
    "instrumentGxPStatus"
  ];

  const valCheck = (key, item) => {
    if (
      typeof item[key] === "object" &&
      item[key] !== null &&
      item[key]?.value !== null &&
      item[key]?.value !== "" &&
      !Array.isArray(item[key]) &&
      !Array.isArray(item[key].value)
    ) {
      if (key === "dateOfNextMaintanance") {
        return (
          <span>
            {item?.dateOfNextMaintanance?.value
              ? changeDateFormat(item?.dateOfNextMaintanance?.value)
              : "-"}
          </span>
        );
      }
      if (key === "dateOfLastMaintanance") {
        return (
          <span>
            {item?.dateOfLastMaintanance?.value
              ? changeDateFormat(item?.dateOfLastMaintanance?.value)
              : "-"}
          </span>
        );
      }
      return item[key]?.value;
    } else if (
      typeof item[key] === "string" &&
      item[key] !== null &&
      item[key] !== "" &&
      !Array.isArray(item[key])
    ) {
      if (key === "dateOfNextPeriodicReview") {
        return (
          <span>
            {item?.dateOfNextPeriodicReview
              ? changeDateFormat(item?.dateOfNextPeriodicReview)
              : "-"}
          </span>
        );
      }
      if (gxpDropCheck.includes(key)) {
        return getStringCapitalized(item[key])?.replace(/ /g, "_");
      }
      return item[key];
    } else if (
      typeof item[key] === "boolean" &&
      item[key] !== null &&
      item[key] !== "" &&
      !Array.isArray(item[key])
    ) {
      if (key === "isBookable") {
        return item.isBookable ? (
          <RegularCell>Yes</RegularCell>
        ) : (
          <RegularCell>
            <FalseAnswerSpan>No</FalseAnswerSpan>
          </RegularCell>
        );
      } else {
        return item[key] ? "Shown" : "Not shown";
      }
    } else if (Array.isArray(item[key])) {
      return map(item[key], "value")?.join(",") || "-";
    } else if (Array.isArray(item[key]?.value) && item[key]?.value.length > 0) {
      let strName = "name: ";
      let strDocument = "documentId: ";
      let strNameDocIdTooltip = "";
      item[key]?.value.forEach((CurrentVal, index) => {
        strName = strName + CurrentVal.name;
        strDocument = strDocument + CurrentVal.documentId;
        strNameDocIdTooltip =
          strNameDocIdTooltip + CurrentVal.name + " " + CurrentVal.documentId;
        if (index < item[key]?.value.length - 1) {
          strName += ", ";
          strDocument += ", ";
          strNameDocIdTooltip += ", ";
        }
      });
      return [strName, strDocument, strNameDocIdTooltip];
    } else if (Array.isArray(item[key]) && item[key].length > 0) {
      let strName = "name: ";
      let strVersion = "version: ";
      let strNameVersionTooltip = "";
      item[key].forEach((CurrentVal, index) => {
        strName = strName + CurrentVal.name;
        strVersion = strVersion + CurrentVal.version;
        strNameVersionTooltip =
          strNameVersionTooltip + CurrentVal.name + " " + CurrentVal.version;
        if (index < item[key].length - 1) {
          strName += ", ";
          strVersion += ", ";
          strNameVersionTooltip += ", ";
        }
      });
      return [strName, strVersion, strNameVersionTooltip];
    } else {
      return "-";
    }
  };

  return (
    <>
      <TableRow data-testid={`${id}-row`}>
        {Object.keys(fields).map((field) => {
          const Component = fields?.[field]?.component
            ? fields?.[field].component
            : null;
          if (!Component)
            return (
              <TableCell
                align="left"
                key={`item-row-${id}-${field}`}
                data-testid={`item-row-${id}-${field}`}
                className="itemRow"
              >
                <Cell>
                  {(() => {
                    if (
                      item[field]?.value !== null &&
                      item[field]?.value !== "" &&
                      item[field]?.value !== undefined
                    ) {
                      return item[field]?.value;
                    } else if (
                      item[field] !== null &&
                      item[field] !== "" &&
                      typeof item[field] === "string"
                    ) {
                      return item[field];
                    } else {
                      return "-";
                    }
                  })()}
                </Cell>
              </TableCell>
            );
          return (
            <TableCell
              align="left"
              key={`item-row-${id}-${field}`}
              data-testid={`item-row-${id}-${field}`}
            >
              <Component
                item={item}
                {...(field?.prop ?? {})}
                triggerSetCollapse={triggerSetCollapse}
              />
            </TableCell>
          );
        })}
      </TableRow>

      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={9}>
          <Collapse in={collapseOpen}>
            {collapseOpen ? (
              <Box margin={1}>
                <CustomTypography variant="h6" gutterBottom component="div">
                  {fieldArray.map((label, index) => {
                    return (
                      <CustomCell>
                        <CellKey>
                          <CustomTooltip
                            title={label.val}
                            placement="bottom-start"
                          >
                            <div
                              style={{
                                maxWidth: 140,
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                                WebkitLineClamp: 1,
                                display: "-webkit-box",
                                WebkitBoxOrient: "vertical",
                                wordBreak: "break-all"
                              }}
                            >
                              {label.val}
                            </div>
                          </CustomTooltip>
                          <div>:</div>
                        </CellKey>

                        <CellValue>
                          {(() => {
                            if (label.key === "installedTests") {
                              return (
                                <>
                                  <CustomTooltip
                                    title={
                                      item?.installedTests?.length > 0
                                        ? item?.installedTests?.length
                                        : "-"
                                    }
                                    placement="bottom-start"
                                  >
                                    <CellValue>
                                      {item?.installedTests?.length > 0
                                        ? item?.installedTests?.length
                                        : "-"}
                                    </CellValue>
                                  </CustomTooltip>
                                </>
                              );
                            } else if (label.key === "qualificationDocuments") {
                              return (
                                <>
                                  <CustomTooltip
                                    title={
                                      item?.qualificationDocuments?.value
                                        ?.length > 0
                                        ? item?.qualificationDocuments?.value
                                            ?.length
                                        : "-"
                                    }
                                    placement="bottom-start"
                                  >
                                    <CellValue>
                                      {item?.qualificationDocuments?.value
                                        ?.length > 0
                                        ? item?.qualificationDocuments?.value
                                            ?.length
                                        : "-"}
                                    </CellValue>
                                  </CustomTooltip>
                                </>
                              );
                            } else {
                              return (
                                <CustomTooltip
                                  title={valCheck(label.key, item)}
                                  placement="bottom-start"
                                >
                                  <CellValue>
                                    {valCheck(label.key, item)}
                                  </CellValue>
                                </CustomTooltip>
                              );
                            }
                          })()}
                        </CellValue>
                      </CustomCell>
                    );
                  })}
                </CustomTypography>
              </Box>
            ) : (
              <></>
            )}
          </Collapse>
        </TableCell>
      </TableRow>
    </>
  );
};

const mapStateToProps = (state) => ({
  loading: state.instruments.loading
});

export default connect(mapStateToProps)(CustomTable);
