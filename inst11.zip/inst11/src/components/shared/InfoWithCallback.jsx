import { Button, Typography } from "@material-ui/core";
import styled from "styled-components";

const InfoStyled = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 15px;
`;

export const InfoWithCallback = ({
  title = "Cannot fetch data",
  buttonLabel = "Retry",
  callback,
  containerProps = null,
  titleProps = null,
  buttonProps = null
}) => {
  return (
    <InfoStyled data-testid="InfoWithCallback-container" {...containerProps}>
      <Typography
        data-testid="InfoWithCallback-title"
        variant="h6"
        gutterBottom
        {...titleProps}
      >
        {title}
      </Typography>
      <Button
        data-testid="InfoWithCallback-button"
        variant="contained"
        color="secondary"
        onClick={() => typeof callback === "function" && callback()}
        {...buttonProps}
      >
        {buttonLabel}
      </Button>
    </InfoStyled>
  );
};
