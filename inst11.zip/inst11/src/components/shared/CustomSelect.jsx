import React from "react";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import { FormHelperText } from "@material-ui/core";

export const IconStyle = {
  position: "absolute",
  marginTop: "-43px",
  marginLeft: "176px",
  color: "blue"
};

export const CustomSelect = ({
  options,
  value,
  propLabel,
  propValue,
  onChange,
  testid,
  name,
  selectLabel,
  emptyOption = false,
  multiple = false,
  helperText,
  SelectProps,
  error,
  renderValue = undefined,
  ...rest
}) => {
  return (
    <>
      <FormControl variant="filled" error={error} {...rest}>
        <InputLabel id={testid}>{selectLabel}</InputLabel>
        <Select
          labelId={testid}
          data-testid={testid}
          id={testid}
          multiple={multiple}
          value={value}
          onChange={onChange}
          name={name}
          style={{
            backgroundColor: "#f5f5f5",
            height: "48px"
          }}
          renderValue={renderValue}
          {...SelectProps}
        >
          {emptyOption && <MenuItem value="">Select all</MenuItem>}
          {options?.map((item) => {
            const option = propValue
              ? multiple
                ? item
                : item?.[propValue]
              : item;
            return (
              <MenuItem value={option} key={option}>
                {propLabel ? item?.[propLabel] : item}
              </MenuItem>
            );
          })}
        </Select>
        {error ? (
          <FormHelperText error={error}>{`*${helperText}`}</FormHelperText>
        ) : null}
      </FormControl>
    </>
  );
};

export default CustomSelect;
