import React from "react";
import { render as rtlRender } from "@testing-library/react";
import { Provider } from "react-redux";
import configureStore from "./store/configureStore";
import { MockedProvider } from "react-apollo/test-utils";
import { ApolloConsumer } from "react-apollo";
import MaterialTheme from "./components/MaterialTheme";
import StyledTheme from "./components/StyledTheme";

function render(
  ui,
  {
    initialState,
    store = configureStore(initialState),
    mocksForApollo = [],
    ...renderOptions
  } = {}
) {
  function Wrapper({ children }) {
    return (
      <MockedProvider mocks={mocksForApollo} addTypename={false}>
        <ApolloConsumer>
          {(client) => {
            client.stop = jest.fn();
            return (
              <Provider store={store}>
                <MaterialTheme>
                  <StyledTheme>{children}</StyledTheme>
                </MaterialTheme>
              </Provider>
            );
          }}
        </ApolloConsumer>
      </MockedProvider>
    );
  }
  return {
    ...rtlRender(ui, { wrapper: Wrapper, ...renderOptions }),
    store: store
  };
}

// re-export everything
export * from "@testing-library/react";
// override render method
export { render };
