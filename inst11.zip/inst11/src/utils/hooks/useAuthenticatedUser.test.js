import { Auth } from "aws-amplify";
import { renderHook } from "@testing-library/react-hooks";
import useAuthenticatedUser, { getUser } from "./useAuthenticatedUser";
import { waitFor } from "@testing-library/react";

jest.mock("aws-amplify");

test("should return undefined", () => {
  Auth.currentAuthenticatedUser.mockResolvedValueOnce(null);
  const { result } = renderHook(() => useAuthenticatedUser());
  expect(result.current).toBe(undefined);
});

test("should return user", async () => {
  Auth.currentAuthenticatedUser.mockResolvedValueOnce(
    Promise.resolve({
      username: 1,
      name: "User"
    })
  );
  const { result } = renderHook(() => useAuthenticatedUser());
  await waitFor(() => {
    expect(result.current).toEqual({
      id: 1,
      name: "User"
    });
  });
});

test("should get user and invoke callback", async () => {
  const mockCallback = jest.fn();
  Auth.currentAuthenticatedUser.mockResolvedValueOnce(
    Promise.resolve({
      username: 1,
      name: "User"
    })
  );
  await getUser(mockCallback);
  expect(mockCallback).toBeCalled();
});
test("should return user and not invoke callback", async () => {
  Auth.currentAuthenticatedUser.mockResolvedValueOnce(
    Promise.resolve({
      username: 1,
      name: "User"
    })
  );
  const user = await getUser(undefined);
  expect(user).toEqual({
    id: 1,
    name: "User"
  });
});
