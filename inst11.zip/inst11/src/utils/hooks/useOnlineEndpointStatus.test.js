import { waitFor } from "@testing-library/dom";
import { renderHook } from "@testing-library/react-hooks";
import { useOnlineEndpointStatus } from "./useOnlineEndpointStatus";

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

describe("test useOnlineEndpointStatus hook", () => {
  test("should check successfully backend availability every 200ms", async () => {
    // arrange
    const urlToCheck = "urlToCheck";
    const intervalTimeToCheck = 200;
    window.fetch = jest.fn(() =>
      Promise.resolve({
        status: 200
      })
    );

    expect(window.fetch).toHaveBeenCalledTimes(0);
    //act
    const { result, unmount } = renderHook(() =>
      useOnlineEndpointStatus(urlToCheck, intervalTimeToCheck)
    );

    // assert
    expect(window.fetch).toBeCalledWith(urlToCheck, { method: "POST" });
    expect(result.current).toBe(true);
    expect(window.fetch).toHaveBeenCalledTimes(1);

    // act
    await sleep(250);

    // assert
    expect(window.fetch).toBeCalledWith(urlToCheck, { method: "POST" });
    expect(result.current).toBe(true);
    expect(window.fetch).toHaveBeenCalledTimes(2);

    // act
    await sleep(250);

    // assert
    expect(window.fetch).toBeCalledWith(urlToCheck, { method: "POST" });
    expect(result.current).toBe(true);
    expect(window.fetch).toHaveBeenCalledTimes(3);

    // unmount hook
    unmount();
  });
  test("should check successfully backend availability every default timeout", async () => {
    jest.useFakeTimers("modern");
    // arrange
    window.fetch = jest.fn(() =>
      Promise.resolve({
        status: 200
      })
    );

    expect(window.fetch).toHaveBeenCalledTimes(0);
    //act
    const { result, unmount } = renderHook(() => useOnlineEndpointStatus());

    // assert
    await waitFor(() => {
      expect(window.fetch).toBeCalledWith("", { method: "POST" });
      expect(result.current).toBe(true);
      expect(window.fetch).toHaveBeenCalledTimes(1);
    });

    // act
    jest.advanceTimersByTime(3050);

    // assert
    await waitFor(() => {
      expect(window.fetch).toBeCalledWith("", { method: "POST" });
      expect(result.current).toBe(true);
      expect(window.fetch).toHaveBeenCalledTimes(2);
    });

    // act
    jest.advanceTimersByTime(3050);

    // assert
    await waitFor(() => {
      expect(window.fetch).toBeCalledWith("", { method: "POST" });
      expect(result.current).toBe(true);
      expect(window.fetch).toHaveBeenCalledTimes(3);
    });

    jest.useRealTimers();

    // unmount hook
    unmount();
  });

  test("checking backend should failed every 200ms", async () => {
    // arrange
    const urlToCheck = "urlToCheck";
    const intervalTimeToCheck = 200;
    window.fetch = jest.fn(() =>
      Promise.resolve({
        status: 403
      })
    );

    expect(window.fetch).toHaveBeenCalledTimes(0);
    //act
    const { result, unmount, waitForValueToChange } = renderHook(() =>
      useOnlineEndpointStatus(urlToCheck, intervalTimeToCheck)
    );

    // assert
    expect(result.current).toBe(true);

    // act
    await waitForValueToChange(() => result.current);

    // assert
    expect(window.fetch).toBeCalledWith(urlToCheck, { method: "POST" });
    expect(window.fetch).toHaveBeenCalledTimes(1);
    expect(result.current).toBe(false);

    // act
    await sleep(250);
    expect(window.fetch).toBeCalledWith(urlToCheck, { method: "POST" });
    expect(window.fetch).toHaveBeenCalledTimes(2);
    expect(result.current).toBe(false);

    unmount();
  });

  test("should change status of backend should from unavailable to available after 500ms", async () => {
    // arrange
    const urlToCheck = "urlToCheck";
    const intervalTimeToCheck = 200;

    const badResponse = jest.fn(() =>
      Promise.resolve({
        status: 403
      })
    );
    const successResponse = jest.fn(() =>
      Promise.resolve({
        status: 401
      })
    );

    window.fetch = badResponse;
    expect(window.fetch).toHaveBeenCalledTimes(0);

    //act
    const { result, unmount, waitForValueToChange } = renderHook(() =>
      useOnlineEndpointStatus(urlToCheck, intervalTimeToCheck)
    );

    // assert
    expect(result.current).toBe(true);

    // act
    await waitForValueToChange(() => result.current);

    // assert
    expect(window.fetch).toBeCalledWith(urlToCheck, { method: "POST" });
    expect(window.fetch).toHaveBeenCalledTimes(1);
    expect(result.current).toBe(false);

    // arrange
    window.fetch = successResponse;

    // act
    await waitForValueToChange(() => result.current);
    expect(window.fetch).toBeCalledWith(urlToCheck, { method: "POST" });
    expect(result.current).toBe(true);

    unmount();
  });

  test("should not check backend availability after unmount", async () => {
    // arrange
    const urlToCheck = "urlToCheck";
    const intervalTimeToCheck = 500;
    window.fetch = jest.fn(() =>
      Promise.resolve({
        status: 200
      })
    );

    //act
    const { result, unmount } = renderHook(() =>
      useOnlineEndpointStatus(urlToCheck, intervalTimeToCheck)
    );

    // assert
    expect(result.current).toBe(true);
    expect(window.fetch).toHaveBeenCalledTimes(1);

    // act
    await sleep(250);
    unmount();
    await sleep(250);
    // assert
    expect(window.fetch).toHaveBeenCalledTimes(1);
  });

  test("request should throw an error every 200ms", async () => {
    // arrange
    const urlToCheck = "urlToCheck";
    const intervalTimeToCheck = 200;
    window.fetch = jest.fn(() =>
      Promise.reject({
        status: 500
      })
    );

    expect(window.fetch).toHaveBeenCalledTimes(0);
    //act
    const { result, unmount, waitForValueToChange } = renderHook(() =>
      useOnlineEndpointStatus(urlToCheck, intervalTimeToCheck)
    );

    // assert
    expect(result.current).toBe(true);

    // act
    await waitForValueToChange(() => result.current);

    // assert
    expect(window.fetch).toBeCalledWith(urlToCheck, { method: "POST" });
    expect(window.fetch).toHaveBeenCalledTimes(1);
    expect(result.current).toBe(false);

    // act
    await sleep(250);
    expect(window.fetch).toBeCalledWith(urlToCheck, { method: "POST" });
    expect(window.fetch).toHaveBeenCalledTimes(2);
    expect(result.current).toBe(false);

    unmount();
  });
});
