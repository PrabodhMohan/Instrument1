import { act } from "@testing-library/react";
import { renderHook } from "@testing-library/react-hooks";
import useDialog from "./useDialog";

test("should  dialog be close", () => {
  const { result } = renderHook(() => useDialog());

  expect(result.current.open).toBe(false);
});
test("should dialog be open", () => {
  const { result } = renderHook(() => useDialog(true));

  expect(result.current.open).toBe(true);
});

test("should dialong change from close to open", async () => {
  const { result } = renderHook(() => useDialog());

  expect(result.current.open).toBe(false);

  act(() => {
    result.current.openDialog();
  });

  expect(result.current.open).toBe(true);
});

test("should dialong change from open to close", async () => {
  const { result } = renderHook(() => useDialog(true));

  expect(result.current.open).toBe(true);

  act(() => {
    result.current.close();
  });

  expect(result.current.open).toBe(false);
});
