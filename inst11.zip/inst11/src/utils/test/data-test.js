export const data = {
  instruments: {
    instruments: [
      {
        softwareVersion: "v3.0.2",
        siteName: "site1",
        siteTimezone: "site timezone",
        belongingToGroup: "Example group2",
        buildingLocation: {
          isSynchronized: false,
          value: "R06",
          __typename: "StringAttribute"
        },
        configurationBaseline: "BA329523",
        dateOfLastMaintanance: {
          isSynchronized: true,
          value: "2021-06-20",
          __typename: "AWSDateAttribute"
        },
        dateOfNextMaintanance: {
          isSynchronized: true,
          value: "2021-06-16",
          __typename: "AWSDateAttribute"
        },
        floorAndRoomLocation: {
          isSynchronized: false,
          value: "05.43-03",
          __typename: "StringAttribute"
        },
        installedTests: [
          { name: "test1", version: "version1", __typename: "InstalledTest" },
          { name: "test2", version: "version2", __typename: "InstalledTest" },
          { name: "test3", version: "version3", __typename: "InstalledTest" }
        ],
        instrumentGTIN: {
          isSynchronized: false,
          value: "gtn1",
          __typename: "StringAttribute"
        },
        instrumentGxPStatus: {
          isSynchronized: false,
          value: "Example string2",
          __typename: "StringAttribute"
        },
        instrumentName: {
          isSynchronized: true,
          value: "STING.5",
          __typename: "StringAttribute"
        },
        instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0342",
        instrumentType: {
          isSynchronized: false,
          value: "Cobas 6400",
          __typename: "StringAttribute"
        },
        isBookable: false,
        isVisualized: false,
        materialNumber: "542568153454",
        qualificationDocuments: {
          isSynchronized: true,
          value: [
            {
              name: "document1",
              url: "https://test.com",
              __typename: "QualificationDocument"
            },
            {
              name: "document2",
              url: "https://roche.com",
              __typename: "QualificationDocument"
            }
          ],
          __typename: "QualificationDocumentAttribute"
        },
        responsiblePerson: {
          isSynchronized: false,
          value: "Kathryn Murphy",
          __typename: "StringAttribute"
        },
        serialNumber: "SD9212969",
        systemStatus: {
          isSynchronized: false,
          value: "Example status2",
          __typename: "StringAttribute"
        },
        secondResponsiblePerson: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        manufacturer: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        equipmentId: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        __typename: "DigitalLabInstrumentRepositoryEntry"
      },
      {
        softwareVersion: "v2.0.5",
        siteName: "site1",
        siteTimezone: "site timezone",
        belongingToGroup: "Example group",
        buildingLocation: {
          isSynchronized: false,
          value: "R089",
          __typename: "StringAttribute"
        },
        configurationBaseline: "BA329524",
        dateOfLastMaintanance: {
          isSynchronized: false,
          value: "2021-04-20",
          __typename: "AWSDateAttribute"
        },
        dateOfNextMaintanance: {
          isSynchronized: false,
          value: "2021-04-16",
          __typename: "AWSDateAttribute"
        },
        floorAndRoomLocation: {
          isSynchronized: false,
          value: "09.436-05",
          __typename: "AWSDateAttribute"
        },
        installedTests: [],
        instrumentGTIN: {
          isSynchronized: true,
          value: "gtn890",
          __typename: "AWSDateAttribute"
        },
        instrumentGxPStatus: {
          isSynchronized: true,
          value: "Example string",
          __typename: "AWSDateAttribute"
        },
        instrumentName: {
          isSynchronized: true,
          value: "STING.505",
          __typename: "StringAttribute"
        },
        instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0505",
        instrumentType: {
          isSynchronized: false,
          value: "5800",
          __typename: "StringAttribute"
        },
        isBookable: true,
        isVisualized: true,
        materialNumber: "923273443654",
        qualificationDocuments: {
          isSynchronized: true,
          value: [
            {
              name: "document14",
              url: "https://test123.com",
              __typename: "QualificationDocument"
            },
            {
              name: "document32",
              url: "https://roche/test.com",
              __typename: "QualificationDocument"
            }
          ],
          __typename: "QualificationDocumentAttribute"
        },
        responsiblePerson: {
          isSynchronized: false,
          value: "5800",
          __typename: "StringAttribute"
        },
        serialNumber: "TEST_NEW_CSV456456456",
        systemStatus: {
          isSynchronized: false,
          value: "Example status",
          __typename: "StringAttribute"
        },
        secondResponsiblePerson: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        manufacturer: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        equipmentId: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        __typename: "DigitalLabInstrumentRepositoryEntry"
      },
      {
        softwareVersion: "v2.1.2",
        siteName: "site1",
        siteTimezone: "site timezone",
        belongingToGroup: "Example group3",
        buildingLocation: {
          isSynchronized: false,
          value: "R05",
          __typename: "StringAttribute"
        },
        configurationBaseline: "BA321244",
        dateOfLastMaintanance: {
          isSynchronized: true,
          value: "2021-05-21",
          __typename: "AWSDateAttribute"
        },
        dateOfNextMaintanance: {
          isSynchronized: true,
          value: "2021-05-22",
          __typename: "AWSDateAttribute"
        },
        floorAndRoomLocation: {
          isSynchronized: false,
          value: "02.48-05",
          __typename: "StringAttribute"
        },
        installedTests: [
          {
            name: "test45",
            version: "version17",
            __typename: "InstalledTest"
          }
        ],
        instrumentGTIN: {
          isSynchronized: false,
          value: "gtn7",
          __typename: "StringAttribute"
        },
        instrumentGxPStatus: {
          isSynchronized: false,
          value: "Example string3",
          __typename: "StringAttribute"
        },
        instrumentName: {
          isSynchronized: true,
          value: "STING.2",
          __typename: "StringAttribute"
        },
        instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0232",
        instrumentType: {
          isSynchronized: false,
          value: "Cobas 6800",
          __typename: "StringAttribute"
        },
        isBookable: true,
        isVisualized: false,
        materialNumber: "542568153455",
        qualificationDocuments: {
          isSynchronized: false,
          value: [],
          __typename: "QualificationDocumentAttribute"
        },
        responsiblePerson: {
          isSynchronized: false,
          value: "Darrell Steward",
          __typename: "StringAttribute"
        },
        serialNumber: "KH9212924",
        systemStatus: {
          isSynchronized: false,
          value: "Example status3",
          __typename: "StringAttribute"
        },
        secondResponsiblePerson: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        manufacturer: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        equipmentId: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        __typename: "DigitalLabInstrumentRepositoryEntry"
      },
      {
        softwareVersion: "v2.0.2",
        siteName: "site1",
        siteTimezone: "site timezone",
        belongingToGroup: "Example group1",
        buildingLocation: {
          isSynchronized: false,
          value: "R06",
          __typename: "StringAttribute"
        },
        configurationBaseline: "BA329544",
        dateOfLastMaintanance: {
          isSynchronized: true,
          value: "2021-06-21",
          __typename: "AWSDateAttribute"
        },
        dateOfNextMaintanance: {
          isSynchronized: true,
          value: "2021-06-22",
          __typename: "AWSDateAttribute"
        },
        floorAndRoomLocation: {
          isSynchronized: false,
          value: "02.43-03",
          __typename: "StringAttribute"
        },
        installedTests: [
          {
            name: "test55",
            version: "version67",
            __typename: "InstalledTest"
          }
        ],
        instrumentGTIN: {
          isSynchronized: false,
          value: "gtn2",
          __typename: "StringAttribute"
        },
        instrumentGxPStatus: {
          isSynchronized: false,
          value: "Example string1",
          __typename: "StringAttribute"
        },
        instrumentName: {
          isSynchronized: true,
          value: "STING.3",
          __typename: "StringAttribute"
        },
        instrumentRUDI: "^^^^^^DMD^5800^0.0.0.0202",
        instrumentType: {
          isSynchronized: false,
          value: "Cobas 9800",
          __typename: "StringAttribute"
        },
        isBookable: true,
        isVisualized: true,
        materialNumber: "356275654353",
        qualificationDocuments: {
          isSynchronized: true,
          value: [
            {
              name: "document245",
              url: "https://roche/test/test2.com",
              __typename: "QualificationDocument"
            }
          ],
          __typename: "QualificationDocumentAttribute"
        },
        responsiblePerson: {
          isSynchronized: false,
          value: "Courtney Henry",
          __typename: "StringAttribute"
        },
        serialNumber: "012921097",
        systemStatus: {
          isSynchronized: false,
          value: "Example status1",
          __typename: "StringAttribute"
        },
        secondResponsiblePerson: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        manufacturer: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        equipmentId: {
          isSynchronized: false,
          value: "",
          __typename: "StringAttribute"
        },
        __typename: "DigitalLabInstrumentRepositoryEntry"
      }
    ],
    __typename: "ModelDigitalLabInstrumentRepositoryEntryConnection"
  }
};
