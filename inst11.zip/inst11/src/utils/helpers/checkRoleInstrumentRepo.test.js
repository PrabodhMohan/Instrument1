import { Auth } from "aws-amplify";
import React from "react";
import { render } from "../../test-utils";
import {checkRoleInstrumentRepo} from "./checkRoleInstrumentRepo";
import get from "lodash/get";
import { GROUPS_TOKEN_PATH,INSTRUMENT_REPO_VIEW_USER,INSTRUMENT_REPOSITORY_ADMIN } from "../../constants";

jest.mock("aws-amplify");

describe("tests with Roles", () => {
  test("should render the checkRole with access users", async () => {
    render(<checkRoleInstrumentRepo />);
    Auth.currentAuthenticatedUser.mockResolvedValueOnce({
      signInUserSession: { accessToken: { payload: { "cognito:groups": [] } } }
    });
    const  access_groups= ['landingPageAdmin', 'InstrumentRepositoryAdmin',]
    expect(await checkRoleInstrumentRepo({access_groups:access_groups})
    ).toBeFalsy(); 

    var x =access_groups.includes(INSTRUMENT_REPOSITORY_ADMIN);
    x = false;
    if(x == false)
     return false;

    x = (access_groups.includes(INSTRUMENT_REPO_VIEW_USER))
     if(x == true)
      return true;

    if(access_groups.includes(INSTRUMENT_REPOSITORY_ADMIN)){
        return false;
    }
    else if(access_groups.includes(INSTRUMENT_REPO_VIEW_USER)){
        return true;
    }
  });
});