import omitDeep from "omit-deep-lodash";
import { LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS } from "../../gql/landingapi/queries";
export const getFilterObject = ({
  filters,
  search,
  groupList,
  categoryList,
  siteList,
  manufacturerList,
  responsiblePersonList
}) => {
  let filterArray = [];

  const group = filters?.group
    ? omitDeep(
        groupList.find((x) => x.value === filters.group),
        "isActive"
      )
    : null;

  const category = filters?.category
    ? omitDeep(
        categoryList.find((x) => x.value === filters.category),
        "isActive"
      )
    : null;

  const site = filters?.site
    ? siteList.find((x) => x.siteName === filters.site)
    : null;
  const manufacturer = filters?.manufacturer
    ? omitDeep(
        manufacturerList.find((x) => x.value === filters.manufacturer),
        "isActive"
      )
    : null;
  const responsiblePerson = filters?.responsiblePerson
    ? responsiblePersonList.find(
        (x) => x.personName === filters.responsiblePerson
      )
    : null;

  if (group) {
    filterArray.push({ belongingToGroup: { eq: JSON.stringify(group) } });
  }
  if (category) {
    filterArray.push({ equipmentCategory: { eq: JSON.stringify(category) } });
  }
  if (site) {
    filterArray.push({ siteName: { eq: site.siteName } });
  }
  if (manufacturer) {
    filterArray.push({
      manufacturer: { eq: JSON.stringify(manufacturer) }
    });
  }
  if (responsiblePerson) {
    filterArray.push({
      or: [
        {
          responsiblePerson: {
            eq: JSON.stringify({
              isSynchronized: false,
              value: responsiblePerson.personName
            })
          }
        },
        {
          responsiblePerson: {
            eq: JSON.stringify({
              isSynchronized: null,
              value: responsiblePerson.personName
            })
          }
        }
      ]
    });
  }
  if (search) {
    filterArray.push({ serialNumber: { beginsWith: search } });
  }
  return filterArray.length === 0
    ? null
    : {
        and: filterArray
      };
};

export const getfilterInstrumentList = async ({ client, variables }) => {
  try {
    const result = await client.query({
      query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
      fetchPolicy: "no-cache",
      variables: variables
    });
    return {
      nextToken:
        result?.data?.listDigitalLabInstrumentRepositoryEntrys?.nextToken,
      items: result?.data?.listDigitalLabInstrumentRepositoryEntrys?.items
    };
  } catch (err) {
    console.warn(err);
    return null;
  }
};
