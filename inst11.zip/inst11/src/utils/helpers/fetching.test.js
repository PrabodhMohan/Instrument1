import { getGQLFilterObj, createGQLFilterObj, getAllData } from "./fetching";
import { data } from "../test/data-test";
import { LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS } from "../../gql/landingapi/queries";

describe("tests getAllData", () => {
  test("should getAllData fetching data until nextToken is null", async () => {
    let executeFlexQuery = jest
      .fn()
      .mockReturnValueOnce({
        data: {
          listDigitalLabInstrumentRepositoryEntrys: {
            items: data.instruments.instruments.slice(0, 1),
            nextToken: "123"
          }
        }
      })
      .mockReturnValueOnce({
        data: {
          listDigitalLabInstrumentRepositoryEntrys: {
            items: data.instruments.instruments.slice(1, 2),
            nextToken: null
          }
        }
      });

    expect(
      await getAllData({
        client: {
          query: executeFlexQuery
        },
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        dataPath: ["data", "listDigitalLabInstrumentRepositoryEntrys"]
      })
    ).toEqual({
      items: data.instruments.instruments.slice(0, 2),
      nextToken: null,
      error: null
    });
    expect(executeFlexQuery).toHaveBeenCalledTimes(2);
  });

  test("should getAllData return all data on first query", async () => {
    let executeFlexQuery = jest.fn().mockReturnValueOnce({
      data: {
        listDigitalLabInstrumentRepositoryEntrys: {
          items: data.instruments.instruments,
          nextToken: null
        }
      }
    });
    expect(
      await getAllData({
        client: {
          query: executeFlexQuery
        },
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        dataPath: ["data", "listDigitalLabInstrumentRepositoryEntrys"]
      })
    ).toEqual({
      items: data.instruments.instruments,
      nextToken: null,
      error: null
    });

    expect(executeFlexQuery).toHaveBeenCalledTimes(1);
  });

  test("should drill data return all data on start", async () => {
    let executeFlexQuery = jest
      .fn()
      .mockReturnValueOnce({
        data: {
          listDigitalLabInstrumentRepositoryEntrys: {
            items: data.instruments.instruments.slice(0, 2),
            nextToken: "123"
          }
        }
      })
      .mockReturnValueOnce({
        data: {
          listDigitalLabInstrumentRepositoryEntrys: {
            items: data.instruments.instruments.slice(2, 4),
            nextToken: "456"
          }
        }
      });
    expect(
      await getAllData({
        client: {
          query: executeFlexQuery
        },
        drillData: true,
        variables: {
          limit: 2
        },
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        dataPath: ["data", "listDigitalLabInstrumentRepositoryEntrys"]
      })
    ).toEqual({
      items: data.instruments.instruments.slice(0, 4),
      nextToken: null,
      error: null
    });

    expect(executeFlexQuery).toHaveBeenCalledTimes(3);
  });
  test("should getAllData return empty array if fetching data fail", async () => {
    let executeFlexQuery = jest
      .fn()
      .mockReturnValueOnce(Promise.reject("error"));
    expect(
      await getAllData({
        client: {
          query: executeFlexQuery
        },
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        dataPath: ["data", "listDigitalLabInstrumentRepositoryEntrys"]
      })
    ).toEqual({ items: [], nextToken: null, error: "error" });
    expect(executeFlexQuery).toHaveBeenCalledTimes(1);
  });

  test("should getAllData return empty array if params are invalid", async () => {
    let executeFlexQuery = jest.fn().mockReturnValueOnce({
      data: {
        listDigitalLabInstrumentRepositoryEntrys: {
          items: data.instruments.instruments,
          nextToken: null
        }
      }
    });
    expect(
      await getAllData({
        client: null,
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        dataPath: ["data", "listDigitalLabInstrumentRepositoryEntrys"]
      })
    ).toEqual({ items: [], nextToken: null, error: null });

    expect(
      await getAllData({
        client: {
          query: executeFlexQuery
        },
        query: null,
        dataPath: ["data", "listDigitalLabInstrumentRepositoryEntrys"]
      })
    ).toEqual({ items: [], nextToken: null, error: null });
    expect(
      await getAllData({
        client: {
          query: executeFlexQuery
        },
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        dataPath: null
      })
    ).toEqual({ items: [], nextToken: null, error: null });
    expect(
      await getAllData({
        client: {
          query: executeFlexQuery
        },
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        dataPath: []
      })
    ).toEqual({ items: [], nextToken: null, error: null });
    expect(
      await getAllData({
        client: {
          query: executeFlexQuery
        },
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        variables: null,
        dataPath: []
      })
    ).toEqual({ items: [], nextToken: null, error: null });
  });

  test("should getAllData return empty array if dataPath return not array", async () => {
    let executeFlexQuery = jest
      .fn()
      .mockReturnValueOnce({
        data: {
          listDigitalLabInstrumentRepositoryEntrys: {
            items: null,
            nextToken: "123"
          }
        }
      })
      .mockReturnValueOnce({
        data: {
          listDigitalLabInstrumentRepositoryEntrys: {
            items: { a: 1 },
            nextToken: null
          }
        }
      });

    expect(
      await getAllData({
        client: {
          query: executeFlexQuery
        },
        query: LIST_DIGITAL_LAB_INSTRUMENT_REPOSITORY_ENTRYS,
        dataPath: ["data", "listDigitalLabInstrumentRepositoryEntrys"]
      })
    ).toEqual({
      items: [],
      nextToken: null,
      error: null
    });
    expect(executeFlexQuery).toHaveBeenCalledTimes(2);
  });
});

describe("tests createGQLFilterObj", () => {
  test("should return empty object", () => {
    expect(createGQLFilterObj(1)).toEqual(null);
    expect(createGQLFilterObj(null)).toEqual(null);
    expect(createGQLFilterObj([1, 2])).toEqual(null);
  });
  test("should getGQLFilterObj return empty object", () => {
    expect(getGQLFilterObj(1)).toEqual(null);
    expect(getGQLFilterObj(null)).toEqual(null);
    expect(getGQLFilterObj([1, 2])).toEqual(null);
  });

  test("should return filter object with array filter", () => {
    expect(
      createGQLFilterObj({
        active: true,
        type: ["BOOKED", "RESERVED"],
        reservedOnAfternoon: ["NONE", "PARTIAL"]
      })
    ).toEqual({
      and: [
        { or: [{ type: { eq: "BOOKED" } }, { type: { eq: "RESERVED" } }] },
        {
          or: [
            { reservedOnAfternoon: { eq: "NONE" } },
            { reservedOnAfternoon: { eq: "PARTIAL" } }
          ]
        },
        { active: { eq: true } }
      ]
    });
    expect(
      createGQLFilterObj({
        active: true,
        type: ["BOOKED", "RESERVED"],
        reservedOnAfternoon: []
      })
    ).toEqual({
      and: [
        { or: [{ type: { eq: "BOOKED" } }, { type: { eq: "RESERVED" } }] },
        { active: { eq: true } }
      ]
    });

    expect(
      createGQLFilterObj({
        active: true,
        instrumentType: "6800",
        type: [],
        reservedOnAfternoon: []
      })
    ).toEqual({
      active: { eq: true },
      instrumentType: { eq: "6800" }
    });

    expect(
      createGQLFilterObj({
        instrumentType: ["5800", "6800"]
      })
    ).toEqual({
      and: [
        {
          or: [
            { instrumentType: { eq: "5800" } },
            { instrumentType: { eq: "6800" } }
          ]
        }
      ]
    });

    expect(
      createGQLFilterObj({
        instrumentType: [null, undefined, []]
      })
    ).toEqual(null);
  });
  test("should return filter object", () => {
    expect(createGQLFilterObj({ active: false })).toEqual({
      active: {
        eq: false
      }
    });
    expect(
      createGQLFilterObj({ email: "test@mail.com", active: false })
    ).toEqual({
      email: {
        eq: "test@mail.com"
      },
      active: {
        eq: false
      }
    });
    expect(
      createGQLFilterObj({ email: "test@mail.com", active: null })
    ).toEqual({
      email: {
        eq: "test@mail.com"
      }
    });
    expect(createGQLFilterObj({ email: "test@mail.com", active: "" })).toEqual({
      email: {
        eq: "test@mail.com"
      }
    });
    expect(createGQLFilterObj({ email: null, active: null })).toEqual(null);
  });
});
