import { data } from "../../test/data-test";
import { filterByQuery, emailToName } from "./index";

const instruments = data.instruments.instruments;

describe("tests filterByQuery", () => {
  test("should return 3 instruments with searched phrase in default prop", () => {
    const query = "cobas";
    expect(filterByQuery(instruments, "").length).toBe(4);
    expect(filterByQuery(instruments, query).length).toBe(3);
  });

  test("should not found any instruments with searched phrase in specified prop", () => {
    const query = "cobas";
    expect(filterByQuery(instruments, "").length).toBe(4);
    expect(
      filterByQuery(instruments, query, [
        "instrumentName.value",
        "serialNumber"
      ]).length
    ).toBe(0);
  });

  test("should return sorted instruments by default name", () => {
    expect(
      filterByQuery(instruments, "", [
        "instrumentName.value",
        "serialNumber"
      ])[0].instrumentName.value
    ).toEqual("STING.505");
    expect(
      filterByQuery(instruments, "", [
        "instrumentName.value",
        "serialNumber"
      ])[3].instrumentName.value
    ).toEqual("STING.2");
  });

  test("should return sorted instruments by default name desc", () => {
    const reverse = true;
    expect(
      filterByQuery(
        instruments,
        "",
        ["instrumentName.value", "serialNumber"],
        ["instrumentName", "value"],
        reverse
      )[0].instrumentName.value
    ).toEqual("STING.2");
    expect(
      filterByQuery(
        instruments,
        "",
        ["instrumentName.value", "serialNumber"],
        ["instrumentName", "value"],
        reverse
      )[3].instrumentName.value
    ).toEqual("STING.505");
  });

  test("should return sorted instruments by instrument type asc", () => {
    const reverse = false;
    expect(
      filterByQuery(
        instruments,
        "",
        ["instrumentName.value", "serialNumber"],
        ["instrumentType", "value"],
        reverse
      )[0].instrumentType.value
    ).toEqual("Cobas 9800");
    expect(
      filterByQuery(
        instruments,
        "",
        ["instrumentName.value", "serialNumber"],
        ["instrumentType", "value"],
        reverse
      )[3].instrumentType.value
    ).toEqual("5800");
  });

  test("should return sorted instruments by instrumenttype desc", () => {
    const reverse = true;
    expect(
      filterByQuery(
        instruments,
        "",
        ["instrumentName.value", "serialNumber"],
        ["instrumentType", "value"],
        reverse
      )[0].instrumentType.value
    ).toEqual("5800");
    expect(
      filterByQuery(
        instruments,
        "",
        ["instrumentName.value", "serialNumber"],
        ["instrumentType", "value"],
        reverse
      )[3].instrumentType.value
    ).toEqual("Cobas 9800");
  });
});
describe("test emailToName", () => {
  test("changes email to name", () => {
    expect(emailToName("john.doe@example.com")).toBe("john doe");
  });

  test("changes invalid email to name", () => {
    expect(emailToName("john.doe")).toBe("john doe");
  });
  test("changes not string to empty string", () => {
    expect(emailToName(12)).toBe("");
  });
});
