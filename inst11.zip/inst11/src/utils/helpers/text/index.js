import * as R from "ramda";
import { at } from "lodash/fp";
import styled from "styled-components";

const RegularCell = styled.div`
  display: flex;
  align-items: center;
`;
const FalseAnswerSpan = styled.span`
  color: #737373;
`;
export const emailToName = (email) =>
  typeof email === "string" ? email.split("@")[0]?.replace(/\./g, " ") : "";

export const getText = (text) => R.compose(R.toLower, R.trim)(text);

export const filterByQuery = (
  data,
  query,
  propFilter = [
    "instrumentName.value",
    "serialNumber",
    "materialNumber",
    "floorAndRoomLocation.value",
    "buildingLocation.value",
    "instrumentType.value",
    "responsiblePerson.value"
  ],
  propSort = ["instrumentName", "value"],
  reverse = false
) => {
  if (!query) R.sort(R.descend(R.path(propSort)))(data);
  const _query = getText(query);
  const valuesAt = at(propFilter);
  const result = R.compose(
    R.sort(R.descend(R.path(propSort))),
    R.filter(
      R.compose(R.contains(_query), getText, R.compose(R.join(""), valuesAt))
    )
  )(data);

  return reverse ? result.reverse() : result;
};

export const getLocationText = (itemWithLocationDetails) => {
  let { buildingLocation, floorAndRoomLocation } =
    itemWithLocationDetails ?? {};
  if (!buildingLocation && !floorAndRoomLocation) {
    return "";
  }
  if (typeof buildingLocation === "object") {
    buildingLocation = buildingLocation.value;
  }
  if (typeof floorAndRoomLocation === "object") {
    floorAndRoomLocation = floorAndRoomLocation.value;
  }
  if (!buildingLocation && !floorAndRoomLocation) {
    return "";
  }
  return `${buildingLocation ?? ""}.${floorAndRoomLocation ?? ""}`;
};
const IsBookableCell = ({ item }) => {
  return item.isBookable ? (
    <RegularCell>Yes</RegularCell>
  ) : (
    <RegularCell>
      <FalseAnswerSpan>No</FalseAnswerSpan>
    </RegularCell>
  );
};
export function changeDateFormat(inputDate) {
  // expects Y-m-d
  var splitDate = inputDate.split("-");
  if (splitDate.count === 0) {
    return "-";
  }
  var year = splitDate[0];
  var month = splitDate[1];
  var day = splitDate[2];

  return day + "-" + month + "-" + year;
}
const LocationCell = ({ item }) => {
  return <span>{getLocationText(item)}</span>;
};
const DateFormatterNextMaintainance = ({ item }) => {
  return (
    <span>
      {item?.dateOfNextMaintanance?.value
        ? changeDateFormat(item?.dateOfNextMaintanance?.value)
        : "-"}
    </span>
  );
};
const DateFormatterLastMaintanance = ({ item }) => {
  return (
    <span>
      {item?.dateOfLastMaintanance?.value
        ? changeDateFormat(item?.dateOfLastMaintanance?.value)
        : "-"}
    </span>
  );
};
const DateFormatterPeriodicReview = ({ item }) => {
  return (
    <span>
      {item?.dateOfNextPeriodicReview
        ? changeDateFormat(item?.dateOfNextPeriodicReview)
        : "-"}
    </span>
  );
};
const PersonCell = ({ item }) => {
  return item?.responsiblePerson?.value ?? "-";
};
const installedTests = ({ item }) => {
  return (
    <RegularCell>
      {item?.installedTests?.length > 0 ? item?.installedTests?.length : "-"}
    </RegularCell>
  );
};
const qualificationDocuments = ({ item }) => {
  return (
    <RegularCell>
      {item?.qualificationDocuments?.value?.length > 0
        ? item?.qualificationDocuments?.value?.length
        : "-"}
    </RegularCell>
  );
};
export const getDynamicFields = (columns) => {
  let fields = {};
  for (const column of columns) {
    let x = {};
    x[column.key] = { text: column.val, sortable: true };
    if (column.key === "location")
      x[column.key].component = LocationCell;
    if (column.key === "dateOfNextMaintanance")
      x[column.key].component = DateFormatterNextMaintainance;
    if (column.key === "dateOfLastMaintanance")
      x[column.key].component = DateFormatterLastMaintanance;
    if (column.key === "dateOfNextPeriodicReview")
      x[column.key].component = DateFormatterPeriodicReview;
    if (column.key === "responsiblePerson")
      x[column.key].component = PersonCell;
    if (column.key === "isBookable") x[column.key].component = IsBookableCell;
    if (column.key === "qualificationDocuments")
      x[column.key].component = qualificationDocuments;
    if (column.key === "installedTests")
      x[column.key].component = installedTests;
    Object.assign(fields, x);
  }
  return fields;
};

export const getStringCapitalized = (value) => {
  const lowerCaseStr = value?.toLowerCase();
  return lowerCaseStr.charAt(0).toUpperCase() + lowerCaseStr.slice(1);
};
