import { Auth } from "aws-amplify";
import get from "lodash/get";
import { GROUPS_TOKEN_PATH,INSTRUMENT_REPO_VIEW_USER,INSTRUMENT_REPOSITORY_ADMIN } from "../../constants";


export const checkRoleInstrumentRepo = async (
  ) => {
  const currentAuthenticatedUser = await Auth.currentAuthenticatedUser();
  const access_groups = get(currentAuthenticatedUser, GROUPS_TOKEN_PATH);
  if(access_groups.includes(INSTRUMENT_REPOSITORY_ADMIN)){
    return false;
  }
  else if(access_groups.includes(INSTRUMENT_REPO_VIEW_USER)){
    return true;
  }
};
