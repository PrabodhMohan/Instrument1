import { updateItem, deleteItem, addItem } from "./crud";

test("test deleteItem with not defauld id", () => {
  const data = [
    { idk: "1", name: "test1" },
    { idk: "2", name: "test2" }
  ];
  expect(deleteItem(data, { idk: "1" }, ["idk"])).toEqual([data[1]]);
});
test("test deleteItem with defauld id", () => {
  const data = [
    { id: "1", name: "test1" },
    { id: "2", name: "test2" }
  ];
  expect(deleteItem(data, { id: "1" })).toEqual([data[1]]);
});
test("test addItem with not defauld id", () => {
  const data = [
    { idk: "1", name: "test1" },
    { idk: "2", name: "test2" }
  ];
  const item = { idk: "3", name: "test3" };
  expect(addItem(data, item, ["idk"])).toEqual([item, ...data]);
});
test("test addItem with defauld id", () => {
  const data = [
    { id: "1", name: "test1" },
    { id: "2", name: "test2" }
  ];
  const item = { id: "3", name: "test3" };
  expect(addItem(data, item)).toEqual([item, ...data]);
});
test("test updateItem with not defauld id", () => {
  const data = [
    { idk: "1", name: "test1" },
    { idk: "2", name: "test2" }
  ];
  const item = { idk: "2", name: "test3" };
  expect(updateItem(data, item, ["idk"])).toEqual([data[0], item]);
});
test("test updateItem with defauld id", () => {
  const data = [
    { id: "1", name: "test1" },
    { id: "2", name: "test2" }
  ];
  const item = { id: "2", name: "test3" };
  expect(updateItem(data, item)).toEqual([data[0], item]);
});
