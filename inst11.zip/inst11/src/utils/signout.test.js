import { signOut } from "./signout";
import { cleanup } from "@testing-library/react";
import { Auth } from "aws-amplify";
import { mock } from "../store";
import configureStore from "../store/configureStore";

afterEach(cleanup);
jest.mock("aws-amplify");
jest.mock("../store", () => {
  const mock = jest.fn();

  return {
    get store() {
      return mock();
    },
    mock
  };
});
describe("signOut", () => {
  test("signout user", async () => {
    delete window.location;
    window.location = {
      reload: jest.fn()
    };
    await signOut();
    expect(Auth.signOut).toHaveBeenCalled();
    expect(window.location.reload).toHaveBeenCalled();
  });
  test("signout catch error", async () => {
    mock.mockReturnValue(configureStore());
    Auth.signOut.mockRejectedValueOnce();
    await expect(() => signOut()).not.toThrow();
  });
});
