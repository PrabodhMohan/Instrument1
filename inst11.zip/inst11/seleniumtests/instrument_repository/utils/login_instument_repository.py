from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ExtendedConditions
from instrument_repository.locators.instrument_repository_locators import InstumentReposiotryLocators
from instrument_repository.properties.instrument_repository_properties import TestProperties


class LoginInstrumentRepository():

    headless = True
    def loginToDesktop(self, user, withVerification=True):
        options = webdriver.ChromeOptions()
        options.headless = self.headless
        self.driver = webdriver.Chrome(TestProperties.testChromeDriverPath['InstrumentRepository'], options=options)
        self.driver.set_window_position(100, 50)
        self.driver.set_window_size(1900, 1080)
        timeout = TestProperties.testTimeOuts['InstrumentRepository']

        # Go to main page and login user
        self.driver.get(TestProperties.testPages['InstrumentRepository'])
        self.sign_in_button = self.driver.find_element_by_css_selector("[data-testid='sign-in-button']")
        self.sign_in_button.click()
        self.driver.execute_script('document.querySelector("#signInFormUsername").value="' + TestProperties.usersForTest[user]['userLogin'] + '"')
        self.driver.execute_script('document.querySelector("#signInFormPassword").value="' + TestProperties.usersForTest[user]['userPassword'] + '"')
        self.driver.execute_script('document.querySelector("[name=signInSubmitButton]").click()')

        if(withVerification):
            WebDriverWait(self.driver, timeout).until(ExtendedConditions.visibility_of_element_located(InstumentReposiotryLocators.MAIN_PAGE_HEADER))

        return self.driver
