from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from instrument_repository.properties.instrument_repository_properties import TestProperties

# This class for all the pages in our application.
# It contains all common elements and functionalities available to all pages.
class BasePage():
    # this function is called every time a new object of the base class is created.
    def __init__(self, driver):
        self.driver = driver
        self.timeout = TestProperties.testTimeOuts['InstrumentRepository']

    # this function performs click on web element whose locator is passed to it.
    def click(self, by_locator):
        WebDriverWait(self.driver, self.timeout).until(EC.visibility_of_element_located(by_locator)).click()

    # this function asserts comparison of a web element's text with passed in text.
    def assert_element_text(self, by_locator, element_text):
        web_element = WebDriverWait(self.driver, self.timeout).until(EC.visibility_of_element_located(by_locator))
        assert web_element.text == element_text

    # this function performs text entry of the passed in text, in a web element whose locator is passed to it.
    def enter_text(self, by_locator, text):
        return WebDriverWait(self.driver, self.timeout).until(EC.visibility_of_element_located(by_locator)).send_keys(
            text)
    def clear_element (self, by_locator):
        return WebDriverWait(self.driver, self.timeout).until(EC.visibility_of_element_located(by_locator)).send_keys(Keys.CONTROL + "a","")
    # this function checks if the web element whose locator has been passed to it, is enabled or not and returns
    # web element if it is enabled.
    def visibility_of_element(self, by_locator):
        return WebDriverWait(self.driver, self.timeout).until(EC.visibility_of_element_located(by_locator))

    # this function checks if the web elements whose locator has been passed to it, is enabled or not and returns
    # web elements
    def visibility_of_all_elements(self, by_locator):
        return WebDriverWait(self.driver, self.timeout).until(EC.visibility_of_all_elements_located(by_locator))

    def invisibility_of_element(self, by_locator, timeout=TestProperties.testTimeOuts['InstrumentRepository']):
        return WebDriverWait(self.driver, timeout).until(EC.invisibility_of_element_located(by_locator))

    def presence_of_element(self, by_locator):
        return WebDriverWait(self.driver, self.timeout).until(EC.presence_of_element_located(by_locator))

    # this function moves the mouse pointer over a web element whose locator has been passed to it.
    def clickable_of_element(self, by_locator):
        return WebDriverWait(self.driver, self.timeout).until(EC.element_to_be_clickable(by_locator))
    def hover_to(self, by_locator):
        element = WebDriverWait(self.driver, self.timeout).until(EC.visibility_of_element_located(by_locator))
        ActionChains(self.driver).move_to_element(element).perform()

    def send_escape_keys(self):
        ActionChains(self.driver).send_keys(Keys.ESCAPE).perform()

    def send_tab_keys(self):
        ActionChains(self.driver).send_keys(Keys.TAB).perform()

    def refresh(self):
        self.driver.refresh()

    def escape(self, by_locator):
        return WebDriverWait(self.driver, self.timeout).until(
            EC.visibility_of_element_located(
                by_locator)).send_keys(Keys.ESCAPE)
