from instrument_repository.locators.instrument_repository_locators import InstumentReposiotryLocators
from instrument_repository.properties.instrument_repository_properties import TestProperties

class InstrunetRepositoryUtils:
    # add instrument sample data
    test_instrument_name = "NewInstrumentForTest"
    test_material_number = "test_material_number"
    test_serial_number = "test_serial_number"
    test_name = "test_name_input"
    test_version = "v1.1.1"
    test_document_name = "document_name_input"
    test_document_url = "https://roche.com"
    test_rudi = "rudi_input"
    test_gtin = "gtin_input"
    test_type = "type_input"
    test_building_location = "building_location_input"
    test_floor_and_room_location = "floor_and_room_location_input"
    test_responsible_person = "responsible_person_input"
    test_second_responsible_person = "second_responsible_person_input"
    test_software_varsion = "software_varsion_input"
    test_configure_baseline = "configure_baseline_input"
    test_system_status = "system_status_input"
    test_gxp_status = "gxp_status_input"
    test_belonging_to_group = "belonging_to_group_input"
    test_equipment_id = "equipment_id_input"
    test_manufacturer = "manufacturer_input"
    test_last_maintenance = "20-Oct-2021"
    test_next_maintenance = "23-Oct-2021"

    # edit instrument sample data
    test_edit_instrument_name = "EditNewInstrumentForTest"
    test_edit_name = "edit_test_name_input"
    test_edit_version = "edit_v1.1.1"
    test_edit_document_name = "edit_document_name_input"
    test_edit_document_url = "https://roche.com/edit"
    test_edit_rudi = "edit_rudi_input"
    test_edit_gtin = "edit_gtin_input"
    test_edit_type = "edit_type_input"
    test_edit_building_location = "edit_building_location_input"
    test_edit_floor_and_room_location = "edit_floor_and_room_location_input"
    test_edit_responsible_person = "edit_responsible_person_input"
    test_edit_second_responsible_person = "edit_second_responsible_person_input"
    test_edit_software_varsion = "edit_software_varsion_input"
    test_edit_configure_baseline = "edit_configure_baseline_input"
    test_edit_system_status = "edit_system_status_input"
    test_edit_gxp_status = "edit_gxp_status_input"
    test_edit_belonging_to_group = "edit_belonging_to_group_input"
    test_edit_equipment_id = "edit_equipment_id_input"
    test_edit_manufacturer = "edit_manufacturer_input"
    test_edit_last_maintenance = "10-Nov-2021"
    test_edit_next_maintenance = "15-Nov-2021"

    # data river instrument data
    test_data_river_material_number = "5524245001"
    test_data_river_serial_number = "1002"
    test_data_river_manufacturer = "data_river_manufacturer"
    test_data_river_instrument_name = "data_river_instrument_name"
    test_data_river_instrument_type = "data_river_instrument_type"
    test_data_river_gtin_number = "data_river_gtin_number"
    test_data_river_equipment_id = "data_river_equipment_id"


    def check_is_present_instrument_by_name(self, page, instrument_name):
        is_present = False
        page.refresh()
        # Get list of all instruments
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_instrument_name = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-instrumentName')]//div").text
            if selected_instrument_name == instrument_name:
                is_present = True
                break

        return is_present

    def check_is_present_instrument_by_serial_and_material_number_old(self, page, serial_number, material_number):
        is_present = False
        page.refresh()
        # Get list of all instruments
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_serial_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-serialNumber')]//div").text
            selected_material_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-materialNumber')]//div").text
            if selected_serial_number == serial_number and selected_material_number == material_number:
                is_present = True
                break

        return is_present

    def check_is_present_instrument_by_serial_and_material_number(self, page, serial_number, material_number):
        is_present = False
        page.refresh()
        # Get list of all instruments
        page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        instrument_with_serial_and_number_list = self.driver.find_elements_by_xpath(
            "//tr//td[contains(@data-testid,'-materialNumber')]//div[string()='"+material_number+"']//ancestor::tr//td[contains(@data-testid,'-serialNumber')]//div[string()='"+serial_number+"']")
        if len(instrument_with_serial_and_number_list)>0:
            is_present = True
        return is_present

    def check_is_present_document_with_name_and_url(self,page, document_name, document_url):
        is_present = False
        documents = page.driver.find_elements_by_xpath("//div[@data-testid='documents-data-form-document-list']"
        "//div[@data-testid='documents-data-form-document-list-info-row-name' and string()='"+document_name+"']"
        "//..//div[@data-testid='documents-data-form-document-list-info-row-documentId' and string()='"+document_url+"']")
        if len(documents)>0:
            is_present = True
        return is_present

    def check_is_present_test_with_name_and_version(self,page, test_name, test_version):
        is_present = False
        documents = page.driver.find_elements_by_xpath("//div[@data-testid='assays-data-form-test-list']"
        "//div[@data-testid='assays-data-form-test-list-info-row-name' and string()='"+test_name+"']"
        "//..//div[@data-testid='assays-data-form-test-list-info-row-version' and string()='"+test_version+"']")
        if len(documents)>0:
            is_present = True
        return is_present

    def get_instrument_with_serial_and_material_number(self, serial_number, material_number):
        instument_row = None
        # Get list of all instruments
        instrument_with_serial_and_number_list = self.driver.find_elements_by_xpath(
            "//tr//td[contains(@data-testid,'-materialNumber')]//div[string()='"+material_number+"']"
            "//ancestor::tr//td[contains(@data-testid,'-serialNumber')]//div[string()='"+serial_number+"']//ancestor::tr")
        if len(instrument_with_serial_and_number_list)>0:
                instument_row = instrument_with_serial_and_number_list[0]
        return instument_row

    def remove_instrument_by_name(self, page, instrument_name):

        # Get list of all instruments
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_instrument_name = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-instrumentName')]//div").text
            if selected_instrument_name in instrument_name:
                instrument_list[x].find_element_by_xpath(".//button[contains(@data-testid,'instrument-table-delete-button')]").click()
                # click confirm button
                page.click(InstumentReposiotryLocators.DELETE_INSTRUMENT_CONFIRM_BUTTON)
                page.invisibility_of_element(InstumentReposiotryLocators.DELETE_INSTRUMENT_CONFIRM_BUTTON)
                break

    def remove_instrument_by_serial_and_material_number(self, page, serial_number, material_number):
        # Filter instuments
        page.clear_element(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT)
        page.enter_text(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT, serial_number)
        # Get list of all instruments
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_serial_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-serialNumber')]//div").text
            selected_material_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-materialNumber')]//div").text
            if selected_serial_number == serial_number and selected_material_number == material_number:
                instrument_list[x].find_element_by_xpath(".//button[contains(@data-testid,'instrument-table-delete-button')]").click()
                # click confirm button
                page.click(InstumentReposiotryLocators.DELETE_INSTRUMENT_CONFIRM_BUTTON)
                page.invisibility_of_element(InstumentReposiotryLocators.DELETE_INSTRUMENT_CONFIRM_BUTTON)
                break

    def add_new_instrument(self, page):
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_BUTTON)
        # Change tab to instaled test and add new test
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_INSTALED_TEST_BUTTON)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_NAME_INPUT, self.test_name)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_VERSION_INPUT, self.test_version)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_ADD_BUTTON)
        # Change tab to edit documents and add document
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_EDIT_DOCUMENTS_BUTTON)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_NAME_INPUT, self.test_document_name)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_URL_INPUT, self.test_document_url)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_ADD_BUTTON)
        # Change tab to basic data and add test data
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_BASIC_DATA_BUTTON)
        page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SITE_NAME_SELECT)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_SITE_NAME_SELECT)
        site_name_list = page.visibility_of_all_elements(InstumentReposiotryLocators.ADD_INSTRUMENT_SITE_NAME_LIST)
        selected_site_name = site_name_list[0].text
        site_name_list[0].click()
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_MATERIAL_NUMBER_INPUT, self.test_material_number)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_SERIAL_NUMBER_INPUT, self.test_serial_number)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_NAME_INPUT, self.test_instrument_name)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_RUDI_INPUT, self.test_rudi)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_GTIN_INPUT, self.test_gtin)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_TYPE_INPUT, self.test_type)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_VISUALIZED_TRUE_BUTTON)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_BOOKABLE_TRUE_BUTTON)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_BUILDING_LOCATION_INPUT, self.test_building_location)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_FLOR_AND_ROOM_LOCATION_INPUT, self.test_floor_and_room_location)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_RESPONSIBLE_PERSON_INPUT, self.test_responsible_person)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_SECOND_RESPONSIBLE_PERSON_INPUT, self.test_second_responsible_person)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_SOFTWARE_VERSION_INPUT, self.test_software_varsion)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_CONF_BASELINE_INPUT, self.test_configure_baseline)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_SYSTEM_STATUS_INPUT, self.test_system_status)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_GXP_STATUS_INPUT, self.test_gxp_status)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_BELONGING_TO_GROUP_INPUT, self.test_belonging_to_group)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_EQUIPMENT_ID_INPUT, self.test_equipment_id)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_MANUFACTURER_INPUT, self.test_manufacturer)
        self.set_maintenance_dates(page, self.test_last_maintenance, self.test_next_maintenance)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)

        page.invisibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON, 15)

    def add_new_instrument_with_data_river_serial_and_material_number(self, page, serial_number, material_number):
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_BUTTON)
        # Change tab to basic data and add test data
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_BASIC_DATA_BUTTON)
        page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SITE_NAME_SELECT)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_SITE_NAME_SELECT)
        site_name_list = page.visibility_of_all_elements(InstumentReposiotryLocators.ADD_INSTRUMENT_SITE_NAME_LIST)
        site_name_list[0].click()
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_MATERIAL_NUMBER_INPUT, material_number)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_SERIAL_NUMBER_INPUT, serial_number)
        page.click(InstumentReposiotryLocators.INSTRUMENT_FETCH_FROM_DATA_RIVER_BUTTON)
        page.visibility_of_element(InstumentReposiotryLocators.NOTIFICATION_INSTUMENT_FETCHED_SUCCESS_INFO)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_NAME_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_NAME_INPUT, self.test_data_river_instrument_name)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_GTIN_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_GTIN_INPUT, self.test_data_river_gtin_number)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TYPE_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_TYPE_INPUT, self.test_type)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_EQUIPMENT_ID_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_EQUIPMENT_ID_INPUT, self.test_data_river_equipment_id)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)
        page.invisibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON, 15)

    def edit_instrument_data(self, page, instrument_row):
        instrument_row.find_element_by_xpath(".//button[@data-testid='instrument-table-edit-button']").click()
        # Change tab to instaled test and add new test
        self.edit_instrument_test_name_and_version(page,self.test_edit_name,self.test_edit_version)
        # Change tab to edit documents and add document
        self.edit_instrument_document_name_and_url(page, self.test_edit_document_name, self.test_edit_document_url)
        # Change tab to basic data and add test data
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_BASIC_DATA_BUTTON)
        page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SITE_NAME_SELECT)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_SITE_NAME_SELECT)
        site_name_list = page.visibility_of_all_elements(InstumentReposiotryLocators.ADD_INSTRUMENT_SITE_NAME_LIST)
        selected_site_name = site_name_list[0].text
        site_name_list[0].click()
        # Serial and material number should be  disabled
        page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_MATERIAL_NUMBER_INPUT_DISABLED)
        page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SERIAL_NUMBER_INPUT_DISABLED)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_NAME_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_NAME_INPUT, self.test_edit_instrument_name)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_RUDI_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_RUDI_INPUT, self.test_edit_rudi)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_GTIN_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_GTIN_INPUT, self.test_edit_gtin)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TYPE_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_TYPE_INPUT, self.test_edit_type)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_VISUALIZED_FALSE_BUTTON)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_VISUALIZED_FALSE_BUTTON)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_BOOKABLE_FALSE_BUTTON)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_BOOKABLE_FALSE_BUTTON)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_BUILDING_LOCATION_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_BUILDING_LOCATION_INPUT, self.test_edit_building_location)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_FLOR_AND_ROOM_LOCATION_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_FLOR_AND_ROOM_LOCATION_INPUT, self.test_edit_floor_and_room_location)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_RESPONSIBLE_PERSON_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_RESPONSIBLE_PERSON_INPUT, self.test_edit_responsible_person)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SECOND_RESPONSIBLE_PERSON_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_SECOND_RESPONSIBLE_PERSON_INPUT, self.test_edit_second_responsible_person)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SOFTWARE_VERSION_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_SOFTWARE_VERSION_INPUT, self.test_edit_software_varsion)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONF_BASELINE_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_CONF_BASELINE_INPUT, self.test_edit_configure_baseline)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SYSTEM_STATUS_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_SYSTEM_STATUS_INPUT, self.test_edit_system_status)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_GXP_STATUS_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_GXP_STATUS_INPUT, self.test_edit_gxp_status)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_BELONGING_TO_GROUP_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_BELONGING_TO_GROUP_INPUT, self.test_edit_belonging_to_group)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_EQUIPMENT_ID_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_EQUIPMENT_ID_INPUT, self.test_edit_equipment_id)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_MANUFACTURER_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_MANUFACTURER_INPUT, self.test_edit_manufacturer)
        self.set_maintenance_dates(page,  self.test_edit_last_maintenance, self.test_edit_next_maintenance)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)

        page.invisibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON, 15)

    def edit_instrument_document_name_and_url(self, page, document_name, document_url):
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_EDIT_DOCUMENTS_BUTTON)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_EDIT_BUTTON)
        page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_EDIT_ACCEPT_BUTTON)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_NAME_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_NAME_INPUT, document_name)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_URL_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_URL_INPUT, document_url)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_EDIT_ACCEPT_BUTTON)

    def edit_instrument_test_name_and_version(self, page, test_name, test_version):
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_INSTALED_TEST_BUTTON)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_EDIT_BUTTON)
        page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_EDIT_ACCEPT_BUTTON)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_NAME_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_NAME_INPUT, test_name)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_VERSION_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_VERSION_INPUT, test_version)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_EDIT_ACCEPT_BUTTON)

    def get_instrument_data_from_data_river(self, page, instrument_row):
        instrument_row.find_element_by_xpath(".//button[@data-testid='instrument-table-edit-button']").click()

        page.invisibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON, 15)

    def check_instrument_after_add_data(self, page, instrument_row):
        valid_data = True
        instrument_row.find_element_by_xpath(".//button[@data-testid='instrument-table-edit-button']").click()
        # Change tab to instaled test and add new test
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_INSTALED_TEST_BUTTON)
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_NAME_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_name else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_VERSION_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_version else False
        # Change tab to edit documents and add document
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_EDIT_DOCUMENTS_BUTTON)
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_NAME_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_document_name else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_URL_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_document_url else False
        # Change tab to basic data and add test data
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_BASIC_DATA_BUTTON)
        page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SITE_NAME_SELECT)
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_MATERIAL_NUMBER_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_material_number else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SERIAL_NUMBER_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_serial_number else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_NAME_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_instrument_name else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_RUDI_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_rudi else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_GTIN_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_gtin else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TYPE_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_type else False
        visualized_true_button_background = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_VISUALIZED_TRUE_BUTTON).value_of_css_property('background')
        bookable_true_button_background = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_BOOKABLE_TRUE_BUTTON).value_of_css_property('background')
        valid_data = valid_data if TestProperties.elementsCssColors['visualized_button']['active_background'] in visualized_true_button_background else False
        valid_data = valid_data if TestProperties.elementsCssColors['bookable_button']['active_background'] in bookable_true_button_background else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_BUILDING_LOCATION_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_building_location else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_FLOR_AND_ROOM_LOCATION_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_floor_and_room_location else False
        element = page.visibility_of_element( InstumentReposiotryLocators.ADD_INSTRUMENT_RESPONSIBLE_PERSON_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_responsible_person else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SECOND_RESPONSIBLE_PERSON_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_second_responsible_person else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SOFTWARE_VERSION_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_software_varsion else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONF_BASELINE_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_configure_baseline else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SYSTEM_STATUS_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_system_status else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_GXP_STATUS_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_gxp_status else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_BELONGING_TO_GROUP_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_belonging_to_group else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_EQUIPMENT_ID_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_equipment_id else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_MANUFACTURER_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_manufacturer else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_LAST_MAINTENANCE_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_last_maintenance else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_NEXT_MAINTENANCE_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_next_maintenance else False
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_CANCEL_BUTTON)
        page.invisibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CANCEL_BUTTON)

        return valid_data

    def check_instrument_after_edit_data(self, page, instrument_row):
        valid_data = True
        instrument_row.find_element_by_xpath(".//button[@data-testid='instrument-table-edit-button']").click()
        # Change tab to instaled test and add new test
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_INSTALED_TEST_BUTTON)
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_NAME_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_name else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TEST_VERSION_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_version else False
        # Change tab to edit documents and add document
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_EDIT_DOCUMENTS_BUTTON)
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_NAME_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_document_name else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_URL_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_document_url else False
        # Change tab to basic data and add test data
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_BASIC_DATA_BUTTON)
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_NAME_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_instrument_name else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_RUDI_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_rudi else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_GTIN_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_gtin else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TYPE_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_type else False
        visualized_true_button_background = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_VISUALIZED_TRUE_BUTTON).value_of_css_property('background')
        bookable_true_button_background = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_BOOKABLE_TRUE_BUTTON).value_of_css_property('background')
        valid_data = valid_data if TestProperties.elementsCssColors['visualized_button']['no_active_background'] in visualized_true_button_background else False
        valid_data = valid_data if TestProperties.elementsCssColors['bookable_button']['no_active_background'] in bookable_true_button_background else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_BUILDING_LOCATION_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_building_location else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_FLOR_AND_ROOM_LOCATION_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_floor_and_room_location else False
        element = page.visibility_of_element( InstumentReposiotryLocators.ADD_INSTRUMENT_RESPONSIBLE_PERSON_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_responsible_person else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SECOND_RESPONSIBLE_PERSON_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_second_responsible_person else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SOFTWARE_VERSION_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_software_varsion else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONF_BASELINE_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_configure_baseline else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SYSTEM_STATUS_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_system_status else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_GXP_STATUS_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_gxp_status else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_BELONGING_TO_GROUP_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_belonging_to_group else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_EQUIPMENT_ID_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_equipment_id else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_MANUFACTURER_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_manufacturer else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_LAST_MAINTENANCE_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_last_maintenance else False
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_NEXT_MAINTENANCE_INPUT).get_attribute("value")
        valid_data = valid_data if element in self.test_edit_next_maintenance else False
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_CANCEL_BUTTON)
        page.invisibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CANCEL_BUTTON)

        return valid_data

    def filter_instrument_and_go_to_edit(self, page, serial_number, material_number):
        page.enter_text(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT, serial_number)
        # Get list of instruments
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_serial_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-serialNumber')]//div").text
            selected_material_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-materialNumber')]//div").text
            if selected_serial_number == serial_number and selected_material_number == material_number:
                instrument_list[x].find_element_by_xpath(".//button[@data-testid='instrument-table-edit-button']").click()
                page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)
                break

    def valid_maintenance_dates(self, page, last_maintenance_date, next_maintenance_date):
        is_valid_data = True
        element = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_LAST_MAINTENANCE_INPUT).get_attribute("value")
        is_valid_data = is_valid_data if element == last_maintenance_date else False
        element = page.visibility_of_element(
            InstumentReposiotryLocators.ADD_INSTRUMENT_NEXT_MAINTENANCE_INPUT).get_attribute("value")
        is_valid_data = is_valid_data if element == next_maintenance_date else False
        return is_valid_data

    def set_maintenance_dates(self, page, last_maintenance_date, next_maintenance_date):
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_LAST_MAINTENANCE_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_LAST_MAINTENANCE_INPUT, last_maintenance_date)
        page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_NEXT_MAINTENANCE_INPUT)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_NEXT_MAINTENANCE_INPUT, next_maintenance_date)