from selenium.webdriver.common.by import By


class InstumentReposiotryLocators:
    MAIN_PAGE_HEADER = (By.XPATH, "//div[contains(@id,'RocheTopBar')]//span[contains(text(),'Instrument repository')]")
    MAIN_PAGE_SEARCH_INPUT = (By.XPATH, "//div[@data-testid='search']//input")
    ADD_INSTRUMENT_BUTTON = (By.XPATH, "//button[contains(@data-testid,'add-instrument-dialog-open-button')]")
    IMPORT_CSV_BUTTON = (By.XPATH, "//button[contains(@data-testid,'import-instrument-file-select')]")
    IMPORT_CSV_INPUT_FILE = (By.XPATH, "//input[contains(@data-testid,'file-input')]")
    OVERWRITE_SELECTED_DATA = (By.XPATH, "(//button[contains(@data-testid,'confirm-dialog-actions-button-approve')])[2]")
    IMPORT_OVERRWRITE_OPTION = (By.XPATH, "//span[@data-testid='import-overwrite-option']")
    DELETE_BUTTONS = (By.XPATH, "(//button[contains(@data-testid,'instrument-table-delete-button')])")
    CONFIRM_DELETE_BUTTON = (By.XPATH, "//button[contains(@data-testid,'confirm-dialog-actions-button-approve')]//span[contains(text(), 'Delete')]")
    ALL_BUTTON = (By.XPATH, "(//span[contains(@data-testid,'import-select-all-props')])")
    INSTRUMENT_NAME_BUTTON = (By.XPATH, "(//span[contains(@data-testid,'import-select-prop-instrumentName')])")
    ALL_BUTTON_CHECKED = (By.XPATH, "(//span[contains(@data-testid,'import-select-all-props')][contains(@class, 'Mui-checked')])")
    INSTRUMENT_NAME_CHECKED = (By.XPATH, "(//span[contains(@data-testid,'import-select-prop-instrumentName')][contains(@class, 'Mui-checked')])")
    INSTRUMENT_REPOSITORY_ROWS = (By.XPATH, "//div[contains(@data-testid,'custom-table')]//table//tbody//tr")
    IS_WARNING_NOTIFY = (By.XPATH, "//div[contains(@data-testid,'notify')]")
    IS_WARNING_NOTIFY_FOR_EMPTY_COLUMN_IN_CSV = (By.XPATH, "//div[contains(@data-testid,'notify-text')]")
    MAIN_PAGE_HEADER_USER_INFO = (By.XPATH, "//header//div[@data-testid='app-bar-user-info-user']//span")
    CLOSE_MODAL_EDIT = (By.XPATH, "//div[contains(@data-testid, 'instrument-repositorium-modal-title')]//button")

    # USER INFO POPOVER
    USER_INFO_POPOVER_LOGO = (By.XPATH, "//div[@data-testid='popover-user-menu-info-section']//div[@data-testid='popover-user-menu-info-section-logo']")
    USER_INFO_POPOVER_USERNAME = (By.XPATH, "//div[@data-testid='popover-user-menu-info-section']//div[@data-testid='popover-user-menu-info-section-username']")
    USER_INFO_POPOVER_EMAIL = (By.XPATH, "//div[@data-testid='popover-user-menu-info-section']//div[@data-testid='popover-user-menu-info-section-email']")
    # ISTRUMENTS TABLE
    TABLE_HEAD_SERIAL_NUMBER = (By.XPATH, "//div[@data-testid='custom-table']//th[@data-testid='table-head-serialNumber']")
    TABLE_HEAD_MATERIAL_NUMBER = (By.XPATH, "//div[@data-testid='custom-table']//th[@data-testid='table-head-materialNumber']")
    TABLE_HEAD_INSTRUMENT_TYPE = (By.XPATH, "//div[@data-testid='custom-table']//th[@data-testid='table-head-instrumentType']")
    TABLE_HEAD_INSTRUMENT_NAME = (By.XPATH, "//div[@data-testid='custom-table']//th[@data-testid='table-head-instrumentName']")
    TABLE_HEAD_FLOOR_AND_ROOM_LOCATION = (By.XPATH, "//div[@data-testid='custom-table']//th[@data-testid='table-head-floorAndRoomLocation']")
    TABLE_HEAD_RESPONSIBLE_PERSON = (By.XPATH, "//div[@data-testid='custom-table']//th[@data-testid='table-head-responsiblePerson']")
    TABLE_HEAD_IS_BOOKABLE = (By.XPATH, "//div[@data-testid='custom-table']//th[@data-testid='table-head-isBookable']")
    TABLE_HEAD_IS_VISUALIZED = (By.XPATH, "//div[@data-testid='custom-table']//th[@data-testid='table-head-isVisualized']")
    TABLE_HEAD_ACTIONS = (By.XPATH, "//div[@data-testid='custom-table']//th[@data-testid='table-head-actions']")
    INSTRUMENT_LIST = (By.XPATH, "//div[@data-testid='custom-table']//tr[contains(@data-testid,'-row')]")
    # ADD INSTRUMENT POPUP
    ADD_INSTRUMENT_TAB_BASIC_DATA_BUTTON = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                      "//button[@data-testid='tabs-for-modal-edit-tab-basic-data']")
    ADD_INSTRUMENT_MATERIAL_NUMBER_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                      "//div[@data-testid='basic-data-req-fields-instrument-material-number-input']//input")
    ADD_INSTRUMENT_MATERIAL_NUMBER_INPUT_DISABLED = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                               "//div[@data-testid='basic-data-req-fields-instrument-material-number-input']"
                                                               "//input[contains(@class,'disabled')]")
    ADD_INSTRUMENT_MATERIAL_NUMBER_HELPER = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                       "//div[@data-testid='basic-data-req-fields-instrument-material-number-input']"
                                                       "//p[@data-testid='basic-data-req-fields-instrument-helper-text-material-number-input']")
    ADD_INSTRUMENT_SERIAL_NUMBER_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                    "//div[@data-testid='basic-data-req-fields-instrument-serial-number-input']//input")
    ADD_INSTRUMENT_SERIAL_NUMBER_INPUT_DISABLED = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                             "//div[@data-testid='basic-data-req-fields-instrument-serial-number-input']"
                                                             "//input[contains(@class,'disabled')]")
    ADD_INSTRUMENT_SERIAL_NUMBER_HELPER = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                     "//div[@data-testid='basic-data-req-fields-instrument-serial-number-input']"
                                                     "//p[@data-testid='basic-data-req-fields-instrument-helper-text-serial-number-input']")
    ADD_INSTRUMENT_SITE_NAME_SELECT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                 "//div[@data-testid='basic-data-req-fields-instrument-siteName']")
    ADD_INSTRUMENT_SITE_NAME_LIST = (By.XPATH, "//ul[@aria-labelledby='basic-data-req-fields-instrument-siteName']//li")
    ADD_INSTRUMENT_NAME_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                           "//div[@data-testid='basic-data-req-fields-instrument-instrument-name-input']//input")
    ADD_INSTRUMENT_NAME_HELPER = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                            "//div[@data-testid='basic-data-req-fields-instrument-instrument-name-input']"
                                            "//p[@data-testid='basic-data-req-fields-instrument-helper-text-instrument-name-input']")
    ADD_INSTRUMENT_TYPE_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                           "//div[@data-testid='basic-data-req-fields-instrument-instrument-type-input']//input")
    ADD_INSTRUMENT_TYPE_HELPER = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                            "//div[@data-testid='basic-data-req-fields-instrument-instrument-type-input']"
                                            "//p[@data-testid='basic-data-req-fields-instrument-helper-text-instrument-type-input']")
    ADD_INSTRUMENT_GTIN_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                           "//div[@data-testid='basic-data-req-fields-instrument-instrument-GTIN-input']//input")
    ADD_INSTRUMENT_GTIN_HELPER = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                            "//div[@data-testid='basic-data-req-fields-instrument-instrument-GTIN-input']"
                                            "//p[@data-testid='basic-data-req-fields-instrument-helper-text-instrument-GTIN-input']")
    ADD_INSTRUMENT_RUDI_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                           "//div[@data-testid='basic-data-req-fields-instrument-instrument-RUDI-input']//input")
    ADD_INSTRUMENT_BOOKABLE_TRUE_BUTTON = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                     "//button[@data-testid='additional-info-bookable-true']")
    ADD_INSTRUMENT_BOOKABLE_FALSE_BUTTON = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                      "//button[@data-testid='additional-info-bookable-false']")
    ADD_INSTRUMENT_VISUALIZED_TRUE_BUTTON = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                       "//button[@data-testid='additional-info-visualized-true']")
    ADD_INSTRUMENT_VISUALIZED_FALSE_BUTTON = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                        "//button[@data-testid='additional-info-visualized-false']")
    ADD_INSTRUMENT_SITE_LOCATION_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                    "//div[@data-testid='basic-data-additional-info-fields-instrument-site-location-input']//input")
    ADD_INSTRUMENT_BUILDING_LOCATION_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                        "//div[@data-testid='basic-data-additional-info-fields-instrument-building-location-input']//input")
    ADD_INSTRUMENT_FLOR_AND_ROOM_LOCATION_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                             "//div[@data-testid='basic-data-additional-info-fields-instrument-floor-and-room-location-input']//input")
    ADD_INSTRUMENT_RESPONSIBLE_PERSON_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                         "//div[@data-testid='basic-data-additional-info-fields-instrument-responsible-person-input']//input")
    ADD_INSTRUMENT_SECOND_RESPONSIBLE_PERSON_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                                "//div[@data-testid='basic-data-additional-info-fields-instrument-second-responsible-person-input']//input")
    ADD_INSTRUMENT_SOFTWARE_VERSION_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                       "//div[@data-testid='basic-data-additional-info-fields-instrument-software-version-input']//input")
    ADD_INSTRUMENT_CONF_BASELINE_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                    "//div[@data-testid='basic-data-additional-info-fields-instrument-configuration-baseline-input']//input")
    ADD_INSTRUMENT_SYSTEM_STATUS_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                    "//div[@data-testid='basic-data-additional-info-fields-instrument-system-status-input']//input")
    ADD_INSTRUMENT_GXP_STATUS_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                 "//div[@data-testid='basic-data-additional-info-fields-instrument-gxp-status-input']//input")
    ADD_INSTRUMENT_BELONGING_TO_GROUP_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                         "//div[@data-testid='basic-data-additional-info-fields-instrument-belonging-to-group-input']//input")
    ADD_INSTRUMENT_EQUIPMENT_ID_INPUT = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                   "//div[@data-testid='basic-data-additional-info-fields-instrument-req-equipmentId-input']//input")
    ADD_INSTRUMENT_MANUFACTURER_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                         "//div[@data-testid='basic-data-additional-info-fields-instrument-req-manufacturer-input']//input")
    ADD_INSTRUMENT_LAST_MAINTENANCE_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                       "//div[@data-testid='basic-data-additional-info-fields-instrument-date-of-last-maintanance-input']//input")
    ADD_INSTRUMENT_NEXT_MAINTENANCE_INPUT = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-content']"
                                                       "//div[@data-testid='basic-data-additional-info-fields-instrument-date-of-next-maintanance-input']//input")
    ADD_INSTRUMENT_CONFIRM_BUTTON = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-action-buttons']"
                                               "//button[@data-testid='instrument-repositorium-modal-action-button-confirm']")
    ADD_INSTRUMENT_CANCEL_BUTTON = (By.XPATH, "//div[@data-testid='instrument-repositorium-modal-action-buttons']"
                                              "//button[@data-testid='instrument-repositorium-modal-action-button-cancel']")
    ADD_INSTRUMENT_TESTS_TITLE = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                            "//*[@data-testid='assays-data-form-title']")
    ADD_INSTRUMENT_TAB_INSTALED_TEST_BUTTON = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                         "//button[@data-testid='tabs-for-modal-edit-tab-installed-tests']")
    ADD_INSTRUMENT_TEST_NAME_INPUT = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                "//div[@data-testid='assays-data-form-test-name-input']//input")
    ADD_INSTRUMENT_TEST_EDIT_BUTTON = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                 "//button[@data-testid='assays-data-form-test-list-edit-iconbutton']")
    ADD_INSTRUMENT_TEST_EDIT_ACCEPT_BUTTON = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                        "//button[@data-testid='assays-data-form-test-button-edit']")
    ADD_INSTRUMENT_TEST_VERSION_INPUT = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                   "//div[@data-testid='assays-data-form-test-version-input']//input")
    ADD_INSTRUMENT_TEST_ADD_BUTTON = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                "//button[@data-testid='assays-data-form-test-button-adding-new']")
    ADD_INSTRUMENT_TAB_EDIT_DOCUMENTS_BUTTON = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                          "//button[@data-testid='tabs-for-modal-edit-tab-documents']")
    ADD_INSTRUMENT_DOCUMENT_TITLE = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                               "//div[@data-testid='documents-data-form-title']")
    ADD_INSTRUMENT_TEST_DELETE_BUTTON_LIST = (By.XPATH, "//div[@data-testid='assays-data-form-test-list']"
                                                        "//button[@data-testid='assays-data-form-test-list-delete-iconbutton']")
    ADD_INSTRUMENT_DOCUMENT_NAME_INPUT = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                    "//div[@data-testid='documents-data-form-document-name-input']//input")
    ADD_INSTRUMENT_DOCUMENT_URL_INPUT = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                   "//div[@data-testid='documents-data-form-document-documentId-input']//input")
    ADD_INSTRUMENT_DOCUMENT_EDIT_BUTTON = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                     "//button[@data-testid='documents-data-form-document-list-edit-iconbutton']")
    ADD_INSTRUMENT_DOCUMENT_EDIT_ACCEPT_BUTTON = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                            "//button[@data-testid='documents-data-form-document-button-edit']")
    ADD_INSTRUMENT_DOCUMENT_DELETE_BUTTON_LIST = (By.XPATH, "//div[@data-testid='documents-data-form-document-list']"
                                                            "//button[@data-testid='documents-data-form-document-list-delete-iconbutton']")
    ADD_INSTRUMENT_DOCUMENT_ADD_BUTTON = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                    "//button[@data-testid='documents-data-form-document-button-adding-new']")
    DELETE_INSTRUMENT_CONFIRM_BUTTON = (By.XPATH, "//div[@data-testid='confirm-dialog-actions']"
                                                  "//button[@data-testid='confirm-dialog-actions-button-approve']"
                                                  "//span[contains(text(),'Delete instrument')]")
    INSTRUMENT_FETCH_FROM_DATA_RIVER_BUTTON = (By.XPATH, "//form[@data-testid='instrument-repositorium-modal-form']"
                                                              "//button[@data-testid='fetchInstrumentFromDataRiver']")
    NOTIFICATION_INSTUMENT_FETCHED_SUCCESS_INFO = (By.XPATH, "//div[@data-testid='notify']//div[contains(string(), 'Instrument have been fetched successfully!')]")
    NOTIFICATION_INSTUMENT_IMPORT_FROM_CSV_SUCCESS_INFO = (By.XPATH, "//div[@data-testid='notify']//div[contains(string(), 'Instruments have been successfully imported')]")
