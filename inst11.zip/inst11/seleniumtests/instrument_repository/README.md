raport: https://digitallab.pages.roche.com/instrument-repository-fronted/

Guidelines: https://code.roche.com/digitallab/booking-frontend/-/blob/develop/seleniumtests/README.md
