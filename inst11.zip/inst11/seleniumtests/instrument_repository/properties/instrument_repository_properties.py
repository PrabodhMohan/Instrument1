class TestProperties(object):
    usersForTest = {
        'test9': {'userLogin': 'ready4s+test9@protonmail.com', 'userPassword': 'Lolopolo1!'},
        'test16': {'userLogin': 'ready4s+test16@protonmail.com', 'userPassword': 'Lolopolo1!'},
        'test17': {'userLogin': 'ready4s+test17@protonmail.com', 'userPassword': 'Lolopolo1!'},
        'test18': {'userLogin': 'ready4s+test18@protonmail.com', 'userPassword': 'Lolopolo1!'},
        'test19': {'userLogin': 'ready4s+test19@protonmail.com', 'userPassword': 'Lolopolo1!'},
        'test20': {'userLogin': 'ready4s+test20@protonmail.com', 'userPassword': 'Lolopolo1!'},
        'test21': {'userLogin': 'ready4s+test21@protonmail.com', 'userPassword': 'Lolopolo1!'},
        'test22': {'userLogin': 'ready4s+test22@protonmail.com', 'userPassword': 'Lolopolo1!'}
    }

    testPages = {
        'InstrumentRepository': 'https://d1wa9f7z183p46.cloudfront.net/'
    }

    testTimeOuts = {
        'InstrumentRepository': 15,
        'InstrumentRepositoryLong': 30
    }

    testChromeDriverPath = {
        'InstrumentRepository': "chromedriver"
    }

    elementsCssColors = {
        'visualized_button': {'active_background': 'rgb(224, 236, 249)', 'no_active_background': 'rgb(250, 250, 250)'},
        'bookable_button': {'active_background': 'rgb(224, 236, 249)', 'no_active_background': 'rgb(250, 250, 250)'}
    }

    csvSampleRows = {
        'row1': {'Serial number': '111',
                 'Material number': '111',
                 'Type': '6800', 'Name': 'instrument first',
                 'ResponsiblePerson': 'john',
                 'SoftVersion': '1.01.2001',
                 'test': 'test'},
        'row2': {'Serial number': '1313',
                 'Material number': '1313',
                 'Type': '5800',
                 'Name': 'Instrument second',
                 'ResponsiblePerson': 'mike',
                 'SoftVersion': '1.01.2001',
                 'test': 'test'},
        'row3': {'Serial number': '777',
                 'Material number': '777',
                 'Type': '5800',
                 'Name': 'instrument third',
                 'ResponsiblePerson': 'john',
                 'SoftVersion': '1.01.2001',
                 'test': 'test'}
    }
