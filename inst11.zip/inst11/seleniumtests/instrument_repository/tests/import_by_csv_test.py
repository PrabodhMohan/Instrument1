import unittest
import os
from time import sleep
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ExtendedConditions
from instrument_repository.locators.instrument_repository_locators import InstumentReposiotryLocators
from instrument_repository.properties.instrument_repository_properties import TestProperties
from instrument_repository.utils.BasePage import BasePage
from instrument_repository.utils.login_instument_repository import LoginInstrumentRepository

# Retina-ID IPSV_LOG-128777 || ROC 952 \ 994
class ImportCSVTest(unittest.TestCase):

    # TESTS FOR DESKTOP
    def test_main_page_desktop(self):
        timeout = TestProperties.testTimeOuts['InstrumentRepository']

        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test9')
        page = BasePage(self.driver)

        # Check before start is date csv exist, if yes delete it
        elements_row_before = page.visibility_of_all_elements(
                InstumentReposiotryLocators.INSTRUMENT_REPOSITORY_ROWS)
        ImportCSVTest.if_data_exist_from_csv_delete(self,page, elements_row_before)
        sleep(2)
        # Import file csv
        import_csv = page.presence_of_element(InstumentReposiotryLocators.IMPORT_CSV_INPUT_FILE)
        import_csv.send_keys(os.path.abspath(os.path.join(os.path.dirname(__file__), "../resources/file_import_test.csv")))
        sleep(2)
        page.visibility_of_element(InstumentReposiotryLocators.ALL_BUTTON).click()
        page.visibility_of_element(InstumentReposiotryLocators.ALL_BUTTON_CHECKED)
        overwrite_selected_data = page.visibility_of_element(InstumentReposiotryLocators.OVERWRITE_SELECTED_DATA)
        overwrite_selected_data.click()
        sleep(2)
        # Check added data
        elements_row = page.visibility_of_all_elements(
                InstumentReposiotryLocators.INSTRUMENT_REPOSITORY_ROWS)
        self.assertTrue(ImportCSVTest.check_added_csv(self,page, elements_row))
        sleep(2)
        # Delete added data
        ImportCSVTest.if_data_exist_from_csv_delete(self,page, elements_row)
        # Import file csv empty
        import_csv_empty = page.presence_of_element(InstumentReposiotryLocators.IMPORT_CSV_INPUT_FILE)
        os.path.abspath(os.path.join(os.path.dirname(__file__), "../resources/file_import_test_empty.csv"))
        import_csv_empty.send_keys(os.path.abspath(os.path.join(os.path.dirname(__file__), "../resources/file_import_test_empty.csv")))
        sleep(2)
        page.visibility_of_element(InstumentReposiotryLocators.IS_WARNING_NOTIFY)
        # Import file csv by name
        import_csv = page.presence_of_element(InstumentReposiotryLocators.IMPORT_CSV_INPUT_FILE)
        import_csv.send_keys( os.path.abspath(os.path.join(os.path.dirname(__file__), "../resources/file_import_test.csv")))
        sleep(2)
        page.visibility_of_element(InstumentReposiotryLocators.INSTRUMENT_NAME_BUTTON).click()
        page.visibility_of_element(InstumentReposiotryLocators.INSTRUMENT_NAME_CHECKED)
        overwrite_selected_data = page.visibility_of_element(InstumentReposiotryLocators.OVERWRITE_SELECTED_DATA)
        overwrite_selected_data.click()
        sleep(2)
        elements_row_name = page.visibility_of_all_elements(
                InstumentReposiotryLocators.INSTRUMENT_REPOSITORY_ROWS)
        self.assertTrue(ImportCSVTest.check_added_csv_name(self, elements_row_name))
        # Delete added data
        ImportCSVTest.if_data_exist_from_csv_delete(self,page, elements_row_name)
        # Import file csv without name
        import_csv = page.presence_of_element(InstumentReposiotryLocators.IMPORT_CSV_INPUT_FILE)
        import_csv.send_keys(os.path.abspath(os.path.join(os.path.dirname(__file__), "../resources/file_import_test_without_name.csv")))
        page.visibility_of_element(InstumentReposiotryLocators.IS_WARNING_NOTIFY_FOR_EMPTY_COLUMN_IN_CSV)
        self.driver.close()


    def check_added_csv(self,page, elements):
        numberOfShortNotifications = len(elements)
        # print(numberOfShortNotifications)
        is_added_1_row = False
        is_added_2_row = False
        is_added_3_row = False

        # Varables the same like in file csv
        row1 = 'row1'
        row2 = 'row2'
        row3 = 'row3'
        serial_number = 'Serial number'
        material_number = 'Material number'
        type = 'Type'
        name = 'Name'
        person = 'ResponsiblePerson'
        soft_version = 'SoftVersion'
        test = 'test'
        added_1_row = [TestProperties.csvSampleRows[row1][serial_number],
                       TestProperties.csvSampleRows[row1][material_number],
                       TestProperties.csvSampleRows[row1][type],
                       TestProperties.csvSampleRows[row1][name],
                       TestProperties.csvSampleRows[row1][person],
                       TestProperties.csvSampleRows[row1][soft_version],
                       TestProperties.csvSampleRows[row1][test]]
        added_2_row = [TestProperties.csvSampleRows[row2][serial_number],
                       TestProperties.csvSampleRows[row2][material_number],
                       TestProperties.csvSampleRows[row2][type],
                       TestProperties.csvSampleRows[row2][name],
                       TestProperties.csvSampleRows[row2][person],
                       TestProperties.csvSampleRows[row2][soft_version],
                       TestProperties.csvSampleRows[row2][test]]
        added_3_row = [TestProperties.csvSampleRows[row3][serial_number],
                       TestProperties.csvSampleRows[row3][material_number],
                       TestProperties.csvSampleRows[row3][type],
                       TestProperties.csvSampleRows[row3][name],
                       TestProperties.csvSampleRows[row3][person],
                       TestProperties.csvSampleRows[row3][soft_version],
                       TestProperties.csvSampleRows[row3][test]]

        for x in range(numberOfShortNotifications-1):
            value_col_1_obj = elements[x].find_elements_by_xpath(".//td")[0]
            value_col_1 = value_col_1_obj.text
            print(value_col_1)
            value_col_2_obj = elements[x].find_elements_by_xpath(".//td")[1]
            value_col_2 = value_col_2_obj.text
            print(value_col_2)
            value_col_3_obj = elements[x].find_elements_by_xpath(".//td")[2]
            value_col_3 = value_col_3_obj.text
            print(value_col_3)
            value_col_4_obj = elements[x].find_elements_by_xpath(".//td")[3]
            value_col_4 = value_col_4_obj.text
            print(value_col_4)
            value_col_5_obj = elements[x].find_elements_by_xpath(".//td")[6]
            value_col_5 = value_col_5_obj.text
            print(value_col_5)


            print(value_col_1+" "+value_col_2+" "+value_col_3+" "+value_col_4)
            print(added_1_row[2]+" "+added_2_row[2]+" "+added_3_row[2])
            if value_col_1 in added_1_row[0] or value_col_1 in added_2_row[0] or value_col_1 in added_3_row[0]:
                if value_col_1 == added_1_row[0]:
                    if value_col_2 == added_1_row[1]:
                        if value_col_3 == added_1_row[2]:
                            if value_col_4 == added_1_row[3]:
                                self.check_values_in_edits(page, elements[x], added_1_row)
                                is_added_1_row = True
                if value_col_1 == added_2_row[0]:
                    if value_col_2 == added_2_row[1]:
                        if value_col_3 == added_2_row[2]:
                            if value_col_4 == added_2_row[3]:
                                is_added_2_row = True
                if value_col_1 == added_3_row[0]:
                    if value_col_2 == added_3_row[1]:
                        if value_col_3 == added_3_row[2]:
                            if value_col_4 == added_3_row[3]:
                                 is_added_3_row = True
        print("First row added " + str(is_added_1_row) + " 2 row added " + str(
            is_added_2_row) + " Third row added " + str(is_added_3_row))
        if is_added_1_row == True and is_added_2_row == True and is_added_3_row == True:
            return True
        else:
            return False

    def check_added_csv_name(self, elements):
        numberOfShortNotifications = len(elements)
        # print(numberOfShortNotifications)
        is_added_1_row = False
        is_added_2_row = False
        is_added_3_row = False
        for x in range(numberOfShortNotifications - 1):
            value_col_1_obj = elements[x].find_elements_by_xpath(".//td")[0]
            value_col_1 = value_col_1_obj.text
            # print(value_col_1)
            value_col_2_obj = elements[x].find_elements_by_xpath(".//td")[1]
            value_col_2 = value_col_2_obj.text
            # print(value_col_2)
            value_col_3_obj = elements[x].find_elements_by_xpath(".//td")[2]
            value_col_3 = value_col_3_obj.text
            # print(value_col_3)
            value_col_4_obj = elements[x].find_elements_by_xpath(".//td")[3]
            value_col_4 = value_col_4_obj.text
            # print(value_col_4)
            row1 = 'row1'
            row2 = 'row2'
            row3 = 'row3'
            serial_number = 'Serial number'
            material_number = 'Material number'
            type = 'Type'
            name = 'Name'
            empty = '-'
            added_1_row = [TestProperties.csvSampleRows[row1][serial_number],
                           TestProperties.csvSampleRows[row1][material_number],
                           TestProperties.csvSampleRows[row1][type],
                           TestProperties.csvSampleRows[row1][name]]
            added_2_row = [TestProperties.csvSampleRows[row2][serial_number],
                           TestProperties.csvSampleRows[row2][material_number],
                           TestProperties.csvSampleRows[row2][type],
                           TestProperties.csvSampleRows[row2][name]]
            added_3_row = [TestProperties.csvSampleRows[row3][serial_number],
                           TestProperties.csvSampleRows[row3][material_number],
                           TestProperties.csvSampleRows[row3][type],
                           TestProperties.csvSampleRows[row3][name]]

            # print(value_col_1 + " " + value_col_2 + " " + value_col_3 + " " + value_col_4)
            # print(added_1_row[1] + " " + added_2_row[1] + " " + added_3_row[1])
            if value_col_1 in added_1_row[0] or value_col_1 in added_2_row[0] or value_col_1 in added_3_row[0]:
                if value_col_1 == added_1_row[0]:
                    if value_col_2 == added_1_row[1]:
                        if value_col_3 == empty:
                            if value_col_4 == added_1_row[3]:
                                is_added_1_row = True

                if value_col_1 == added_2_row[0]:
                    if value_col_2 == added_2_row[1]:
                        if value_col_3 == empty:
                            if value_col_4 == added_2_row[3]:
                                is_added_2_row = True
                if value_col_1 == added_3_row[0]:
                    if value_col_2 == added_3_row[1]:
                        if value_col_3 == empty:
                            if value_col_4 == added_3_row[3]:
                                is_added_3_row = True
        # print("First row added " + str(is_added_1_row) + " 2 row added " + str(
        #     is_added_2_row) + " Third row added " + str(is_added_3_row))
        if is_added_1_row == True and is_added_2_row == True and is_added_3_row == True:
            return True
        else:
            return False

    def if_data_exist_from_csv_delete(self,page, elements):
        timeout = TestProperties.testTimeOuts['InstrumentRepository']
        numberOfShortNotifications = len(elements)
        # print(numberOfShortNotifications)
        list_with_index_to_delete_rows = []
        for x in range(numberOfShortNotifications - 1):
            value_col_1_obj = elements[x].find_elements_by_xpath(".//td")[0]
            value_col_1 = value_col_1_obj.text
            # print(value_col_1)
            added_1_row = TestProperties.csvSampleRows['row1']['Serial number']
            added_2_row = TestProperties.csvSampleRows['row2']['Serial number']
            added_3_row = TestProperties.csvSampleRows['row3']['Serial number']
            # print(added_1_row+" "+added_2_row+" "+" "+added_3_row)
            if value_col_1 in added_1_row or value_col_1 in added_2_row or value_col_1 in added_3_row:
                    list_with_index_to_delete_rows.append(x)
            else:
                continue
        reverse_list=reversed(list_with_index_to_delete_rows)
        # print(list_with_index_to_delete_rows)
        for x in reverse_list:
            # print(x)
            # print(
            #     "I will find delete button and cliick")  # pozbierac tablice numerow wierszow do suniecia albo in po przecinku
            elements[x].find_element_by_xpath(
                ".//td//div//button[contains(@data-testid,'instrument-table-delete-button')]").click()
            # print("confirm delete")
            page.visibility_of_element(InstumentReposiotryLocators.CONFIRM_DELETE_BUTTON)
            page.click(InstumentReposiotryLocators.CONFIRM_DELETE_BUTTON)
            # print("deleted")
            sleep(2)

    def check_values_in_edits(self, page, element, list_to_check):
        element.find_element_by_xpath(".//button[contains(@data-testid, 'instrument-table-edit-button')]").click()
        page.click(InstumentReposiotryLocators.CLOSE_MODAL_EDIT)