import unittest
from instrument_repository.utils.BasePage import BasePage
from instrument_repository.utils.login_instument_repository import LoginInstrumentRepository
from instrument_repository.utils.InstrumentRepositoryUtils import InstrunetRepositoryUtils

# Retina-ID IPSV_LOG-77474 || ROC-967
class RemoveInstrumentFromRepositoryTest(unittest.TestCase):

    test_material_number = "test_material_number"
    test_serial_number = "test_serial_number"

    @classmethod
    def setUpClass(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        # Check that instrument is present
        instrument_exist = InstrunetRepositoryUtils.check_is_present_instrument_by_serial_and_material_number(self, page, self.test_serial_number, self.test_material_number)

        if not instrument_exist:
            # Add new defined insturment
            utils = InstrunetRepositoryUtils()
            utils.add_new_instrument(page)

        self.driver.close()

    def test_remove_instrument_from_repository(self):

        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)
        # Check that instrument with name is present
        instrument_exist = InstrunetRepositoryUtils.check_is_present_instrument_by_serial_and_material_number(self, page, self.test_serial_number, self.test_material_number)
        self.assertTrue(instrument_exist)
        # Remove application by name
        utils = InstrunetRepositoryUtils()
        utils.remove_instrument_by_serial_and_material_number(page, self.test_serial_number, self.test_material_number)
        # Check that instrument with name is not present
        instrument_exist = InstrunetRepositoryUtils.check_is_present_instrument_by_serial_and_material_number(self, page, self.test_serial_number, self.test_material_number)
        self.assertFalse(instrument_exist)

        self.driver.close()