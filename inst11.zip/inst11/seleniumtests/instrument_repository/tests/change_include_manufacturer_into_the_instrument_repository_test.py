import unittest
from instrument_repository.utils.InstrumentRepositoryUtils import InstrunetRepositoryUtils
from instrument_repository.utils.BasePage import BasePage
from instrument_repository.locators.instrument_repository_locators import InstumentReposiotryLocators
from instrument_repository.utils.login_instument_repository import LoginInstrumentRepository
import os
from time import sleep

# Retina-ID IPSV_LOG-12877 || ROC 952 \ 994
class ChangeIncludeManufacurerIntoTheInstrumentRepositoryTest(unittest.TestCase):

    test_data_river_material_number = "5524245001"
    test_data_river_serial_number = "1002"
    test_data_river_manufacturer = "Roche"
    test_edit_manufacturer = "test_edit_manufacturer"
    test_manufacturer_from_csv = "test_import_from_csv_manufacturer"

    @classmethod
    def setUpClass(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        # Check that instrument is present
        instrument_exist = InstrunetRepositoryUtils.check_is_present_instrument_by_serial_and_material_number(self,page, self.test_data_river_serial_number,self.test_data_river_material_number)

        if not instrument_exist:
            # Add new defined insturment
            utils = InstrunetRepositoryUtils()
            utils.add_new_instrument_with_data_river_serial_and_material_number(page, self.test_data_river_serial_number, self.test_data_river_material_number)

        self.driver.close()

    def test_01_change_manufacturer_from_edit(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        edit_instrument = False
        # Filter instuments
        page.enter_text(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT, self.test_data_river_serial_number)
        # Get list of instruments
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_serial_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-serialNumber')]//div").text
            selected_material_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-materialNumber')]//div").text
            if selected_serial_number == self.test_data_river_serial_number and selected_material_number == self.test_data_river_material_number:
                instrument_list[x].find_element_by_xpath(".//button[@data-testid='instrument-table-edit-button']").click()
                # Edit instrument data
                page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_BASIC_DATA_BUTTON)
                page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_MANUFACTURER_INPUT)
                page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_MANUFACTURER_INPUT, self.test_edit_manufacturer)
                page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)
                page.invisibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)
                edit_instrument = True
                break
        self.assertTrue(edit_instrument)

        # Check manufacturer field after fetch from data river
        # page.refresh()
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_serial_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-serialNumber')]//div").text
            selected_material_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-materialNumber')]//div").text
            if selected_serial_number == self.test_data_river_serial_number and selected_material_number == self.test_data_river_material_number:
                # Edit instrument data
                instrument_list[x].find_element_by_xpath(".//button[@data-testid='instrument-table-edit-button']").click()
                manufacturer = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_MANUFACTURER_INPUT).get_attribute("value")
                self.assertEqual(manufacturer, self.test_edit_manufacturer)
                break

        self.driver.close()

    def test_02_change_manufacturer_from_data_river(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        edit_instrument = False
        # Filter instuments
        page.enter_text(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT, self.test_data_river_serial_number)
        # Get list of instruments
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_serial_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-serialNumber')]//div").text
            selected_material_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-materialNumber')]//div").text
            if selected_serial_number == self.test_data_river_serial_number and selected_material_number == self.test_data_river_material_number:
                # Edit instrument data
                instrument_list[x].find_element_by_xpath(".//button[@data-testid='instrument-table-edit-button']").click()
                page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_BASIC_DATA_BUTTON)
                page.click(InstumentReposiotryLocators.INSTRUMENT_FETCH_FROM_DATA_RIVER_BUTTON)
                page.visibility_of_element(InstumentReposiotryLocators.NOTIFICATION_INSTUMENT_FETCHED_SUCCESS_INFO)
                page.clear_element(InstumentReposiotryLocators.ADD_INSTRUMENT_EQUIPMENT_ID_INPUT)
                page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_EQUIPMENT_ID_INPUT,"test_equipment_id")
                page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)
                page.invisibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)
                edit_instrument = True
                break
        self.assertTrue(edit_instrument)
        # Check manufacturer field after fetch from data river
        # Filter instuments
        page.enter_text(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT, self.test_data_river_serial_number)
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_serial_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-serialNumber')]//div").text
            selected_material_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-materialNumber')]//div").text
            if selected_serial_number == self.test_data_river_serial_number and selected_material_number == self.test_data_river_material_number:
                # Edit instrument data
                instrument_list[x].find_element_by_xpath(".//button[@data-testid='instrument-table-edit-button']").click()
                manufacturer = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_MANUFACTURER_INPUT).get_attribute("value")
                self.assertEqual(manufacturer, self.test_data_river_manufacturer)
                break

        self.driver.close()

    def test_03_change_manufacturer_from_csv_import(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        # Import file csv
        import_csv = page.presence_of_element(InstumentReposiotryLocators.IMPORT_CSV_INPUT_FILE)

        import_csv.send_keys(os.path.abspath(os.path.join(os.path.dirname(__file__), "../resources/test_update_mainteiner.csv")))
        sleep(1)
        page.click(InstumentReposiotryLocators.ALL_BUTTON)
        page.visibility_of_element(InstumentReposiotryLocators.ALL_BUTTON_CHECKED)
        page.click(InstumentReposiotryLocators.IMPORT_OVERRWRITE_OPTION)
        page.click(InstumentReposiotryLocators.OVERWRITE_SELECTED_DATA)
        page.visibility_of_element(InstumentReposiotryLocators.NOTIFICATION_INSTUMENT_IMPORT_FROM_CSV_SUCCESS_INFO)
        page.invisibility_of_element(InstumentReposiotryLocators.NOTIFICATION_INSTUMENT_IMPORT_FROM_CSV_SUCCESS_INFO)

        # Check manufacturer field after import from csv file
        # Filter instuments
        page.enter_text(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT, self.test_data_river_serial_number)
        manufacturer="Empty"
        # Get list of instruments
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_serial_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-serialNumber')]//div").text
            selected_material_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-materialNumber')]//div").text
            print(selected_serial_number)
            print(selected_material_number)
            if selected_serial_number == self.test_data_river_serial_number and selected_material_number == self.test_data_river_material_number:
                # Edit instrument data
                instrument_list[x].find_element_by_xpath(".//button[@data-testid='instrument-table-edit-button']").click()
                manufacturer = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_MANUFACTURER_INPUT).get_attribute("value")
                break
        self.assertEqual(manufacturer, self.test_manufacturer_from_csv)

        self.driver.close()
