import unittest
from instrument_repository.utils.BasePage import BasePage
from instrument_repository.utils.login_instument_repository import LoginInstrumentRepository
from instrument_repository.utils.InstrumentRepositoryUtils import InstrunetRepositoryUtils
from instrument_repository.locators.instrument_repository_locators import InstumentReposiotryLocators

# Retina-ID IPSV_LOG-77476 || ROC-968 / ROC-1128
class ChangeInstrumentDataInRepositoryTest(unittest.TestCase):

    test_material_number = "test_material_number"
    test_serial_number = "test_serial_number"

    @classmethod
    def setUpClass(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        # Check that instrument is present
        instrument_exist = InstrunetRepositoryUtils.check_is_present_instrument_by_serial_and_material_number(self,page, self.test_serial_number,self.test_material_number)

        if not instrument_exist:
            # Add new defined insturment
            utils = InstrunetRepositoryUtils()
            utils.add_new_instrument(page)

        self.driver.close()

    def test_01_change_instrument_data_in_repository(self):

        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)
        edit_instrument = False

        # Filter instuments
        page.enter_text(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT, self.test_serial_number)

        # Get list of instruments
        page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)

        selected_instument_row = InstrunetRepositoryUtils.get_instrument_with_serial_and_material_number(self, self.test_serial_number, self.test_material_number)
        if selected_instument_row is not None:
            # Edit instrument data
            utils = InstrunetRepositoryUtils()
            utils.edit_instrument_data(page, selected_instument_row)
            edit_instrument = True

        self.assertTrue(edit_instrument)

        self.driver.close()

    def test_02_chcek_edited_instrument_data(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        check_edit_instrument = False

        # Filter instuments
        page.enter_text(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT, self.test_serial_number)
        # Get list of instruments
        page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        selected_instument_row = InstrunetRepositoryUtils.get_instrument_with_serial_and_material_number(self,
                                                                                                         self.test_serial_number,
                                                                                                         self.test_material_number)
        if selected_instument_row is not None:
            utils = InstrunetRepositoryUtils()
            check_edit_instrument = utils.check_instrument_after_edit_data(page, selected_instument_row)

        self.assertTrue(check_edit_instrument)

        self.driver.close()