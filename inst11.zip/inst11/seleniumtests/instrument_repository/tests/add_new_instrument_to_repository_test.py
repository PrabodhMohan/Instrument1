import unittest
from instrument_repository.locators.instrument_repository_locators import InstumentReposiotryLocators
from instrument_repository.utils.BasePage import BasePage
from instrument_repository.utils.login_instument_repository import LoginInstrumentRepository
from instrument_repository.utils.InstrumentRepositoryUtils import InstrunetRepositoryUtils

# Retina-ID BOOK_LOG-76962 || ROC-696
class AddNewInstrumentToRepositoryTest(unittest.TestCase):

    test_material_number = "test_material_number"
    test_serial_number = "test_serial_number"

    test_data_river_material_number = "5524245001"
    test_data_river_serial_number = "1002"


    @classmethod
    def setUpClass(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        # Check that instrument is present
        instrument_exist = InstrunetRepositoryUtils.check_is_present_instrument_by_serial_and_material_number(self, page, self.test_serial_number, self.test_material_number)

        # Check that instrument from data river is present
        instrument_from_data_river_exist = InstrunetRepositoryUtils.check_is_present_instrument_by_serial_and_material_number(self,page,self.test_data_river_serial_number,self.test_data_river_material_number)

        if instrument_exist:
            utils = InstrunetRepositoryUtils()
            utils.remove_instrument_by_serial_and_material_number(page, self.test_serial_number, self.test_material_number)

        if instrument_from_data_river_exist:
            utils = InstrunetRepositoryUtils()
            utils.remove_instrument_by_serial_and_material_number(page, self.test_data_river_serial_number, self.test_data_river_material_number)

        self.driver.close()

    def test_01_add_new_instrument_to_repository(self):

        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)
        # Add new defined insturment
        utils = InstrunetRepositoryUtils()
        utils.add_new_instrument(page)
        # Check that instrument with serial and material number is present
        instrument_exist = InstrunetRepositoryUtils.check_is_present_instrument_by_serial_and_material_number(self, page,self.test_serial_number, self.test_material_number)
        self.assertTrue(instrument_exist)

        self.driver.close()

    def test_02_check_edit_instrument_data(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        check_edit_instrument = False
        # Filter instuments
        page.enter_text(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT, self.test_serial_number)
        # Get list of instruments
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_serial_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-serialNumber')]//div").text
            selected_material_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-materialNumber')]//div").text
            if selected_serial_number == self.test_serial_number and selected_material_number == self.test_material_number:
                # Check instrument data from edit panel
                utils = InstrunetRepositoryUtils()
                check_edit_instrument = utils.check_instrument_after_add_data(page, instrument_list[x])
                break
        self.assertTrue(check_edit_instrument)

        self.driver.close()

    def test_03_add_already_existing_istrument_to_repository(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)
        # Add new defined insturment
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_BUTTON)
        # Change tab to basic data and add test data
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_BASIC_DATA_BUTTON)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_MATERIAL_NUMBER_INPUT, self.test_material_number)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_SERIAL_NUMBER_INPUT, self.test_serial_number)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)

        serial_number_helper = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_SERIAL_NUMBER_HELPER).text
        material_number_helper = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_MATERIAL_NUMBER_HELPER).text
        self.assertTrue( "Material and serial numers are not unique" in material_number_helper)
        self.assertTrue("Serial and material numers are not unique" in serial_number_helper)
        instrument_name_helper = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_NAME_HELPER).text
        instrument_type_helper = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_TYPE_HELPER).text
        instrument_gtin_helper = page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_GTIN_HELPER).text
        self.assertTrue("Instrument name is required" in instrument_name_helper)
        self.assertTrue("Instrument type is required" in instrument_type_helper)
        self.assertTrue("nstrument GTIN is required" in instrument_gtin_helper)

        self.driver.close()


    def test_add_new_instrument_to_repository_from_data_river(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        # Add new defined insturment
        utils = InstrunetRepositoryUtils()
        utils.add_new_instrument_with_data_river_serial_and_material_number(page, self.test_data_river_serial_number,
                                                                                  self.test_data_river_material_number)
        # Check that instrument with serial and material number is present
        instrument_exist = InstrunetRepositoryUtils.check_is_present_instrument_by_serial_and_material_number(self, page, self.test_data_river_serial_number,
                                                                                                                          self.test_data_river_material_number)
        self.assertTrue(instrument_exist)

        self.driver.close()