import unittest
from instrument_repository.utils.InstrumentRepositoryUtils import InstrunetRepositoryUtils
from instrument_repository.utils.BasePage import BasePage
from instrument_repository.locators.instrument_repository_locators import InstumentReposiotryLocators
from instrument_repository.utils.login_instument_repository import LoginInstrumentRepository


# Retina-ID BOOK_LOG-80016 || ROC-1126
class ListOfQualificationRelatedDocumentsTest(unittest.TestCase):
    test_material_number = "test_material_number"
    test_serial_number = "test_serial_number"
    test_first_document_name = "first_document_name"
    test_first_document_url = "https://www.roche.com/fitst_document"
    test_second_document_name = "second_document_name"
    test_second_document_url = "https://www.roche.com/second_document"

    @classmethod
    def setUpClass(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        # Check that instrument is present
        instrument_exist = InstrunetRepositoryUtils.check_is_present_instrument_by_serial_and_material_number(self,page,self.test_serial_number, self.test_material_number)

        if not instrument_exist:
            # Add new defined insturment
            utils = InstrunetRepositoryUtils()
            utils.add_new_instrument(page)

        self.driver.close()

    def test_list_of_qualification_related_documents(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        # Filter instuments
        page.enter_text(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT, self.test_serial_number)
        # Get list of instruments
        instrument_list = page.visibility_of_all_elements(InstumentReposiotryLocators.INSTRUMENT_LIST)
        for x in range(0, len(instrument_list)):
            selected_serial_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-serialNumber')]//div").text
            selected_material_number = instrument_list[x].find_element_by_xpath(".//td[contains(@data-testid,'-materialNumber')]//div").text
            if selected_serial_number == self.test_serial_number and selected_material_number == self.test_material_number:
                instrument_list[x].find_element_by_xpath(".//button[@data-testid='instrument-table-edit-button']").click()
                page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)
                page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_TAB_EDIT_DOCUMENTS_BUTTON)
                page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_TITLE)
                break

        # Remove all documents
        delete_document_buttons = self.driver.find_elements_by_xpath(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_DELETE_BUTTON_LIST[1])
        for x in range(len(delete_document_buttons)):
            delete_document_buttons = self.driver.find_elements_by_xpath(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_DELETE_BUTTON_LIST[1])
            delete_document_buttons[0].click()

        # Check list of document is empty
        delete_document_buttons = self.driver.find_elements_by_xpath(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_DELETE_BUTTON_LIST[1])
        self.assertEqual(len(delete_document_buttons),0)

        # Add first documents with url
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_NAME_INPUT, self.test_first_document_name)
        page.enter_text(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_URL_INPUT, self.test_first_document_url)
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_ADD_BUTTON)

        # Check document with name and url is added
        is_document_present = InstrunetRepositoryUtils().check_is_present_document_with_name_and_url(page, self.test_first_document_name, self.test_first_document_url)
        self.assertTrue(is_document_present)

        # Edit first document
        InstrunetRepositoryUtils().edit_instrument_document_name_and_url(page, self.test_second_document_name, self.test_second_document_url)

        # Check document with name and url is added
        is_document_present = InstrunetRepositoryUtils().check_is_present_document_with_name_and_url(page,self.test_second_document_name,self.test_second_document_url)
        self.assertTrue(is_document_present)
        delete_document_buttons = self.driver.find_elements_by_xpath(InstumentReposiotryLocators.ADD_INSTRUMENT_DOCUMENT_DELETE_BUTTON_LIST[1])
        self.assertEqual(len(delete_document_buttons), 1)

        # Save all changes
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)
        page.invisibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)

        self.driver.close()