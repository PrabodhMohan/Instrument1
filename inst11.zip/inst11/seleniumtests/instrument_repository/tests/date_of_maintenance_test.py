import unittest
from instrument_repository.utils.InstrumentRepositoryUtils import InstrunetRepositoryUtils
from instrument_repository.utils.BasePage import BasePage
from instrument_repository.locators.instrument_repository_locators import InstumentReposiotryLocators
from instrument_repository.utils.login_instument_repository import LoginInstrumentRepository
from datetime import datetime
from datetime import timedelta


# Retina-ID BOOK_LOG-80016 || ROC-1126
class DateOfMaintenanceTest(unittest.TestCase):
    test_material_number = "test_material_number"
    test_serial_number = "test_serial_number"
    test_last_maintenance = "25-Nov-2021"
    test_next_maintenance = (datetime.now() + timedelta(days=5) ).strftime("%d-%b-%Y")
    test_edit_last_maintenance = "28-Nov-2021"
    test_edit_next_maintenance = (datetime.now() + timedelta(days=10)).strftime("%d-%b-%Y")

    @classmethod
    def setUpClass(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        # Check that instrument is present
        instrument_exist = InstrunetRepositoryUtils.check_is_present_instrument_by_serial_and_material_number(self,page,self.test_serial_number, self.test_material_number)

        if not instrument_exist:
            # Add new defined insturment
            utils = InstrunetRepositoryUtils()
            utils.add_new_instrument(page)

        self.driver.close()

    def test_date_of_maintenance_test(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        # Filter instuments
        InstrunetRepositoryUtils().filter_instrument_and_go_to_edit(page, self.test_serial_number, self.test_material_number)

        # Delete actual and set new date of next maintenance and executed maintenance
        InstrunetRepositoryUtils().set_maintenance_dates(page, self.test_last_maintenance, self.test_next_maintenance)

        # Save all changes
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)
        page.invisibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)

        page.refresh()

        # Filter instuments
        InstrunetRepositoryUtils().filter_instrument_and_go_to_edit(page, self.test_serial_number, self.test_material_number)
        # Check date of next maintenance and executed maintenance
        validation_restult =  InstrunetRepositoryUtils().valid_maintenance_dates(page, self.test_last_maintenance, self.test_next_maintenance)
        self.assertTrue(validation_restult)

        # Edit date of next maintenance and executed maintenance
        InstrunetRepositoryUtils().set_maintenance_dates(page, self.test_edit_last_maintenance, self.test_edit_next_maintenance)
        # Save all changes
        page.click(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)
        page.invisibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_CONFIRM_BUTTON)

        page.refresh()

        # Filter instuments
        InstrunetRepositoryUtils().filter_instrument_and_go_to_edit(page, self.test_serial_number, self.test_material_number)
        # Check date of next maintenance and executed maintenance after edit
        validation_restult =  InstrunetRepositoryUtils().valid_maintenance_dates(page, self.test_edit_last_maintenance, self.test_edit_next_maintenance)
        self.assertTrue(validation_restult)

        self.driver.close()