import unittest
from instrument_repository.locators.instrument_repository_locators import InstumentReposiotryLocators
from instrument_repository.utils.BasePage import BasePage
from instrument_repository.utils.login_instument_repository import LoginInstrumentRepository

# Retina-ID IPSV_LOG-77476 || ROC-621
class OpenMainPageTest(unittest.TestCase):

    def test_open_main_page(self):
        # Go to login page and login user
        self.driver = LoginInstrumentRepository().loginToDesktop('test18')
        page = BasePage(self.driver)

        # Check main page header
        page.visibility_of_element(InstumentReposiotryLocators.MAIN_PAGE_HEADER)

        # Check import csv button
        page.visibility_of_element(InstumentReposiotryLocators.IMPORT_CSV_BUTTON)

        # Check add instrument button
        page.visibility_of_element(InstumentReposiotryLocators.ADD_INSTRUMENT_BUTTON)

        # Check search element
        page.visibility_of_element(InstumentReposiotryLocators.MAIN_PAGE_SEARCH_INPUT)

        # Check instrument table headers
        page.visibility_of_element(InstumentReposiotryLocators.TABLE_HEAD_INSTRUMENT_NAME)
        page.visibility_of_element(InstumentReposiotryLocators.TABLE_HEAD_INSTRUMENT_TYPE)
        page.visibility_of_element(InstumentReposiotryLocators.TABLE_HEAD_SERIAL_NUMBER)
        page.visibility_of_element(InstumentReposiotryLocators.TABLE_HEAD_MATERIAL_NUMBER)
        page.visibility_of_element(InstumentReposiotryLocators.TABLE_HEAD_FLOOR_AND_ROOM_LOCATION)
        page.visibility_of_element(InstumentReposiotryLocators.TABLE_HEAD_RESPONSIBLE_PERSON)
        page.visibility_of_element(InstumentReposiotryLocators.TABLE_HEAD_IS_BOOKABLE)
        page.visibility_of_element(InstumentReposiotryLocators.TABLE_HEAD_IS_VISUALIZED)
        page.visibility_of_element(InstumentReposiotryLocators.TABLE_HEAD_ACTIONS)

        # Click user info
        page.click(InstumentReposiotryLocators.MAIN_PAGE_HEADER_USER_INFO)
        # Check popover elements
        page.visibility_of_element((InstumentReposiotryLocators.USER_INFO_POPOVER_LOGO))
        page.visibility_of_element((InstumentReposiotryLocators.USER_INFO_POPOVER_USERNAME))
        page.visibility_of_element((InstumentReposiotryLocators.USER_INFO_POPOVER_EMAIL))

        self.driver.close()
