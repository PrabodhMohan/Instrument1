#!/bin/bash

docker build -t registry.code.roche.com/digitallab/selenium-chrome .
