CWD=$(pwd)
PROJECT=$(git remote get-url --all origin |sed 's|.*/||' | sed 's/.git//g')
docker run -ti --rm \
    -e ENV=r4s \
    --shm-size=2g \
    -v ${CWD}:/builds/digitallab/${PROJECT} \
    --workdir /builds/digitallab/${PROJECT} \
    registry.code.roche.com/digitallab/selenium-chrome bash